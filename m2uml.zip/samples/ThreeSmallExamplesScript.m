%% Some small examples 
%#ok<*NASGU>
%%  Define a list of the classes
fqnlist = { 'FileExchange.m2uml.Element'
            'FileExchange.m2uml.Doer'
            'FileExchange.m2uml.Class'
            'FileExchange.m2uml.MetaDataScanner'
          };
%%  Create a PlantUML script in a text file.
puml_script = m2uml.create_PlantUML_script( 'Classes',fqnlist ); 
%%  Display the full filespec of the pluml-script
disp( puml_script )
%%  Create a minimal puml-script with the same four classes
user.Footer.On          = false;
user.Header.On          = false;
user.Title.On           = false;
user.Diagram.Monospaced = false;
user.Diagram.Arguments  = false;
user.Property.private   = false;
user.Property.protected = false;
user.Method.private     = false;
user.Method.protected   = false;
user.TodoFixme.fixme    = false;                     
user.TodoFixme.todo     = false;                      
user.TodoFixme.note     = false;
%
user.Hyperlink.Class        = false;
user.Hyperlink.Enumeration  = false;
user.Hyperlink.Event        = false;
user.Hyperlink.Function     = false;
user.Hyperlink.Method       = false;
user.Hyperlink.Package      = false;
user.Hyperlink.Property     = false;
user.Hyperlink.TodoFixme    = false;
%
user.Tooltip.Class          = false;
user.Tooltip.Enumeration    = false;
user.Tooltip.Event          = false;
user.Tooltip.Function       = false;
user.Tooltip.Method         = false;
user.Tooltip.Package        = false;
user.Tooltip.Property       = false;
user.Tooltip.TodoFixme      = false;
%
puml_script = m2uml.create_PlantUML_script( 'Classes',fqnlist, 'UserOptions',user );
%%  Display the full filespec of the puml-script
disp( puml_script )
%%  Use local installation of PlantUML 
user.Title.On           = true;
user.Hyperlink.Class    = true;
user.Hyperlink.Method   = true;
user.Hyperlink.Package  = true;
user.Hyperlink.Property = true;
user.Tooltip.Class      = true;
user.Tooltip.Method     = true;
user.Tooltip.Package    = true;
user.Tooltip.Property   = true;

puml_script = m2uml.create_PlantUML_script(                     ...
                'Classes'       , fqnlist                       ...
            ,   'UserOptions'   , user                          ...
            ,   'Title'         , 'local PlantUML-installation' ); 

graphic_file = m2uml.puml2graphic( 'PlantUmlScript',puml_script, 'GraphicFormat','svg' );

m2uml.depict_graphic_file( 'GraphicFile',graphic_file )
