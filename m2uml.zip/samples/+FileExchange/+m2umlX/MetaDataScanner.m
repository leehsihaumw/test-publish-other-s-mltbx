classdef    MetaDataScanner < FileExchange.m2umlX.Doer          %
% MetaDataScanner    

%#ok<*AGROW>

    properties                                                  %
    end
    methods     ( Access = ?FileExchange.m2umlX.Doer )          %
        function    execute_PlantUmlScript  ( this, pus )       %
            %
            this.execute_for_all_children( pus )
        end
        function    execute_Class           ( this, obj )       %

            objmeta = meta.class.fromName( obj.source_file.fqn );
            
            obj.data.CircleCharacter = this.getCircleCharacter( objmeta );   
            obj.data.isAbstract      = objmeta.Abstract;
            obj.data.isEnumeration   = objmeta.Enumeration;            
            
            for prp_meta = reshape( objmeta.PropertyList, 1,[] ) 
                if strcmp( prp_meta.DefiningClass.Name, obj.source_file.fqn )
                    prp = this.create_property( prp_meta );
                    prp.source_file = obj.source_file;
                    obj.children = [ obj.children, prp ];
                end
            end
            
            for mth_meta = reshape( objmeta.MethodList, 1,[] ) 
                if  strcmp( mth_meta.DefiningClass.Name, obj.source_file.fqn ) ...
                &&  not( strcmp( mth_meta.Name, 'empty' ) )
            
                    mth = this.create_method( mth_meta );
                    cac = regexp( obj.source_file.fqn, '\.', 'split' );
                    % TODO: has_explicit_constructor is slow. execute_Class, line 37,
                    % time: 1.259s, Calls: 145. Reason: mainly the call of checkcode.
                    % x8.has_explicit_constructor takes half the time. which('fqn')
                    % dominates. Use ffs as input if available. 
                    if  x8.has_explicit_constructor( obj.source_file ) ...
                    &&  strcmp( cac{end}, mth_meta.Name )   % and the name agrees
                        mth.data.isExplicitConstructor = true;
                    end
                    
                    mth.source_file = obj.source_file;
                    obj.children = [ obj.children, mth ];   
                end
            end
        end
        function    execute_Footer          ( ~, ~ )            %
            % Does not provide any real behavior.  
        end
        function    execute_Function        ( ~, obj )          %
            obj.data.CircleCharacter = 'F';   
        end
        function    execute_Header          ( ~, ~ )            %
            % Does not provide any real behavior.  
        end
        function    execute_Method          ( ~, ~ )            %
            % Does not provide any real behavior. Not supposed to be invoked.
            warning('Does not provide any real behavior. Not supposed to be invoked.')
        end
        function    execute_Package         ( this, obj )       %
            %
            this.execute_for_all_children( obj )
%             for obj = pkg.children
%                 this.execute( obj ) 
%             end
        end
        function    execute_Property        ( ~, ~ )            %
            % Does not provide any real behavior. Not supposed to be invoked.
            warning('Does not provide any real behavior. Not supposed to be invoked.')
        end
        function    execute_Relationship    ( ~, ~ )            %
            % Does not provide any real behavior.
        end
        function    execute_Separator       ( ~, ~ )            %
            % Does not provide any real behavior. Not supposed to be invoked.
            warning('Does not provide any real behavior. Not supposed to be invoked.')
        end
        function    execute_SingleCodeRow   ( ~, ~ )            %
            % Does not provide any real behavior. 
        end
        function    execute_Skinparam       ( ~, ~ )            %
            % Does not provide any real behavior. 
        end
        function    execute_Title           ( ~, ~ )            %
            % Does not provide any real behavior. 
        end
        function    execute_TodoFixme       ( ~, ~ )            %
            % Does not provide any real behavior. Not supposed to be invoked.
            warning('Does not provide any real behavior. Not supposed to be invoked.')
        end 
        %
    end
    methods     ( Access = private )
%{
%         function    array   = create_relationship_array ( this, cls )           %
% 
%             array = x8.Relationship.empty(1,0);
%             
%             if isa( cls, 'x8.Class' )
%                 clsmeta = meta.class.fromName( cls.fqn );
%                 for super = reshape( clsmeta.SuperclassList, 1,[] )
%                     array = [ array, this.create_relationship( cls.fqn, super ) ];   
%                 end
%             end
%         end
%}
        function    new_prp = create_property           ( ~, prp_meta )         %
            new_prp = x8.Property( prp_meta.Name );  
            
            new_prp.data.isAbstract = prp_meta.Abstract;  
            new_prp.data.isStatic   = prp_meta.Constant;
            % NOTE: quickfix to handle "properties ( SetAccess = {?ClassName1,...} )" 
            if ischar( prp_meta.SetAccess )
                new_prp.data.visibility = prp_meta.SetAccess;
            else
                new_prp.data.visibility = 'protected';
            end
            
            if strcmp( prp_meta.SetAccess, 'immutable' ) 
                new_prp.data.isStatic = true;
            end
        end
        function    new_mth = create_method             ( ~, method_meta )      %
            new_mth = x8.Method( method_meta.Name );  

            new_mth.data.isAbstract  = method_meta.Abstract;  
            new_mth.data.isStatic    = method_meta.Static;
            % NOTE: quickfix to handle "methods ( Access = {?ClassName1,?ClassName2} )" 
            if ischar( method_meta.Access )
                new_mth.data.visibility = method_meta.Access;
            else
                new_mth.data.visibility = 'protected';
            end
            new_mth.data.outargs     = method_meta.OutputNames;
            new_mth.data.inargs      = method_meta.InputNames;
        end
        function    new_rls = create_relationship       ( ~, name, super_meta ) %
            
            len = length( super_meta );
            new_rls(1,len) = x8.Relationship();

            new_rls.data.source  = name;
            new_rls.data.target  = super_meta.Name;
            new_rls.data.type    = 'generalization';
            new_rls.data.keyword = '';
        end
        function    out     = getCircleCharacter        ( ~, mco )              %
            
            out = 'C';  % Adhere to PlantUml, which uses C as default
%             str = fqn2type( mco.Name );

        %   The order of the following if-statements is important, since a class 
        %   may meet the criteria of more than one. A Singleton is typically also a
        %   Handle class, but here it will by tagged with S, since S comes before H.
        
%             if strcmp( str, 'function' )    % F 
%                 out = 'F';
%                 return                                                      %   RETURN
%             end
            if mco.Abstract                 % A 
                out = 'A';
                return                                                      %   RETURN
            end
            if mco.Enumeration              % E 
                out = 'E';
                return                                                      %   RETURN
            end
            if isSingleton_( mco )          % S 
                out = 'S';
                return                                                      %   RETURN
            end
            if isHandleClass_( mco )        % H 
                out = 'H';
                return                                                      %   RETURN
            end
            if not( mco.HandleCompatible )  % V 
                out = 'V';
                return                                                      %   RETURN
            end
        end
    end
end
function    isS = isSingleton_( mco )                           %
%    
%   Assumption: 
%       A class is a Singleton iff it has an explicite constructor that is private     

    isS = false;
    for jj = 1 : numel( mco.Methods )
        if is_explicite_constructor_( mco, jj )
            if  strcmp( mco.Methods{jj}.Access, 'private' )
                isS = true;
            end
            break
        end
    end
end
function    isC = is_explicite_constructor_( mco, ix_method  )  %
%
%   Assumption: The meta class object does not explicitely indicate the constructor 

    isC = false;
    if strcmp(  mco.Methods{ix_method}.DefiningClass.Name, mco.Name )
        cac = regexp( mco.Name, '\.', 'split' );
        if strcmp( mco.Methods{ix_method}.Name, cac{end} )
            isC = true;
        end
    end
end
function    isH = isHandleClass_( mco )                         %
%    
%   Assumption: 
%       A class is a Handle class if mco.HandleCompatible is true and one 
%       of it's superclasses is a handle class

    if not( mco.HandleCompatible )
        isH = false;
        return
    end
    
    obj = mco;  isH = false;
    for jj = 1 : length( obj.SuperClasses )
    
        super_class = obj.SuperClasses{jj};
        if strcmp( super_class.Name, 'handle' )
            isH = true;
            break
        else
            isH = isHandleClass_( super_class );    % recursive call
        end
    end
end
