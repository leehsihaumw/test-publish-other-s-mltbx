classdef    Class  < FileExchange.m2umlX.Element        %   
% Knows the data to make the class block code for ONE Matlab class. NodeHierarchyCreator

% Class holds the data needed to generatate PlantUML code for one Matlab class. Class
% relies on children for data on property, method and todofixme code.

    properties                                          %
        % Data used for the class block code
        data = struct(  'CircleCharacter'       , ''  ... capital letter in circle
                    ,   'CircleBackgroundColor' , ''  ... color of circle background
                    ,   'stereotype'            , ''  ...
                    ,   'tooltip'               , ''  ...
                    ,   'isAbstract'            , false  ...
                    ,   'isEnumeration'         , false  );
        %
        % Children of class include objects of Property, Method and TodoFixme 
        children = x8.Element.empty(1,0);
        % Instance of class, SourceFile, with the properties: ffs and fqn
        source_file = x8.SourceFile.empty(1,0);
        %
        % The longest text row controls the width of the class-box. TodoFixme strings
        % must not increase the width of the class-box, but on the other hand use the
        % available width. max_class_leaf_string_width is set by the longest string in
        % the box and used to set the part of the todofixme-string, which can be
        % displayed in the box.
        max_class_leaf_string_width
    end
    methods
        function    this = Class( varargin )            %
            % Explicit constructor
            this = this@FileExchange.m2umlX.Element( varargin{:} );
        end
    end
end
