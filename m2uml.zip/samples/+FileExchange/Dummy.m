classdef 	Dummy
    % Dummy "Issue about Namespace and Package"
    
    properties
        Property1
    end
    methods
        function this = m02( inputArg1, inputArg2 )
            if not( nargin == 0 )
                this.Property1 = inputArg1 + inputArg2;
            end
        end
    end
end
