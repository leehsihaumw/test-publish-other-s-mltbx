classdef    Package  < FileExchange.m2uml.Element
% Knows all data to make the namespace block for ONE Matlab package.   

    properties
        % Data used for the package code block
        data = struct(  'BackgroundColor'   ,   ''  ...
                    ,   'folderspec'        ,   ''  ...
                    ,   'tooltip'           ,   ''  ...
                    );
        %
        % Children of class include objects of Class, Function and Package 
        children = FileExchange.m2uml.Element.empty(1,0);
    end
    methods
        function    this = Package( varargin )
            % Explicit constructor
            this@FileExchange.m2uml.Element( varargin{:} );
        end
    end
end
