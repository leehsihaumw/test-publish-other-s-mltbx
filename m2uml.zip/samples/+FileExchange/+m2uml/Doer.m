classdef    Doer < handle
    %
    methods     ( Access = public )
        function    execute( this, obj )                          %
            %
            
            %   NOTE: quickfix to handle PlantUmlCodePrinter, which is the only
            %   one that is controlled by obj.isSelected. The reason for the test,
            %   not(isempty(obj)), is also a special case, - fill in which.
            
            is_printer = isa( this, 'x8.PlantUmlCodePrinter' );
            
            if  not(isempty(obj))                                   ...
            &&  ( not(is_printer) || ( is_printer && obj.isSelected ) )
                %
                cac = regexp( class(obj), '\.', 'split' );   
                mth = sprintf( '%s_%s', 'execute', cac{end} );
                feval( mth, this, obj );
            end
        end
    end
    methods     ( Access = protected )
        function    execute_for_all_children( this, obj )         %
            %
            for child = obj.children
                this.execute( child )
            end
        end
    end
end
