classdef    PlantUmlCodePrinter < FileExchange.m2uml.Doer                   %
% PlantUmlCodePrinter

%   NOTE: The Matlab browser has a print feature. It is possible to print to an Adobe
%   or a Microsoft PDF-printer. Text and symbols display well, but box borders and 
%   background colors are missing. Good news: open the svg-file with Internet Explorer  
%   and print to Adobe works just fine.  

    properties                                                  %
        %
        plantuml_code = '';     % <1xn char>
    end
    properties  ( Access = private )                            %
        %
        current_indent = 0;
        %
        tab_size       = 4;
        %
        max_leaf_string_width
        %
        options     %   structure
    end

    methods     ( Access = public )                             %
        function    this = PlantUmlCodePrinter( varargin )      %
            %
            narginchk( 0, 1 )
            if nargin == 1
                this.options = varargin{1};
            end
        end
    end
    methods     ( Access = ?FileExchange.m2uml.Doer )           %
        function    execute_PlantUmlScript  ( this, obj )       %
            %
            this.add_Row( '@startuml' )
            this.increaseIndent( +1 )

            this.execute_for_all_children( obj )

            this.increaseIndent( -1 );
            this.add_Row( '@enduml' )
        end
        function    execute_Class           ( this, obj )       %
            %                                                   
            this.add_ClassDefRow( obj )
            this.increaseIndent( +1 )
            this.execute_for_all_children( obj )
            this.increaseIndent( -1 );
            this.add_Row( '}' )
        end
        function    execute_Event           ( this, obj )       %
            %
            this.add_EventRow( obj )
        end
        function    execute_Enumeration     ( this, obj )       %
            %
            this.add_EnumerationRow( obj )
        end
        function    execute_Footer          ( this, obj )       %
            %
            this.add_Row( 'left footer' )
            this.increaseIndent( +1 )
            str = sprintf(  '<font color=%s size=%d>%s</font>'  ...
                        ,   obj.Color, obj.Size, obj.String     );
            this.add_Row( str )
            this.increaseIndent( -1 )
            this.add_Row( 'end footer' )
        end
        function    execute_Function        ( this, obj )       %
            %
            this.max_leaf_string_width = 0;

            this.add_FunctionDefRow( obj )
            this.increaseIndent( +1 )
            this.execute_for_all_children( obj )
            this.increaseIndent( -1 );
            this.add_Row( '}' )
        end
        function    execute_Header          ( this, obj )       %
            this.add_Row( 'left header' )
            this.increaseIndent( +1 )
            str = sprintf(  '<font color=%s size=%d>%s</font>'  ...
                        ,   obj.Color, obj.Size, obj.String     );
            this.add_Row( str )
            this.increaseIndent( -1 )
            this.add_Row( 'end header' )
        end
        function    execute_Method          ( this, obj )       %
            %
            this.add_MethodRow( obj )
        end
        function    execute_Package         ( this, obj )       %
            %
            this.add_PackageDefRow( obj )
            this.increaseIndent( +1 )
            this.execute_for_all_children( obj )
            this.increaseIndent( -1 );
            this.add_Row( '}' )
        end
        function    execute_Property        ( this, obj )       %
            %
            this.add_PropertyRow( obj )
        end
        function    execute_Relationship    ( this, obj )       %
            if strcmp( obj.data.type, 'generalization' )
                str = sprintf( '%s <|-- %s', obj.data.target, obj.data.source );
                this.add_Row( str )
            else
                % keyboard
                error(  'm2uml:PlantUmlCodePrinter:Unexpected'      ...
                    ,   'Unexpected value of obj.data.type: "%s"'   ...
                    ,   value2short( obj.data.type )                )
            end
        end
        function    execute_Separator       ( this, obj )       %
            %
            this.add_Row( obj.string )
        end
        function    execute_SingleCodeRow   ( this, obj )       %
            %
            this.add_Row( obj.string )
        end                                             
        function    execute_Skinparam       ( this, obj )       %
            %
            this.add_Row( 'skinparam {' )
            this.increaseIndent( +1 )
            this.execute_for_all_children( obj )
            this.increaseIndent( -1 );
            this.add_Row( '}' )
        end                                             
        function    execute_Title           ( this, obj )       %
            %
            this.add_Row( 'title' )
            this.increaseIndent( +1 )
            str = sprintf(  '<font color=%s size=%d>%s</font>'  ...
                        ,   obj.Color, obj.Size, obj.String     );
            this.add_Row( str )
            this.increaseIndent( -1 )
            this.add_Row( 'end title' )
        end
        function    execute_TodoFixme       ( this, obj )       %
            %             
            this.add_TodoFixmeRow( obj )
        end
    end
    methods     ( Access = private )                            %
        %
        function    add_PackageDefRow    ( this, obj  )         %
            %
            str = createHyperlinkTooltip( this, obj );
            hex = w3_color_palette( obj.data.BackgroundColor );  % hex is required
            % namespace Dummy [[http://www.google.com{this is a tooltip}]] #DDDDDD {
            this.add_Row( sprintf( 'namespace %s %s %s {', obj.name, str, hex ) );
            % There is a good reason for using PlantUml Namespace rather than
            % Package. In packages you cannot have two classes with the very
            % same name in different packages. In namespace you can!
        end
        function    add_ClassDefRow      ( this, obj  )         %
            %
            obj.max_label_width.update( obj.name, true )
            
            % 3.15 Specific spot. Classes will always show a capital letter in a circle.
            % Default is (C). (However, is may be suppressed with the keyword, hidden.) 
            
            isCircle = not(isempty( obj.data.CircleCharacter ))     ...
                    && not(isempty( obj.data.CircleBackgroundColor ) );
                
            isStereotype = not(isempty( obj.data.stereotype ));

            if obj.data.isAbstract
                uml_str = sprintf( 'abstract class %s', obj.name );
            elseif obj.data.isEnumeration
                uml_str = sprintf( 'enum %s', obj.name );
            else
                uml_str = sprintf( 'class %s', obj.name );
            end

            if isCircle  
                crc = sprintf(  '(%c,%s)'                       ...
                            ,   obj.data.CircleCharacter        ...
                            ,   obj.data.CircleBackgroundColor  );
            else
                crc = '';
            end
            if isStereotype
                 crc = sprintf( '%s %s', crc, obj.data.stereotype );
            end
            if not(isempty( crc ))
                uml_str = sprintf( '%s <<%s>>', uml_str, crc );
            end
            
            if  this.options.Hyperlink.Class || this.options.Tooltip.Class 
                str = createHyperlinkTooltip( this, obj );
                this.add_Row( sprintf( '%s %s {', uml_str, str ) );
            else
                this.add_Row( sprintf( '%s {', uml_str ) );
            end
        end
        function    add_EventRow         ( this, obj  )         %
            %
            uml_str = sprintf( '{field} %c %s'                  ...
                    ,   vis2chr_(obj.data.visibility), obj.name  );

            str = createHyperlinkTooltip( this, obj );
            this.add_Row( sprintf( '%s %s', uml_str, str ) );

            obj.max_label_width.update( obj.name )
        end
        function    add_EnumerationRow   ( this, obj  )         %
            % DONE: include the enum.value in the display string
            17;
            if isnumeric( obj.value )
                if not(isempty( obj.value ))
                    uml_str = sprintf( '{field} %s  (%d)', obj.name, obj.value );
                else
                    uml_str = sprintf( '{field} %s', obj.name );
                end
            elseif islogical( obj.value )
                uml_str = sprintf( '{field} %s  (%d)', obj.name, obj.value );
            elseif ischar(obj.value) || isstring(obj.value)
                if not(isempty( obj.value ))
                    uml_str = sprintf( '{field} %s  (%s)', obj.name, obj.value );
                else
                    uml_str = sprintf( '{field} %s', obj.name );
                end
            else
                error(  'm2uml:PlantUmlCodePrinter:UnknownType'             ...
                    ,   'add_EnumerationRow is not implemented for: "%s"'   ...
                    ,   class(obj.value)                                    )
            end

            str = createHyperlinkTooltip( this, obj );
            this.add_Row( sprintf( '%s %s', uml_str, str ) );
            
            obj.max_label_width.update( obj.name )
        end
        function    add_FunctionDefRow   ( this, obj  )         %
            %
            %   class-name font-size is 12 and field-font-size is 11, thus "12/11".
            %   "200", found by trial, accounts for part of the circle and the gap
            %   between the circle and the text. 
            obj.max_label_width.update( obj.name, true )

            uml_str = sprintf( 'class %s <<', obj.name );
            crc = sprintf( '(%c,%s)', obj.data.CircleCharacter      ...
                                    , obj.data.CircleBackgroundColor );
            uml_str = sprintf( '%s%s>>', uml_str, crc );
            
            str = createHyperlinkTooltip( this, obj );
            this.add_Row( sprintf( '%s %s {', uml_str, str ) );
        end
        function    add_PropertyRow      ( this, obj  )         %
            %
            uml_str = '{field}';
            if obj.data.isAbstract
                uml_str = sprintf( '%s%s', uml_str, '{abstract}' );
            end
            % NOTE: {static} properties isn't a good idea. 

            % NOTE: Property and method names consisting of ONE character doesn't
            % display correctly. "+A" in the script displays as "  +A" in the browser.
            % The indent is the size of the visibility symbol, i.e. "+" is taken as
            % part of the name. "+ A" in the script gives the expected result. The
            % example under "3.6 Advanced class body" shows one space after the
            % visibility character. Thus, I use "%c %s" with a separating space.
            %
            % obj.data.prefix was introduced to add the "/" for dependent function.   

            uml_str = sprintf( '%s %c %c%s'                     ...
                            ,   uml_str                         ...
                            ,   vis2chr_(obj.data.visibility)   ...
                            ,   obj.data.prefix                 ...
                            ,   obj.name                        );

            str = createHyperlinkTooltip( this, obj );
            this.add_Row( sprintf( '%s %s', uml_str, str ) );
            
            obj.max_label_width.update( obj.name )
        end
        function    add_MethodRow        ( this, obj  )         %
            %
            uml_str = '{method}';
            if obj.data.isAbstract
                uml_str = sprintf( '%s%s', uml_str, '{abstract}' );
            end
            if obj.data.isStatic
                uml_str = sprintf( '%s%s', uml_str, '{static}' );
            end
            uml_str = sprintf( '%s %c %s', uml_str              ...
                    ,  vis2chr_( obj.data.visibility), obj.name );

            arg_str = this.createParameterList( obj );                        
            uml_str = sprintf( '%s %s', uml_str, arg_str );
            
            str = createHyperlinkTooltip( this, obj );
            uml_str = sprintf( '%s %s', uml_str, str );
            
            this.add_Row( uml_str );
            
            obj.max_label_width.update([obj.name,' ',arg_str])
        end
        function    add_TodoFixmeRow     ( this, obj  )         %
            %
            
            % The widths of the TodoFixme-display-string shall use the available
            % class-box-width, but not extend it. PlantUml adapt the class-box-width to
            % allow for the longest string. A proportional font is used. To calculate the
            % exact width of a display-string is complicated and over-kill. Thus, I keep
            % track of the maximun number of characters, max_class_leaf_string_length, 
            % and use ceil(0.96*this.max_class_leaf_string_length) as the upper limit of
            % TodoFixme-display-string.
            %            
            % FEX: calcticks by John Barber, especially subfunction, getTextSize
            % See: testStringExtent.m
            
            tooltip_label = obj.max_label_width.truncate_to_max_width( obj.data.tooltip );
                        
            uml_str = sprintf( '{field} %c%s', vis2chr_(obj.data.type), tooltip_label );

            str = createHyperlinkTooltip( this, obj );
            this.add_Row( sprintf( '%s %s', uml_str, str ) );
        end
    end
    methods     ( Access = private )                            %
        function    add_Row( this, uml_str )                    %
            %
            uml_str = strtrim( uml_str );                       % 2018-08-01
            this.plantuml_code  = cat( 2, this.plantuml_code                ...
            ,   sprintf( '%s%s\n', blanks(this.current_indent), uml_str )   );
        end
        function    increaseIndent( this, ii )                  %
            %
            this.current_indent = this.current_indent + ii.*this.tab_size;
            % TODO: rename increaseIndent to something neutral, e.g. changeIndent 
        end
        function    str = createHyperlinkTooltip( this, obj )   %
            %
            if  not( this.options.Hyperlink.(fcn(obj)) )  ...
            &&  not( this.options.Tooltip.(fcn(obj)) )    
                str = '';
                return                                              %   RETURN
            end
            
            if this.options.Tooltip.(fcn(obj))  % fcn returns the class base name
                tooltip = sprintf( '{%s}', obj.data.tooltip );
            else
                % '{}' rather than '' to suppress that the Hyperlink is displayed as 
                % tooltip - found out the hard way
                tooltip = '{}'; 
            end
            %   NOTE: Candidate for refactoring. This switch statement smells.
            type = fcn( obj );
            switch type
                case 'Package'      
                    if this.options.Hyperlink.Package
                        fmt = '[[matlab:cd(''%s'');%s]]';
                        str = sprintf( fmt, obj.data.folderspec, tooltip );
                    else
                        str = sprintf( '[[%s]]', tooltip );
                    end
                case 'Class'        
                    %   DONE: There might be better hyperlinks for Class and Function 
                    %   than "openDocument"
                    if this.options.Hyperlink.Class 
                        fmt = [ '[[matlab:matlab.desktop.editor.openAndGoToLine' ...
                                '(''%s'',%d);%s]]'                               ];
                        str = sprintf( fmt, obj.source_file.ffs, obj.data.line, tooltip );
                    else
                        str = sprintf( '[[%s]]', tooltip );
                    end
                case 'Function'     
                    if this.options.Hyperlink.Function
                        fmt = '[[matlab:matlab.desktop.editor.openDocument(''%s'');%s]]';
                        str = sprintf( fmt, obj.source_file.ffs, tooltip );
                    else
                        str = sprintf( '[[%s]]', tooltip );
                    end
                case {'Event','Enumeration','Property'}
                    % 
                    if this.options.Hyperlink.(type)
                        fmt = [ '[[[matlab:matlab.desktop.editor.openAndGoToLine'   ...
                                '(''%s'',%d);%s]]]'                                 ];
                        str = sprintf( fmt, obj.source_file.ffs ...
                                    ,   obj.data.line, tooltip  );
                    else
                        str = sprintf( '[[[%s]]]', tooltip );
                    end
                case 'Method'
                    %   NOTE: No hyperlink for implicit constructor
                    if  this.options.Hyperlink.Method   ...
                    &&  not(obj.data.isImplicitConstructor)
                        fmt = [ 'matlab:matlab.desktop.editor.openAndGoToFunction'  ...
                                '(''%s'',''%s'');%s'                                ];
                        fmt = ['[[[',fmt,']]]'];
                        str = sprintf( fmt, obj.source_file.ffs, obj.name, tooltip );
                    else
                        str = sprintf( '[[[%s]]]', tooltip );
                    end
                case 'TodoFixme'    
                    if this.options.Hyperlink.TodoFixme
                        fmt = [ '[[[matlab:matlab.desktop.editor.openAndGoToLine'   ...
                                '(''%s'',%d);%s]]]'                                 ];
                        str = sprintf( fmt, obj.source_file.ffs, obj.data.line, tooltip );
                    else
                        str = sprintf( '[[[%s]]]', tooltip );
                    end
                otherwise           
                    error(  'poi:m2uml:PlantUmlCodePrinter:UnknownName' ...
                        ,   'UnKnown base name of class: %s'            ...
                        ,   value2short( fcn( obj ) )                   )
            end
        end
        function    str = createParameterList( this, obj )      %
            %
            if  obj.data.isImplicitConstructor
                % The default argument name confuses me and doesn't add any value. ???
                str = '';
            else
                if this.options.Diagram.Arguments
                    str = sprintf( '(%s):[%s]'               ...
                        ,   strjoin( obj.data.inargs , ',' ) ...
                        ,   strjoin( obj.data.outargs, ',' ) );
                else
                    str = '';
                end
            end
        end
    end
end
function    chr = vis2chr_( level )                             %
%

%   Visibility indicator
    switch level
        case {'private','fixme'}    , chr = '-';
        case {'protected','todo'}   , chr = '#';
        case {'public','note'}      , chr = '+';
        otherwise
            error(  'm2uml:PlantUmlCodePrinter:UnKnownVisibility'       ...
                ,   'Unknown visibility|type: "%s"', value2short(level) )
    end
end
