classdef    Stack < handle
% Stack
 
%   The Stack class represents a last-in-first-out (LIFO) stack of objects. 
%   The usual push and pop operations are provided, as well as a method to 
%   peek at the top item on the stack, a method to test whether the stack 
%   is empty, and a method to search the stack for an item and discover how 
%   far it is from the top. Mimics java.util Class Stack
%
%   When a stack is first created, it contains no items. 
%  
    
    properties ( SetAccess = private, GetAccess = public )
        ID_         = '';
        Created_    = nan;
        caStack     = cell( 0, 1 );     %   caStack is flipped compared to the "stack"
    end
    
    methods ( Access = public )
        function this = Stack(  )           
            this.ID_        = nextID;
            this.Created_   = now;
        end
        function       push( this, val )    
            % Pushes an item onto the top of the stack
            this.caStack( end+1 ) = { val };
        end
        function val = pop( this )          
            % Returns the object at the top of the stack and removes it
            if not( this.isempty )
                val = this.caStack{ end };
                this.caStack( end ) = []; 
            else
                val = [];
            end
        end
        function val = peek( this )         
        % Returns the item at the top of the stack without removing it from the stack
            val = this.caStack{ end };
        end
        function ise = isempty( this )      
            % Tests if this stack is empty.
            ise = isempty( this.caStack ); 
        end
        function n   = search( this, obj )  
          % Returns the position of an object, obj, on this stack. 
          % n = the distance from the top of the stack (n=1 for top object )
          % n = -1 when the object is not on the stack.
            
            n   = -1;
            if  not( this.isempty )
                for ii = numel( this.caStack ) : -1 : 1 
                    if  eq( this.caStack{ ii }, obj )
                        n   = numel( this.caStack ) - ii + 1;
                    end
                end
            end
        end
        function       show( this )         
            fprintf( 'Stack: %s, <top-bottom>\n', this.ID_ )
            for ii = numel( this.caStack ) : -1 : 1
                item = this.caStack{ii};
                if isa( item, 'handle' )
                    if strcmp( 'ID_', properties(item) )
                        fprintf( ' %s: %s', class(item), item.ID_ )
                    else
                        printf( ' %s', class(item) )
                    end
                elseif ischar( item )
                    fprintf( ' %s', item ) 
                elseif isflint( item )
                    fprintf( ' %d', item ) 
                else
                    error(  'Stack:show:Failed' ...
                        ,   'Cannot show: "%s"' ...
                        ,   value2short( item ) )
                end
                fprintf( '%s', ',' )
            end
            fprintf( '\n' )
        end
        function       clear( this )        
            this.caStack = cell( 0, 1 );
        end
        function val = get( this, n )       
            % Returns the item at the n:th position of the stack. get(1) returns the top.
            ix  = this.size - n + 1;
            val = this.caStack{ix};
        end
        function val = size( this )         
            % Returns the number of items in the stack
            val = length( this.caStack );
        end
    end
end
