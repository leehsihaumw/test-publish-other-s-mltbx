classdef    MaxLabelWidth  < handle
    
    %   "Label" rather than "String" to avoid associations to the Matlab type string.
    
    properties  ( Constant = true, Access = private )           %
        pivot = 31;
    end
    properties  ( Access = private )                            %
        max_label_width = 0;
        character_widths
    end
    properties  ( SetAccess = private, GetAccess = public )     %
        isMonospace
    end
    
    methods     ( Access = public )                             %
        function    this = MaxLabelWidth( varargin )            %
% TODO: narginchk(1,1)
            if nargin <= 1 
                this.isMonospace = varargin{1};
                if this.isMonospace
                    this.character_widths = ...
                        [ reshape((this.pivot+1:255),[],1), ones(255-this.pivot,1) ];
                else
                    this.character_widths = create_AW_();
                end
            end
        end
        function    update( this, str, isHeader )               %
            
            narginchk(2,3)
            
            if nargin == 2
                isHeader = false;
            end
            
            wid = sum( this.character_widths( double(str)-this.pivot, 2 ) );
            if isHeader 
                if this.isMonospace
                    wid = (12/11)*wid + 2;
                else
                    wid = (12/11)*wid + 200;
                end
            end
            
            if wid > this.max_label_width 
                this.max_label_width = wid;
            end
        end
        function    str = truncate_to_max_width( this, str )    %

            current_width = this.width_( str );
            
            if current_width <= this.max_label_width
                % no need to truncate
                return                                          %   RETURN
            end
            
            ellipsis = ' ...';
            ellipsis_width = this.width_( ellipsis );
            
            %   current_guess is a number of characters
            guess = floor( strlength(str)*this.max_label_width/current_width ) - 2;
            current_width = this.width_( splitstr( str, guess ) );
            
            was_here = false(1,2);
            while not( all( was_here ) )
                if current_width + ellipsis_width > this.max_label_width
                    was_here( 1 ) = true;
                    guess = guess - 1;
                else
                    was_here( 2 ) = true;
                    if not( was_here( 1 ) )
                        guess = guess + 1;
                    end
                end
                current_width = this.width_( splitstr( str, guess ) );
            end
            if isa( str, 'string' )     % 2020-09-03, poi: required to pass old tests
                str = splitstr(str,guess) + ellipsis;
            else
                str = [ str(1:guess), ellipsis ];
            end
        end
        function    str = add_second_column( this, str, val )   %
            % add_second_column of value to one enumeration member. Not implemented
            %
            % Syntax:
            %    str = this.add_second_column( str, val )
            %
            % Inputs:
            %    str    enumeration member name
            %    in2    enumeration member value
            %
            % Outputs:
            %    str    'name    (val)' 
            %
            % Example:
            variable_not_used( this, str, val );
        end
    end
    methods     ( Access = private )                            %
        function    wid = width_( this, txt )                   %
            
            %   Not all characters are extended ascii. Let the width of char(>255) 
            %   be equal to the width of 'M'.
            chr = char( txt );  % 2020-07-28, poi
            chr_ix  = double( chr ) - this.pivot;
            chr_ix( chr_ix >= ( 255 - this.pivot ) ) = double('M') - this.pivot; 
            
            wid = sum( this.character_widths( chr_ix, 2 ) );
        end
    end
end
function    AW  = create_AW_()           %
    
    AW1 = ascii_032to126_();
    AW2 = ascii_161to255_();
    
    min_ascii = AW1(1,1);
    max_ascii = AW2(end,1);
    
    asc = reshape( min_ascii:max_ascii, [], 1 );
    
    AW = [ asc, nan(size(asc)) ]; 
    AW( AW1(:,1)-min_ascii+1, : ) = AW1;  
    AW( AW2(:,1)-min_ascii+1, : ) = AW2;  
    
    AW( isnan(AW(:,2)), 2 ) = 100;  % Q&D to avoid crashes
end
function    AW  = ascii_161to255_()      %
%   guestimate: the width of "ÅÄ" is equal to the width of "A" and "åä" to "a", etc.

    asc = [ 192:203,        204:207,      208:209,       210:216,       217:221       ];
    wid = [ 112*ones(1,12), 50*ones(1,4), 112*ones(1,2), 135*ones(1,7), 112*ones(1,5) ];
    
    asc = [ asc, 222:235,       236:239,      240:252,       253:255 ];
    wid = [ wid, 95*ones(1,14), 37*ones(1,4), 95*ones(1,13), 85*ones(1,3) ];
    
    asc = [ 161:191, asc ];         % YAGNI: not worth trying
    wid = [ 95*ones(1,31), wid ];
    
    [ ~, ixs ] = sort( asc );
    
    len = length( asc );
    AW = nan( len, 2 );
    AW( :, 1 ) = reshape( asc( ixs ), [], 1 );
    AW( :, 2 ) = reshape( wid( ixs ), [], 1 );
end
function    AW  = ascii_032to126_()      %
    
%   Stack Overflow: Roughly approximate the width of a string of text in Python? [closed]    
%   https://stackoverflow.com/questions/16007743/
%   roughly-approximate-the-width-of-a-string-of-text-in-python  
%
% def getApproximateArialStringWidth(st):
%     size = 0 # in milinches
%     for s in st:
%         if s in 'lij|\' ': size += 37
%         elif s in '![]fI.,:;/\\t': size += 50
%         elif s in '`-(){}r"': size += 60
%         elif s in '*^zcsJkvxy': size += 85
%         elif s in 'aebdhnopqug#$L+<>=?_~FZT' + string.digits: size += 95
%         elif s in 'BSPEAKVXY&UwNRCHD': size += 112
%         elif s in 'QGOMm%W@': size += 135
%         else: size += 50
%     return size * 6 / 1000.0 # Convert to picas
% by speedplane

    ascii_number = ...
    [ 108, 105, 106, 124,  39,  32,  ...
       33,  91,  93, 102,  73,  46,  44,  58,  59,  47,  92, 116,       ...
       96,  45,  40,  41, 123, 125, 114,  34,                           ... 
       42,  94, 122,  99, 115,  74, 107, 118, 120, 121,                 ...
       97, 101,  98, 100, 104, 110, 111, 112, 113, 117, 103,  35,       ... 
            36,  76,  43,  60,  62,  61,  63,  95, 126,  70,  90,  84,  ...
       66,  83,  80,  69,  65,  75,  86,  88,  89,  38,  85, 119,  78,  ... 
            82,  67,  72,  68                                           ...
       81,  71,  79,  77, 109,  37,  87,  64,                           ... 
       48,  49,  50,  51,  52,  53,  54,  55,  56,  57                  ];
    
    character_width = ...
    [ 37*ones(1, 6),  50*ones(1,12),  60*ones(1, 8),      85*ones(1,10),    ...
      95*ones(1,24), 112*ones(1,17), 135*ones(1, 8), (50+40)*ones(1,10)     ];
 
    [ ~, ixs ] = sort( ascii_number );
    
    len = length( ascii_number );    
    AW = nan( len, 2 );
    AW( :, 1 ) = reshape( ascii_number( ixs ), [], 1 );
    AW( :, 2 ) = reshape( character_width( ixs ), [], 1 );
end
