classdef    Separator  < m2uml.Element
% Separator knows all data to make ONE separator between compartments of a class box  

    properties                                      %
        %
        string = '';
    end
    methods                                         %
        function    this = Separator( varargin )    %
            % Explicit constructor
            this@m2uml.Element( varargin{1:2} );
            if nargin == 0
                return
            end
            this.string = varargin{3};
        end
    end
end
