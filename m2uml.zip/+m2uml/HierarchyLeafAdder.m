classdef    HierarchyLeafAdder < handle        
% HierarchyLeafAdder adds Footer, Header, Title and Skinparam to PlantUmlScript

    methods                                                 %
        function    add_option_based_items_to_hierarchy ( this, pus, options )  %
            %
            assert( isa( pus, 'm2uml.PlantUmlScript' )                 ...
                ,   'm2uml:LeadingLeafsCreator:execute:IllegalType'   ...
                ,   'Only PlantUmlScript objects allowed. Not "%s"!'...
                ,   class( pus )                                    )
            
            %   These items show up in the PlantUml code in the opposite order;
            %   skinparam first and footer last
            this.add_footer     ( pus, options );
            this.add_header     ( pus, options );
            this.add_title      ( pus, options );
%            
            this.add_direction  ( pus );    % top to bottom direction; left to right
            this.add_scale      ( pus, options );
            this.add_skinparam  ( pus );
        end
        function    set_max_label_width_calculator      (    ~, pus, is_mono )  %
            
            node_row = pus.traverse_hierarchy( pus );
            %   Each Class/Function object shall have a unique MaxLabelWidth object. 
            for obj = node_row
                if isa( obj, 'm2uml.Class' ) || isa( obj, 'm2uml.Function' ) 
                    obj.max_label_width = m2uml.MaxLabelWidth( is_mono ); 
                end
            end
        end
    end
    methods     ( Access = private )                        %
        function    add_direction   ( ~, pus )          %
            pus.children = [ m2uml.SingleCodeRow( 'direction', pus                  ...
                                        ,   'left to right direction'), pus.children ];
        end
        function    add_footer      ( ~, pus, options ) %
            %
            pus.children = [ m2uml.Footer( 'footer', pus, options.Footer ), pus.children ];
        end
        function    add_header      ( ~, pus, options ) %
            %
            pus.children = [ m2uml.Header( 'header', pus, options.Header), pus.children ];
        end
        function    add_scale       ( ~, pus, options ) %
            %   At one point scale seemed useful. It doesn't hurt to keep it like this.  
            width = options.General.DisplayWidth;
            scale = m2uml.SingleCodeRow( 'scale', pus, sprintf('scale %d width',width) );
            pus.children = [ scale, pus.children ];
        end
        function    add_skinparam   ( ~, pus )          %
            %
                skin = m2uml.Skinparam();
                fh = @(name,parent,puml)  m2uml.SingleCodeRow( name, parent, puml );
                skin.children =                                                     ...
                    [   fh( 'mono',  pus, 'classFontName Monospaced' )              ...
                    ,   fh( 'mono',  pus, 'classArrowFontName Monospaced' )         ...
                    ,   fh( 'mono',  pus, 'classAttributeFontName Monospaced' )     ...
                    ,   fh( 'mono',  pus, 'classStereotypeFontName Monospaced' )    ...
                    ,   fh( 'ortho', pus, 'linetype ortho' )                        ...
                    ];
                pus.children = [ skin, pus.children ];
            %   NOTE: skinparam defaultFontName is Monospaced
        end
        function    add_title       ( ~, pus, options ) %
            %
            pus.children = [ m2uml.Title('title', pus, options.Title ), pus.children ];
        end
    end
end
