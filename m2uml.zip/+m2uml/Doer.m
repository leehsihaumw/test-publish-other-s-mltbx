classdef    Doer < handle                   %
% Doer is superclass of classes, which operate on subclasses of Element
%
% Subclasses: LeafDisplayOrder, LeafDisplaySelection, MetaDataScanner, 
% PlantUmlCodePrinter, SourceFileScanner, FindFiles "< m2uml.Doer" 

% The property, fh, is the result of the second refactoring. Better performance was the
% driving force. /help/matlab/matlab_prog/techniques-for-improving-performance.html says:
%
%       Avoid functions such as eval, evalc, evalin, and feval(fname). Use the
%       function handle input to feval whenever possible. Indirectly evaluating a
%       MATLAB expression from text is computationally expensive.
%
% The original construct was
%       cac = regexp( class(obj), '\.', 'split' );
%       chr = sprintf( '%s_%s', 'execute', cac{end} );
%       feval( chr, this, obj );
% The current construct is 
%       cac = regexp( class(obj), '\.', 'split' );
%       this.fh.(cac{end}) ( this, obj );
% The current construct is significantly faster and cleaner. 
    
    properties  ( Access = protected )                      %
        fh = m2uml.Doer.create_function_handles;
    end
    methods     ( Static = true, Access = protected )       %
        function    fh = create_function_handles()          %
            fh.Class            = @execute_Class;
            fh.Enumeration      = @execute_Enumeration;
            fh.Event            = @execute_Event;
            fh.Footer           = @execute_Footer;
            fh.Function         = @execute_Function;
            fh.Header           = @execute_Header;
            fh.Method           = @execute_Method;
            fh.Package          = @execute_Package;
            fh.PlantUmlScript   = @execute_PlantUmlScript;
            fh.Property         = @execute_Property;
            fh.Relationship     = @execute_Relationship;
            fh.Separator        = @execute_Separator;
            fh.SingleCodeRow    = @execute_SingleCodeRow;
            fh.Skinparam        = @execute_Skinparam;
            fh.Title            = @execute_Title;
            fh.TodoFixme        = @execute_TodoFixme;
        end
    end
    methods     ( Access = public )         %
        function    execute( this, obj )                   %
            % execute double dispath
            
            if  isempty(obj) || not( isscalar(obj) )
                % catch empty objects, which however shall never occur.
                error( 'm2uml:Doer:Unexpected', 'Object is empty or not a scalar' )
            end
                            
            % PlantUmlCodePrinter is the only element that is controlled by
            % obj.isSelected.
            is_printer = isa( this, 'm2uml.PlantUmlCodePrinter' );
            
            if  not( is_printer )           ...       
            ||  ( is_printer && obj.isSelected )  
                % Double dispatch
                cac = regexp( class(obj), '\.', 'split' );
                % function handle | input arguments
                this.fh.(cac{end}) ( this, obj );
            end
        end
    end
    methods     ( Access = ?m2uml.Doer )                   %
    %   The functions of this block are overloaded as needed. 
    %   These null-methods saves tonnes of complicated if-statements.
        function    execute_Class           ( ~, ~ )       %
        end                                             
        function    execute_Enumeration     ( ~, ~ )       %
        end                                             
        function    execute_Event           ( ~, ~ )       %
        end                                             
        function    execute_Footer          ( ~, ~ )       %
        end                                             
        function    execute_Function        ( ~, ~ )       %
        end                                             
        function    execute_Header          ( ~, ~ )       %
        end                                             
        function    execute_Method          ( ~, ~ )       %
        end                                             
        function    execute_Package         ( ~, ~ )       %
        end                                             
        function    execute_PlantUmlScript  ( ~, ~ )       %
        end
        function    execute_Property        ( ~, ~ )       %
        end                                             
        function    execute_Relationship    ( ~, ~ )       %
        end                                             
        function    execute_Separator       ( ~, ~ )       %
        end                                             
        function    execute_SingleCodeRow   ( ~, ~ )       %
        end                                             
        function    execute_Skinparam       ( ~, ~ )       %
        end                                             
        function    execute_Title           ( ~, ~ )       %
        end                                             
        function    execute_TodoFixme       ( ~, ~ )       %
        end 
    end    
    methods     ( Access = protected )      %
        function    execute_for_all_children( this, obj )  %
            %
            for child = obj.children
                if not( isempty( child ) )
                    this.execute( child )
                end
            end
        end
    end
end
