classdef    SourceFile % < handle                             %
% SourceFile reads, trims and stores ONE m-module

    properties  ( SetAccess = private, GetAccess = public ) %
        % fully qualified file specification
        ffs     (1,:)   char      
        % fully qualified name
        fqn
        % type of m-file, class/function/...
        type
        % 
        namespace
        % 
        basename
        % 
        mcodes  (:,1)   struct = struct( 'row',{}, 'kinds',{}, 'block_type',{} );
        %
        external_methods    (1,:)  m2uml.SourceFile  
    end
    properties  ( SetAccess = private, GetAccess = private) %
        sfa = m2uml.SourceFileAnalyzer;
    end
    methods     ( Access = public )                         %
        function    this = SourceFile( file_list )          %
            %
            %   Syntax 
            %       obj = m2uml.SourceFile(); 
            %       obj = m2uml.SourceFile( file_list ); 
            %
            %   Inputs
            %       file_list   <nx1 cell>      filespecs
            %
            %   Don't validate file_list, because it's already done by
            %   create_PlantUML_script/validate_input_file_list_()
            
            if nargin == 0
                this.ffs  = '';
                this.fqn  = '';
                this.type = '';
                %
                this.namespace = '';
                this.basename  = '';
                return                                                  %   RETURN
            end
            
            len = numel( file_list );
            [ this(1,1:len).fqn ] = deal(''); % calls the construtor with nargin==0
            
            for ff = len : -1 : 1   % loop over all files

                this(ff).ffs = file_list{ff};

                % fqn, type, namespace, basename
                this(ff).type = fqn2type( this(ff).ffs );   % fqn2type now takes ffs
                [ this(ff).fqn, ~, this(ff).namespace, this(ff).basename ]  ...
                =   ffs2fqn( this(ff).ffs ); 
 
                this(ff).mcodes = this(ff).sfa.read_and_classify( this(ff).ffs );
                
                switch this(ff).type
                    case 'class'
                        this(ff).external_methods                       ...
                        =   this(ff).get_external_methods_source_files();
                    case 'function'
                        %   do nothing
                    case 'script'
                        fprintf( 2, 'Script will be excluded: "%s"\n', this(ff).ffs );
                        this(ff) = [];
                    case 'external_method'
                        this(ff).external_methods = m2uml.SourceFile.empty;
                    otherwise
                        fprintf( 2,'Unidentified will be excluded: "%s"\n', this(ff).ffs);
                        this(ff) = [];
                end
            end
            assert( not(isempty( this ))                ...
                ,   'poi:m2uml:SourceFile:EmptyObject'  ...
                ,   'The list contains no valid files'  )
        end
    end
    methods     ( Access = private )                        %
        function    sfs = get_external_methods_source_files( this )
            
            %   Find external methods. All m-files under the class definition
            %   folder defines single class-methods except for the classdef-file.
            
            assert( isscalar( this ) )
            assert( strcmp( this.type, 'class' ) )
            
            if not( contains( this.ffs, "@" ) )
                sfs = m2uml.SourceFile.empty;
                return                                                  %   RETURN              
            end
            
            pth = extractBefore( this.ffs, filesep+"@" );
            sad = dir( fullfile( pth, "@"+this.basename, '**', '*.m' ) );
            sad( strcmp( {sad.name}, this.basename+".m" ) ) = [];
            len = numel(sad);
            
            if len >= 1
                sfs( 1, len ) = m2uml.SourceFile(); 
                for jj = 1 : len
                    ffz{1} = fullfile( sad(jj).folder, sad(jj).name );
                    sfs(1,jj) = m2uml.SourceFile( ffz ); 
                end
            else
                sfs = m2uml.SourceFile.empty;
            end
        end
    end
end
