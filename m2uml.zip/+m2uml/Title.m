classdef    Title  < m2uml.Element
% Title knows all data to make the code for the title.  
% 
%   Title is displayed as one string row with parameterized font size and color. 

    properties                                  %
        %
        String  = '';
        %
        Size    = [];
        %
        Color   = '';
    end
    methods                                     %
        function    this = Title( varargin )    %
            % Explicit constructor. The properties, String, Size, and Color, are set.
            this@m2uml.Element( varargin{1:2} );
            if nargin == 3
                this.String = varargin{3}.String;
                this.Size   = varargin{3}.FontSize;
                this.Color  = varargin{3}.Color;
            end
        end
    end
end
