classdef    Enumeration  < m2uml.Element            %
% Enumeration knows all data to make the PlantUml field row for ONE enumeration.  

% NOTE: UMLD3 p82, Enumerations shows a simple class box without compartments for 
%       properties or methods. Most of the examples on the Internet show similar 
%       simple class boxes. 
%
%       ------------------------------------------------------------------------   
%       Data Type, Enumeration, https://www.uml-diagrams.org/data-type.html
%
%       Data Type: A data type is a classifier - similar to a class,[...] A data
%       type is shown using rectangle [...] A data type may contain attributes and
%       operations to support the modeling [...]
%
%       Enumeration:
%       [...] A list of enumeration literals may be placed, one to a line, in the 
%       bottom compartment. The attributes and operations compartments may be 
%       suppressed, and typically are suppressed if they would be empty.
%
%       poi: In UML Enumeration is a separate classifier in parallel to Class.
%       In Matlab it's a class with an enumeration block. Interface doesn't 
%       exist explicitly in Matlab. The closest is a special kind of abstract
%       class.
%
%       poi: 2020-05-04, in the current code the class, Enumeration, is parallel 
%       with Method, Property, etc., the instancies of which are children of 
%       instancies of Class. .... . At first glance it appears that Enumeration 
%       should rather have belonged to a group of classifier together with Class 
%       and Function.  
%       ------------------------------------------------------------------------   
%       m2uml: Lets place an Enum-compartment between the Method and the TodoFixme 
%       compartments. Enumerations don't have visibility. Suppress the Property and 
%       the Method compartments only if both are empty. 
%
%       Enumeration blocks may appear together with other blocks in classdef
%       files. A search for enumeration blocks in the Matlab code base together
%       with interactive inspection of files showed that classdef files with one
%       single enumeration block dominated. Second comes one single enumeration
%       block together with a methods block containing methods operating on the
%       enumeration members.
%       
%       PlantUML, Guide 3.15 Specific Spot assumes Enum classes indicated with (E).
%
%       m2uml: The existance of an enumeration block makes the class an Enum class.
%       In exceptional cases that might give an unwanted result, but so what.   
%       ------------------------------------------------------------------------   
%       Enumeration member names honor isvarname() - I assume.
%       Several enumeration blocks are allowed, but doesn't exist in the
%       Matlab code base.
%       Enumeration blocks don't have attributes.


    properties  ( Constant = true )             %
        
        %   NOTE: The function STRING is overloaded in the class, RequestMethod 
        %   c:\Program Files\MATLAB\R2018b\toolbox\matlab\external\interfaces
        %   \webservices\http\+matlab\+net\+http\RequestMethod.m

        %   The meta.class object includes a long list of methods for Enumeration, 
        %   which are not defined in the source code of the Enumeration class.  
        exclude_method_list = { 'cellstr','char','colon','eq','intersect','ismember'...
                            ,   'ne','setdiff','setxor','strcmp','strcmpi','string' ...
                            ,   'strncmp','strncmpi','union'                        };
        %
        block_head  = 'enumeration'; 
    end
    properties                                  %
        % Data used for the property code row
        data = struct(                              ...
                        'visibility'    ,  'public' ...      
                    ,   'isAbstract'    ,   false   ...
                    ,   'isStatic'      ,   false   ...
                    ,   'line'          ,   []      ...
                    ,   'tooltip'       ,   ''      ...
                    );
        % Value
        value
        % SourceFile instance, with the enumeration: ffs,fqn,type,namespace,basename
        source_file = m2uml.SourceFile.empty(1,0);
        %
        max_label_width
    end
    methods                                     %
        function    this = Enumeration( varargin ) %
            % Explicit constructor
            this@m2uml.Element( varargin{1:2} );
        end
    end
end
