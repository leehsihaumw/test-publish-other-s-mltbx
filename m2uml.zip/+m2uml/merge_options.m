function    out = merge_options( varargin )
% merge_options
%
%   Syntax
%       out = merge_options_( varargin )
%
%   Input
%       options     scalar struct that is field-equal to m2uml.factory_options
%       user        scalar struct that is a subset of m2uml.factory_options
%
%   Output
%       out         <1x1 struct> full m2uml option structure
%    
% Description: 

    out = m2uml.factory_options();
    
    for jj = 1 : length( varargin )
        out = merge_options_( out, varargin{jj} );
    end
end
function    out = merge_options_( options, user )
% merge_options_ replaces leaf values of options by the corresponding values of user         
%
%   Syntax
%       out = merge_options_( options, user )
%
%   Input
%       options     scalar struct that is field-equal to m2uml.factory_options
%       user        scalar struct that is a subset of m2uml.factory_options
%
%   Output
%       out         scalar struct that is field-equal to m2uml.factory_options
%
%   Description
%       Merges the struct, options, with the struct, user, by replacing leaf values of 
%       the struct, options, by the corresponding values of the struct, user. It  works  
%       recursively. An error is thrown if the struct, user, has a field that is not in
%       the struct, options. 
%
%   Example
%       user.Diagram.Monospaced         = true;
%       user.Diagram.LinetypeDefault    = false;
%       user.Diagram.TopToBottom        = false;
%       options = m2uml.merge_options_( m2uml.factory_options(), user );
%

% Inspired by the FEX-submissions, mergestruct, by Igor Kaufman
% (and Merge Options, by Matthew Kelly)

%   NOTE:   assert() that the fields of user is a subset of those of factory. 
%           'Unexpected name of user option, "%s"' isn't good enough.

    narginchk( 2, 2 )
    
    assert( isa( options, 'struct' )                    ...
        ,   'm2uml:merge_options_:WrongType'            ...
        ,   'The first input, "%s", shall be a struct'  ...
        ,   inputname( 1 )                              );
    
    assert( isa( user, 'struct' )                       ...
        ,   'm2uml:merge_options_:WrongType'            ...
        ,   'The second input, "%s", shall be a struct' ...
        ,   inputname( 2 )                              );
    
    out = options;
    
    user_field_names = fieldnames( user );
    
    for jj = 1 : length( user_field_names )
     
        user_name = user_field_names{jj};
        
        assert( isfield( options, user_name )           ...
            ,   'm2uml:merge_options_:UnexpectedName'   ...
            ,   'Unexpected name of user option, "%s"'  ...
            ,   user_name                               );
    
        user_value = user.(user_name);
        
        if isstruct( user_value )
            out.( user_name ) = merge_options_( options.(user_name), user_value );
        else
            out.( user_name ) = user_value;
        end
    end
end
