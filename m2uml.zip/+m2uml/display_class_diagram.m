function    varargout = display_class_diagram( varargin )   
% display_class_diagram displays an image file in a browser 
%
% Syntax: 
%       m2uml.display_class_diagram                 ...
%               (   'GraphicFile'   , graphic_file  ... required
%               ,   'UserOptions'   , user_options  ... optional
%               ,   'Viewer'        , viewer        ... optional
%               );
%
% Input:
%       graphic_file    full filespec of image file   
%       user_options    "subset" of the struct defined by m2uml.factory_options. The
%                       user_options structs has only the fields, the values of which
%                       differs from m2uml.factory_options.
%       viewer          a character row: 'web', 'browser' or 'webwindow'
%
% Output:
%       viewer          a character row, which was used for testing 
%
% Description:
%       m2uml.display_class_diagram displays an image file in a browser 
%
% Examples:
%     m2uml.display_class_diagram
%
% See also: m2uml.create_PlantUML_script, m2uml.puml2graphic,
%           m2uml.call_local_PlantUML, m2uml.run

    ipp = InputPreprocessor( {              
    ...   Name              Default value       Class       Constraint  
        3 'GraphicFile'     nan                 {'char'}    {'row'}
        3 'UserOptions'     struct([]) {'cell','struct'}    {}
        3 'Viewer'          ''                  {'char'}    {'row'}
        } );
    
    inv = ipp.parse( varargin{:} );
    
    %   Build an option stucture of input argument values 
    if not( isempty( inv.Viewer ) )
        arguments.General.Viewer = inv.Viewer;
    else
        arguments = struct([]);     
    end
    
    if isa( inv.UserOptions, 'struct' )
        options = m2uml.merge_options( inv.UserOptions, arguments );
    else
        if all( cellfun( @(uo) isa(uo,'struct'), inv.UserOptions ) )
            options = m2uml.merge_options( inv.UserOptions{:}, arguments );
        else
            error(  'm2uml:puml2graphic:CannotFindFile'                         ...
                ,   'The value of ''UserOptions'' is not a cell row of structs' )
        end
    end
    
    viewer  = options.General.Viewer;
    
    switch viewer
        case 'web'
            web( inv.GraphicFile, '-new' )
        case 'browser'
            web( inv.GraphicFile, '-browser' ) 
        case 'webwindow'
            w = matlab.internal.webwindow( m2uml.ffs2url( inv.GraphicFile ) );
            show( w )
        otherwise
            error(  'm2uml:IllegalValue'    ...
                ,   'No such Viewer: "%s"'  ...
                ,   viewer                  )
    end
    if nargout==1
        varargout = { viewer };
    end
end
