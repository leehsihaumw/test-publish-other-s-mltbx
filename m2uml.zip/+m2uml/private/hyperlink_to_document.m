function    str = hyperlink_to_document( varargin )
% hyperlink_to_document creates a hyperlink to display in the command window
%
%   See also: open_files, dir_regex
%
%   Ref: FEX/Hyperlink by Michele Scalseggi, Hyperlink2OpenFile

%   TODO: 
%   The predecessor, open_file_hyperlink, is lost.
%{
ffs = 'h:\m\PiaX\IDE_tools\has_documents_with_problems.m';
disp( hyperlink_to_document( ffs ) )
%}    
    persistent ipp
    if isempty( ipp )
        ipp = InputPreprocessor( {
            1 'Filespec'        ''  {'char'}    {'FileExist'}
            3 'Method'          ''  {'char'}    {'MatlabVarName'}
            3 'LineNumber'      []  {'double'}  {'scalar','positive'}
            } );
    end
    ipv = ipp.parse( varargin{:} );

    isDocument  =     isempty( ipv.Method )  &&     isempty( ipv.LineNumber );
    isMethod    = not(isempty( ipv.Method )) &&     isempty( ipv.LineNumber );
    isLine      =     isempty( ipv.Method )  && not(isempty( ipv.LineNumber ));
    isIllegal   = not(isempty( ipv.Method )) && not(isempty( ipv.LineNumber ));
    
    [~,file_name] = fileparts( ipv.Filespec ); 
    if  isDocument  
        fmt = 'matlab.desktop.editor.openDocument(''%s'');';
        cmd = sprintf( fmt, ipv.Filespec );
        lbl = file_name;
    elseif isMethod
        fmt = 'matlab.desktop.editor.openAndGoToFunction(''%s'',''%s'');';
        cmd = sprintf( fmt, ipv.Filespec, ipv.Method ); 
        lbl = sprintf( '%s.%s', file_name, ipv.Method ); 
    elseif isLine
        fmt = 'matlab.desktop.editor.openAndGoToLine(''%s'',''%d'');';
        cmd = sprintf( fmt, ipv.Filespec, ipv.LineNumber ); 
        lbl = sprintf( '%s/%d', file_name, ipv.LineNumber ); 
    elseif isIllegal
        error(  'hyperlink_to_document:IllegalInputValues'                      ...
            ,   'At least one of method, "%s", and line, "%d", must be empty'   ...
            ,   ipv.Method, ipv.LineNumber ) 
    else
        error( 'hyperlink_to_document:InternalError', 'A bug is encountered' )
    end
    str = sprintf( '<a href="matlab:%s">%s</a>', cmd, lbl );   
end
