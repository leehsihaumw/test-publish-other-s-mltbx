function    H1 = get_H1_line( ffs, fcn_name )                   %
% get_H1_line gets the first comment line of the help text of fcn_name 
%
% Syntax: 
%       H1_line = get_H1_line( ffs ); 
%       H1_line = get_H1_line( ffs, fcn_name ); 
%
% Input Parameters:
%       ffs         filespec of classdef-file, function-file, method-file in class folder
%       fcn_name    method-name or subfuction-name      
%
% Output parameters:
%       H1          H1-line
%
% Description:   
%
% Examples:
% NOTE: The help section is not complete
% NOTE: 2018-08-25, added functionality for scripts; return first comment-line 
%
%   See also: xtests\mylib_test, getdescription 
%   C:\Program Files\MATLAB\R2018b\toolbox\matlab\reports\private\getdescription.m  % Private to reports
%   helpfunc  built-in (undocumented)

%   Folders Containing Class Definitions
%   http://uk.mathworks.com/help/matlab/matlab_oop/organizing-classes-in-folders.html
%   -   Path folders    class definitions in a single "classdef-file"
%   -   Class Folders   class definitions in a single "classdef-file" together with 
%                       additional zero or more method files. A Class Folder contains 
%                       the definition of exactly one class.   
%
%   A Class Folder may contain a PRIVATE folder. All main functions in the private
%   folder are private methods of the class, i.e. equivalent to (Access=private).
%
    narginchk( 1, 2 )

%   TODO:   Reduce the requirements on ffs, which are
%           1. ffs must be in the Matlab path 
%           2. which( fully_qualified_module_name ) must return ffs.
    
    [~,~,ext] = fileparts( ffs );
    if isempty( ext )
        ffs = which( ffs );
    end
    
    type     = fqn2type( ffs2fqn( ffs ) );    
    isClass  = strcmp( type, 'class' );   
    row_list = read_and_trim_souce_code_( ffs, type ); 
    [~,file] = fileparts( ffs );   % file – base name of the file
   
%   One input argument: Search H1-line of classdef or function, i.e first comment line 
%   after the classdef/function statement.
    if nargin == 1
        if ismember( type, {'class','function'} )
            xpr = [ '^\s*((function)|(classdef)).+?', file ];  % specific enough(?)
            num = regexp( row_list{1}, xpr );
            assert( not(isempty(num)) && num==1     ...
                ,   'get_H1_line:SyntaxError'       ...
                ,   'Illegal line: "%s"', num       )
            H1  = extract_H1_line_( row_list{1+1} );
        elseif ismember( type, {'script'} )
            H1  = regexp( row_list{1}, '(?<=^\s*%\s*).*$', 'match' ); 
            H1  = strtrim( H1{:} );
        else
            keyboard
        end
        return                                                      %   RETURN     
    end
   
%   Two input arguments:   
%   xpr = [ '^\s*(function)[^%]+?', fcn_name ];
    xpr = regex.concrete_method_name( fcn_name );
%   TODO: "files" is a misleading name    
    files = regexp( row_list, xpr );    
    isv = not( cellfun( @isempty, files ) );
    ixf = find( isv, 1, 'first' );
    
%   Several cases ...
    if isempty( ixf )   % No method/function named "fcn_name" found in the file
        %   1. Implicit contructor of class
        if isClass && strcmp( file, fcn_name )
            H1 = 'Implicit constructor';
            return                                                  %   RETURN     
        end
        
        %   2. Method is defined in a separate file in a class folder
        pth = fileparts( ffs );
        sad = dir( fullfile( pth, [fcn_name,'.m'] ) );
        if not(isempty( sad )) 
            ffs = fullfile( pth, sad.name );
            
            rws = read_and_trim_souce_code_( ffs, 'function' ); 
            H1  = extract_H1_line_( rws{2} ); 
            return                                                  %   RETURN     
        end
               
        %   3. Method is defined in a superclass
        %   In reponse to comment 9 Aug 2017 by Andrew Joslin in FEX/m2uml
        fqn = ffs2fqn( ffs );
        mcc = meta.class.fromName( fqn );
        mcm = mcc.MethodList;
        ism = strcmp( {mcm.Name}, fcn_name );
        if any( ism )
            H1  = sprintf(  'The method, %s, is defined in %s'  ...
                        ,   fcn_name, mcm(ism).DefiningClass.Name );
            return                                                  %   RETURN
        end
        
        error(  'get_H1_line:CannotFindFncName'         ...
            ,   'Cannot find function, "%s", in "%s"'   ... 
            ,   fcn_name, ffs                           )
    end
    
    assert( length(ixf)==1, 'get_H1_line:TooMany'   ...
        ,   'More than one function, "%s", in "%s"' ...
        ,   fcn_name, ffs                           )
    
    H1  = extract_H1_line_( row_list{ixf+1} );
end
function    rws = read_and_trim_souce_code_     ( ffs, type )   %

%   TODO: read_and_trim_souce_code_ does not preserve the line numbers. The
%   length of rws is shorter than the file. I recall, I have written a similar
%   code that preserves the line numbers. However, I cannot find that code now.

    fid = fopen( ffs );
    cac = textscan( fid, '%s', 'Delimiter','\n');
    [~] = fclose( fid );
    rws = strtrim( cac{1} );
    
%   Remove empty lines
    ise = cellfun( @isempty, rws );
    rws( ise ) = [];
    
%   Remove empty comment lines 
    xpr = '^%[% ]*$';
    cac = regexp( rws, xpr );
    isc = not( cellfun( @isempty, cac ) );
    rws( isc ) = [];

%   TODO: Remove multi-line comments. See KeywordSearch>remove_multiline_comments_

    if ismember( type, {'class','function'} )
    %   Remove leading comments, i.e. comments before any code (not needed(?))
        xpr = '^%.*';
        cac = regexp( rws, xpr );
        ixf = find( cellfun( @isempty, cac ), 1, 'first' );
        rws( 1 : ixf-1 ) = [];
    else
    %   Remove all non-comment-lines
        isc = startsWith( strjust( rws, 'left' ), '%' );
        rws( not( isc ) ) = [];
    end
    
%   Concatenate continuation lines ...   
%   TODO: Rows with only space and ... might cause problems 
    xpr = '^(?:\s*[^%].+)(\.{3})';
    cix = permute( regexp( rws, xpr, 'tokenExtents' ), [2,1] );
    ixr = find( not( cellfun( @isempty, cix ) ) );
% TODO: Comment needed. I don't get the meaning of the following for-loop    
    len = length( rws );
    for rr = fliplr( ixr )
        if rr == len,   continue                                        %   CONTINUE
        end
        cc = cix{rr}{1}(1);
        rws{rr  } = [ rws{rr}(1:cc-1), rws{rr+1} ];
        rws(rr+1) = [];
    end
end
function    H1  = extract_H1_line_              ( row_str   )   %
    cac = regexp( row_str, '^(?:%+)(?:\s*)(\S.+)$', 'tokens', 'emptymatch' );
    if not( isempty( cac ) )
        H1 = cac{1}{1};
    else
        H1 = 'No H1-line';
    end
end
