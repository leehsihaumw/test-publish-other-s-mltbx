function    isf = isflint( vec )
% isflint determines if input is a vector of floating point integers 
%
%   Input
%       m   vector of doubles 
%
%   Output
%       isf     <1x1 logical>
%
%   See also: isAllFlint
   
%   http://www.mathworks.com/company/newsletters/news_notes/pdf/Fall96Cleve.pdf
%   JanSimon: http://www.mathworks.se/matlabcentral/answers/67247-about-isinteger- ...
%       command-confusion#answer_78914   

    assert( isa( vec, 'double' ) && isvector( vec ) ...
        ,   'isflint:IllegalInput'                  ...
        ,   'The input should be a double vector'   )

    isf =   all( abs(   vec ) <= flintmax ) ...
        &&  all( floor( vec ) == vec      ) ; 
end
% TODO: Return vector: isf = abs(vec)<=flintmax & floor(vec)==vec; Call all(isflint)
%       See Answers: Integer check, Stephen Cobeldick on 16 Sep 2019, This could be
%       trivially vectorized: why force it to return a scalar?
