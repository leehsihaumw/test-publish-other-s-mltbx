function    varargout = convertStringsToChars_substitute( varargin )
% Convert string arrays to character arrays and leave others unaltered.

    assert( nargout == nargin, 'The number of outputs and inputs shall be equal' )

    len = nargin; 
    varargout = cell( 1, len );
    
    for jj = 1 : len
        val = varargin{jj};
        if isstring( val ) 
            if isscalar( val )
                varargout{jj} = char( val );
            else
                [ R, C ] = size( val );
                cac = cell( R, C );
                for rr = 1 : R
                    for cc = 1 : C
                        cac{rr,cc} = char( val(rr,cc) );
                    end
                end
                varargout{jj} = cac;
            end
        else
            varargout{jj} = val;
        end
    end
end
