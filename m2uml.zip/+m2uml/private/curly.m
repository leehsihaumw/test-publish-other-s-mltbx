function    out = curly( root, varargin )
% curly extracts values from nested structures and cell arrays, respectively.
%
%   FORCE: When working with the meta.MetaData class one frequently encounters
%   nested structures. To get a list of objmeta.EventList.DefiningClass.Name
%   Either
%       out = cellfun( @(obj) obj.Name, {objmeta.EventList.DefiningClass}, 'uni',false );
%   or
%       out = curly( objmeta.EventList, 'DefiningClass', 'Name' ) 
%
%   The first statement is more difficult to create and understand than the second.
%   Adding another property to the train wreck increases the difference. 

%   Is curly a good idea? 
%   Jan isn't sure, https://se.mathworks.com/matlabcentral/answers/
%   329538-why-do-i-get-this-error-for-this-non-scalar-structure#answer_258672
%   Argument against: X = A(:).B.C(:).D(:).E

%   Two function forced into one, because I like the name curly.

%   TODO: Create bracket() that returns an array.
    
    narginchk( 2, inf )
    
    if isstruct( root ) || isobject( root )
        if length(varargin) >= 2 
            out = curly_of_structure_( root, varargin{:} );
        else
            out = { root.( varargin{1} ) }; 
        end
    elseif iscell( root )
        out = curly_of_cell_array_( root, varargin{:} );
    else
        out = nan;
    end
end
function    out = curly_of_cell_array_( root, varargin )
    
%   This is a minimal code to make CRL_cell_array_21_test and CRL_cell_array_22_test pass.

    num = [varargin{:}];
    assert( isflint( num ), 'poi:curly:NotAllFlint'     ...                     ...
        ,   'Second argument and beyond must be flints' )
    
    out = root(:,num(1));
    
    for jj = num( 2 : end )
        out( cellfun(@isempty,out) ) = [];  % poi: 2020-01-14,
        out = cellfun( @(cac) cac{num(jj)}, out, 'uni',false );
    end
end
function    out = curly_of_structure_( root, varargin )
%    
%   SYNTAX
%       out = curly( root, name1, name2, name3, ... )
%
%   INPUT
%       root        a vector of objects or structures   
%       name_       a comma delimited list of names of properties or fields
%
%   OUTPUT
%       out         cell array of values of properties or fields    
%
%   See also: mylib_test
    
    if  isscalar( root )
        nested_depth = length( varargin );      % Access Data in *Nested* Structures
        argument_len = nan( 1, nested_depth ); 
        for jj = 1 : nested_depth               % DRY, c.f. number_of_names_()
            if isstring( varargin{jj} )         % String array
                argument_len(jj) = numel( varargin{jj} );
            elseif iscellstr( varargin{jj} )    % Cell array of character vectors
                argument_len(jj) = numel( varargin{jj} );
            elseif ischar( varargin{jj} )       % Character vectors
                argument_len(jj) = 1;
            else
                error(  'poi:curly:IllegalInput'                                    ...
                    ,   'Something is wrong with the class of the %d:th input', jj+1 ) 
            end
        end
        
        is_name_array = argument_len >= 2;
        
        assert( sum( double( is_name_array ) ) <= 1         ...
            ,   'poi:curly:TooManyNameArrays'               ...
            ,   'Input contains more than one name array'   )
            
        if any( is_name_array )
            out = multiple_fields_( root, varargin{:} );
        else    % Why calling curly in this case?
            out = root;
            for jj = 1 : nested_depth
                out = out.(varargin{jj});
            end
            out = {out};
        end
    else
        out = array_root_( root, varargin{:} );
    end
end
function    out = array_root_( root, varargin )
    len = length( root );
    out = cell( 1, len );
    
    for jj = 1 : len
        tmp = root(jj);
        for ii = 1 : length( varargin )
              tmp = tmp.(varargin{ii});
        end
        out{jj} = tmp;
    end
end
function    out = multiple_fields_( root, varargin )
    
    nNames = cellfun( @number_of_names_, varargin, 'uni',true );
    
    out = cell( 1, max(nNames) );
    
    tmp = root;
    ix  = find( nNames >=2 );
    if ix >= 2
        tmp = getfield( tmp, varargin{1:ix-1} );                            %#ok<GFLD>
    else
        % do nothing
    end
    for jj = 1 : max(nNames)
        out{jj} = getfield( tmp.(varargin{ix}{jj}), varargin{ix+1:end} );   %#ok<GFLD>
    end
end
function    n = number_of_names_( str )
    
    if isa( str, 'char' )
        n = 1;
    elseif isa( str, 'cell' )
        n = length( str );
    elseif isa( str, 'string' )
        n = length( str );
    end
end
%% Left over
