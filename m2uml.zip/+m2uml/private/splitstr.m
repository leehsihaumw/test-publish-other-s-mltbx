function    [ str1, str2 ] = splitstr( str, pos )
% splitstr splits a string in two substrings
%
% Syntax:
%    [ str1, str2 ] = splitstr( str, pos )
%
% Inputs:
%    str -  <1x1 string>
%    pos -  <1x1 double>
%
% Outputs:
%    str1 - <1x1 string>    The leading part of str including position, pos
%    str2 - <1x1 string>    The remaining part of str after position, pos
%
% Example: 
%    
%
% See also:
%    
    narginchk( 2, 2 )
    
    xpr = sprintf( '^(.{%d})(.+)$', pos );
    str = regexp( str, xpr, 'tokens','once' );
    
    str1 = str(1);
    str2 = str(2);
end
