function    varargout = convertCharsToStrings_substitute( varargin )
% Convert character arrays to string arrays and leave others unaltered.
    
    assert( nargout == nargin, 'The number of outputs and inputs shall be equal' )

    len = nargin; 
    varargout = cell( 1, len );
    
    for jj = 1 : len
        val = varargin{jj};
        if  iscellstr( val )                %#ok<ISCLSTR>
            varargout{jj} = string( val );
        elseif ischar( val )
            varargout{jj} = string( val );
        else
            varargout{jj} = val;
        end
    end
end
