function    str = txt2str( inarg1, nbytes )
% txt2str returns the content of a text file as a string, row vector. LF for newline.
%
%   str = txt2str( filespec )    returns the content of the text file filespec
%   str = txt2str( filespec, n ) returns the first n bytes of the content of filespec
%
%   The code mimics Matlab fileread. The file is opened in text mode, 'rt', thus 
%   '\r\n' is automatically replaced by '\n'. Force: simplify regular expressions. 
%
%   See also fread, fileread, matlab.internal.getCode

    narginchk(1,2);
    if nargin == 1
       nbytes = inf; 
    end
    inarg1 = convertStringsToChars( inarg1 );
    
    if isa( inarg1, 'char' )  && isrow( inarg1 )        % filespec
        assert( not( isempty( inarg1 ) )    ...
            ,   'pia:str2txt:emptyFilename' ...
            ,   'Empty filespec'            ); 

        [fid, msg] = fopen( inarg1, 'rt' );
        assert( fid >= 1                        ...
            ,   'pia:str2txt:cannotOpenFile'    ...
            ,   'Cannot open "%s", because %s'  ...
            ,   inarg1 , msg );
        
    elseif isa( inarg1, 'numeric' )     ...             % file identifier
    && isscalar( inarg1 )               ...
    && not( isempty( fopen( inarg1 ) ) )
        fid = inarg1;
    else
        error('pia:str2txt:IllegalInarg'...
            , 'Illegal input: "%s"'     ...
            , value2short( inarg1 )     )
    end
    
    try
        % TODO: replace permute()
        str = permute( fread( fid, nbytes, '*char' ), [2,1] );
        % close the file if it's opened in this function, otherwise don't
        if ischar( inarg1 )
            fclose(fid);
        end
    catch me
        % close file
        fclose(fid);
        throw(me);
    end
end
