function    variable_not_used( varargin )       
% variable_not_used - helps keep the code analyzer box green  
end