function    class_base_name = fcn( obj )
% fcn returns the class base name of the object. The short name is a feature.

    cac = strsplit( class( obj ), '.' );
    class_base_name = cac{end};
end
