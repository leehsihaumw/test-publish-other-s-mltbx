function    varargout = dbhex( str )
%
% >> dbhex A
% >>>     \x41  <<< put on clipboard
% >> dbhex \x41
% >>>       A   <<< put on clipboard
    
% TODO: neither "dbhex ' " nor "dbhex '' " works correctly. 
%     dbhex '
%      dbhex '
%            ?
%     Error: Character vector is not terminated properly.
%
%     dbhex ''
%     >>>     \x  <<< put on clipboard

    if nargin == 0
        str = '[\w\x5D\x29\x7D\x2E]';
    end
    if nargin==1 && isempty(str)
        str = '''';
    end
    if isnumeric( str )
        str = sprintf( '%02d', str );
    end
    
    cac = regexp( str, '(\\x\d[\dA-Fa-f])', 'tokenExtents' );   % is character entity
    
    if isempty( cac )
        buf = dec2hex( double( str ) );
        buf = mat2cell( buf, ones(1,size(buf,1)), size(buf,2) );
        out = sprintf( '\\x%s', buf{:} );
    else
        out = str;
        
        buf = cellfun( @(num) reshape(num,[],1), cac, 'uni', false );
        tok_ext  = cell2mat( buf );
        
        for jj = 1 : size( tok_ext, 2 )
            dec = hex2dec( str( tok_ext(1,jj)+2 : tok_ext(2,jj) ) );
            out( tok_ext(1,jj) : tok_ext(2,jj) ) = sprintf( '  %1c ', char( dec ) );
        end
    end
    
    if nargout == 0
        clipboard( 'copy', out )
        fprintf( '>>>     %s  <<< put on clipboard\n', out );
        varargout = cell(0);
    else
        varargout = { out };
    end
end
% sprintf( '%02X', 255 )
% ans =
% FF
% sprintf( '\\x%02X', double('A') )
% ans =
% \x41
