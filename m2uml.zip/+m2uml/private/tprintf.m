function    out = tprintf( ffs, format, varargin  )
% tprintf writes column-oriented data to a tabular text file. 
% 
% Syntax:        tprintf( ffs, format, A1, A2, ..., An )
%          out = tprintf( ffs, format, A1, A2, ..., An )
%
% Inputs:
%   ffs     <1xn char>      file specifier. (tprintf overwrites an existing file.)
%           <1x1 double>    file identifier  
%           <1x1 double>    1/2 displays the results on the screen
%           <1x1 double>    [], empty, ... 
%   format  <1xm char>      formatting operator (same as with fprintf)
%
%   A1,A2,  <Nxk ... >      numeric matrix, cell array or character array. Columns in 
%                           matrices and arrays are written to columns in the text file. 
%                           A character array is written to one column in the text file.
%
% Outputs:
%   out     <1xn char>      character vector, "map" of the output text file   
%
% Description:
%   tprintf( filespec, format, A1, ..., An ) creates a tabular text file by writing the 
%   columns of A1,...,An to columns in the text file.
%
%
% Example: 
%
%   tprintf( 1, '%d, %4.1f, %s, %s\n', [1;2], rand(2,1),{'first';'second'},['ABC';'DEF'] ) 
%   tprintf( 1, '%4.2f, %4.2f, %4.2f\n', rand(4,1),rand(4,1),rand(4,1) ) 
%   tprintf( 1, '%5.3f\n', rand(6,1) ) 
%
%   N   = 5;
%   ffs = 'c:\tmp\tprintf.txt';
%   f3  = rand( N, 3 ) * 3;
%   i1  = ones( N, 1, 'int8' );
%   cs1 = {'ABC';'DEF';'GHI';'JKL';'MNO'};
%   s1  = ['MNO';'PQR';'STU';'VWX';'YZZ'];
%   cs2 = cat( 2, cs1, lower(cs1) );
%   tprintf( ffs, '%s, %d, %s, %f, %f, %f, %s, %s\n', cs1, i1, s1, f3, cs2 );
%
% See also: fprintf, h:\m\PiaX\xtests\mylib_test.m

% Tabular text is ASCII text arranged in rows and columns, separated by characters. 

% https://uk.mathworks.com/matlabcentral/answers/355189-how-fprintf-cell-array-and-martix
    
%   SURPRISE: tprint is three times as fast as csvwrite (and dlmwrite) writing a 
%   <1e5x8 double>.
%
%   mylib_test, QPR_large_8num_csvwrite_timing_test 
%   num = rand( 1e5, 8 );
%
%   Failure   // Elapse time: tprintf,csvwrite //  
%         Type: 'equal'
%       Actual: 2.0574
%     Expected: 6.4201
%

%   It seems as if the special handling, i.e. data2num_, of the pure double matrix case
%   shortens the execution time by a third.

%   WISH: How can I view numeric array elements in edit text box, in a GUI?
%     97      nbytes = fprintf( fid, format, OUT{:} ); 
%     K>> str = sprintf( format, OUT{:} )
%     str =
%     1,  0.1, first, ABC
%     2,  0.9, second, DEF
%     numel(str)
%     ans =
%         41
%
%   TODO: It would be simple to return a string from tprintf. Why not 'TooltipString'
%   TODO: Scalar expansion. A scalar in the list of columns may be expanded. 
%   DONE: 2019-09-06, Most tests, mylib_test>TPR_..., throw the error, 
%           Error in tprintf>data2cell_ (line 203)
%           OUT( nix : nix+szs(2,jj)-1, : ) = cac;
%       which is because of reshape() where it should be and was permute(). That is most
%       likely because I made a "global" change from permute() to reshape(). During a
%       period had misused permute() to change between <1xk> and <kx1>. See Baclog.m
%   %%  TODO: permute( ___, 2,1 ); I've used it in hundreds of cases to convert between .
%  
%         h:\m\BestPractices\mylib_sandbox\tbx\mylib\ 2019-09-05 23:23:40 9 KB  Fixed
%         h:\m\PiaRepos\mylib\                        2018-08-18 05:41:06 9 KB  not fixed
%         h:\m\FEX\Upload\tprintf\                    2017-09-12 02:09:35 8 KB  Ok

    if not( strcmp( format(end-1:end), '\n' ) )
        format = cat( 2, format, '\n' );
        warning('newline, \n, added to the end of the format specifier')
    end

    if  all( cellfun( @isfloat,   varargin ) )  ...     interprets left to right
    ||  all( cellfun( @isinteger, varargin ) )  ...
    &&  isscalar( unique( cellfun( @class, varargin, 'uni',false ) ) )
        OUT = { data2num_( varargin{:} ) };
        row_len = size(OUT{:},1);
    else
        OUT = data2cell_( varargin{:} );
        row_len = size(OUT,1);
    end
    
    %   the number of row of OUT, shall be equal to the number of "%" in the format
    %   string. 
    assert( eq( length(strfind(format,'%')), row_len )  ...
        ,   'tprintf:FormatspecMismatch'                ...
        ,   'The format, "%s", doesn''t match data'     ...
        ,   format                                      )
    
    out = sprintf( format, OUT{:} );
    if not( isempty( ffs ) )
        if ischar( ffs )
            fid = fopen( ffs, 'wt' );       % 2017-09-13, poi: 'wt'
            assert( fid >= 1, 'tprintf:CannotOpenFile', 'Cannot open "%s"', ffs );
            close_fid = true;
        elseif isfid_( ffs )
            fid = ffs;
            close_fid = false;
        elseif ismember( ffs, [1,2] )         % "stdout","stderr"
            fid = ffs;
            close_fid = false;
        else
            error(  'tprintf:IllegalValue'                  ...
                ,   'Illegal value of file specifier: %s'   ...
                ,   value2short( ffs )                      )
        end

        [~] = fprintf( fid, format, OUT{:} ); 
        if close_fid
            fclose( fid );
        end
    end
end
function    OUT = data2num_( varargin )     %
    
    cac = cellfun( @size, varargin, 'uni',false );
    
    assert( all( cellfun( @ismatrix, cac ) )    ...
        ,   'tprintf:NotAllMatrix'              ...
        ,   'All data inputs are not matrices'  )
    
    szs = cell2mat( cac );
    szs = reshape( szs, 2, [] );        % "2" is the number of dims of a matrix
    
    col_len = unique( szs( 1, : ) );    % "col" and "row" refers to the final text file
   
    if not( isscalar( col_len ) )
        error(  'tprintf:NotEqualLength'                          ...
            ,   'The length of all data inputs are not equal: %s' ...
            ,   value2short( col_len )                            )
    end

    row_len = sum( szs( 2, : ) );
    
    if length(varargin) == 1
        OUT = permute( varargin{1}, [2,1] );    
    else
        OUT = nan( row_len, col_len );
        nix = 1; % next ix
        for jj = 1 : length(varargin)
            OUT( nix : nix+szs(2,jj)-1, : ) = permute( varargin{jj}, [2,1] );
            nix = nix + szs(2,jj);
        end
    end
end
function    OUT = data2cell_( varargin )    %
    
    cac = cellfun( @size, varargin, 'uni',false );
    
    data_classes = cellfun( @class, varargin, 'uni',false );

    assert( all( cellfun( @ismatrix, cac ) )    ...
        ,   'tprintf:NotAllMatrix'              ...
        ,   'All data inputs are not matrices'  )
    
    szs = cell2mat( cac );
    szs = reshape( szs, 2, [] );    % "2" is the number of dims of a matrix
    
    col_len = unique( szs( 1, : ) );
   
    if not( isscalar( col_len ) )
        error(  'tprintf:NotEqualLength'                          ...
            ,   'The length of all data inputs are not equal: %s' ...
            ,   value2short( col_len )                            )
    end
    %   In this case assert is significantly slower than if-error-end, because it
    %   evaluates(?) value2short(col_len) even when the condition is true.
    %   assert( isscalar( col_len ),  'tprintf:NotEqualLength'    ...
    %       ,   'The length of all data inputs are not equal: %s' ...
    %       ,   value2short( col_len )                            )

    %   A character matrix is printed to one column, regardless of the number of
    %   characters per row
    szs( 2, strcmp(data_classes,'char') ) = 1;
    row_len = sum( szs( 2, : ) );
    
    OUT = cell( row_len, col_len );
    nix = 1; % next ix
    
    for jj = 1 : length(varargin)
        
        if isa( varargin{jj}, 'numeric' )
            num = permute( varargin{jj}, [2,1] );
            cac = num2cell( num );
        elseif iscellstr( varargin{jj} )
            cac = permute( varargin{jj}, [2,1] );
        elseif isa( varargin{jj}, 'char' )
            sz  = size( varargin{jj} );
            cac = mat2cell( varargin{jj}, ones(1,sz(1)), sz(2) ); 
            cac = permute( cac, [2,1] );
        else
            error(  'tprintf:IllegalType'   ...
                ,   'Illegal type of "%s"'  ...
                ,   in_(jj+2,inputname(jj+2)) )
        end
        OUT( nix : nix+szs(2,jj)-1, : ) = cac;
        nix = nix + szs(2,jj);
    end
end
function    isf = isfid_( fid )             %
   
    if  isflint( fid )                  ...
    &&  not( isempty( fopen( fid ) ) )  ...
    &&  not( ismember( fopen(fid), {'"stderr"','"stdout"'} ) )
        isf = true;
    else
        isf = false;
    end
end
function    str = in_( ix, str )            %
%   When an expression is used as an input, inputname returns an empty string. in_
%   replaces this empty string with something meaningful. The short name "in_" is 
%   chosen to make it fit in the function, assert.
%
%   Examples
%   in_(3,inputname(3))           
%   in_(jj+2,inputname(jj+2))

    if isempty( str )
        str = sprintf( 'input_%d', ix );
    end
%   % My first approach failed!  
%   function    str = inputname_( ix )    % good try
%       str = evalin( 'caller', sprintf( 'inputname(%d);', ix ) );
%       Error using inputname
%       Cannot return input name if not in an active function.    
%   end
end
