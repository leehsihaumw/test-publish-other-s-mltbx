function    type = fqn2type( fqn )
% fqn2type takes a fully qualified name, fqn, (or ffs) and returns its module type, 
% i.e. 'class'|'function'|'script'|'external_method' 
%
% fqn shall be on the search path
%
% See also: exist, isClassdef, ffs2fqn

% See Answer: Walters answers to "How to implement isClassdef(filespec) ... " and
%             "Is there a term for "mypack.mysubpack.myFcn"?"  
% See Blog: What Kind of MATLAB File is This? by Loren Shure, August 26, 2013
% Undocumented: Function definition meta-info, mtree
 
    ffs = which( fqn );
    if isempty( ffs )
        % TODO: 2018-06-13, Better handling of empty ffs.
        warning( 'poi:fqn2type:CannotFind', 'Cannot find: %s', fqn )
        type = '';
        return                                                              %   RETURN
    end
    
%   if exist( file, 'class' ) == 8
    tree = mtree( ffs, '-file' );
    if  tree.count >= 1 
        if strcmp( tree.select(1).kind, 'CLASSDEF' )
            type = 'class';
        else
            try
                % narging.m says: "FUN can be [...] a character vector or string scalar
                % that contains the name of that function." That's an obscure way of
                % saying that FUN may be a full filespec of an external method.
                nargin( ffs );
                if any( ffs == '@' )           % 2020-08-01, SourceFile.external_method
                    type = 'external_method';
                else
                    type = 'function';
                end
            catch me 
                if strcmp( me.identifier,'MATLAB:nargin:isScript' )
                    type = 'script';
                else
                    rethrow( me )
                end
            end
        end
    else
        type = 'script';
    end
end
% Left over
