function    [ fqn, path_folder, namespace, basename, ext ] = ffs2fqn( filespec )
% ffs2fqn takes a filespec and returns the fully qualified name of the modules, i.e 
% a class, a function or a script. Approx: the reverse of WHICH regarding m-files.
%
% Syntax:  
%   [ fqn, path_folder, namespace, basename, ext ] = ffs2fqn( filespec )
%   
% Output parameters:
%   fqn             <1xn char>      fully qualified name of module
%   path_folder     <1xn char>      the folder, which contains the module, fqn
%   namespace       <1xn char>      
%   basename        <1xn char>
%   ext             <1xn char>
%
%
%   See also: fqn2type, m2uml\private\filespec2namespec, h:\m\PiaX\xtests\mylib_test.m

%   NOTE, 2018-04-04: Fully qualified name, quickly said it seems to be a good idea.
%   However, external methods files; private files especially those in class folders; 
%   and more. 
%
%   External methods: ffs2fqn is about modules on the search path. However, profile 
%   causes problems because not all display entries are on the search path. 

%   TODO: [ fqn, path_folder, namespace, ext ] and ...\@cls1\private\@cls2\cls2.m
%   2018-02-25: QuickDepfun line 110: [ fqn, folder, ext ] = ffs2fqn( caStr_In{jj} ); is 
%   the only call, which uses more than one output argument according to FileLocator Lite.
%   Thus, it's permissible to change the signature.

    [ fqn, path_folder, namespace, basename, ext ] = ffs2fqn_( filespec );

end
function    [ fqn, path_folder, namespace, basename, ext ] = ffs2fqn_( filespec )
%
%   ffs2fqn_ doesn't include any checks regarding the Matlab path or the existence of
%   files.
namespace = 'dummy';
%%  Packages Create Namespaces (excerpts)
%   Packages are special folders that can contain class folders, functions, and class
%   definition files, and other packages (, but not ordinary "Path folders". What about
%   private folders?)
%
%%
%   TODO: Replace m2uml\private\filespec2namespec by ffs2fqn in ClassNode and
%         Relationship
%
%{
[ fqn, folder ] = ffs2fqn( 'h:\m\PiaRepos\m2uml\+m2uml\PlantUmlAdapter.m' );
[ fqn, folder ] = ffs2fqn( 'h:\m\PiaRepos\m2uml\+m2uml\run.m' );
[ fqn, folder ] = ffs2fqn( 'h:\m\FEX\InUse\@stop\stop.m' );
[ fqn, folder ] = ffs2fqn( 'h:\m\FEX\InUse\TreeDataStructure\@tree\tree.m' );
[ fqn, folder ] = ffs2fqn( 'h:\m\PiaRepos\m2uml\lib\uml2doc.m' );
%}

%   TODO: assert that the value of filespec is "The combination of drive letter, path, 
%   and filename that identifies a file uniquely to the operating system",[DRDOS].

%   TODO: 2018-02-10, Undocumented behavior: nested class folders, private folders
%   Doc: Folders Containing Class Definitions, Using Class Folders, A class folder name
%   always begins with the @ character followed by the class name [...]. A class folder
%   must be contained in a path folder, but the class folder is not on the MATLAB path.
%
%   class folder in class folder
%   ...\datamanager\@datamanager\@brushmanager\updateVars.m
%   >> obj = datamanager.brushmanager 
%   obj =
%       datamanager.brushmanager
%
%   NOTE: 2018-02-13, nested class folders relies on "schema" and is not for me. 
%     matlabroot\R2016a\toolbox\matlab\datamanager\@datamanager\@brushmanager\schema.m
%     function schema
%     % Copyright 2008-2010 The MathWorks, Inc.
%     % Register class 
%     c = schema.class(findpackage('datamanager'),'brushmanager');
%
%   ffs2fqn('h:\m\Pia\Pia2\piaUnit\dbch_files\@dbch_class_3_0\private\private_function.m')
%   returns dbch_class_3_0.private>private_function
%
%   NOTE: 2018-02-13, Conclusion from experiment: packages are not allowed in class
%   folders 
%
%   NOTE: mlint said: class cannot be defined in private folder  
%
%   TODO: 2018-02-10, what about static methods? ffs2fqn is about modules

    cac = regexp( filespec, ['(?<=\',filesep,')[\x2B\x40]'], 'match' );     % [+@]
    special_characters = strjoin( cac, '' );
    if isempty( special_characters )
        %   No package or class folders
        [ path_folder, fqn, ext ] = fileparts( filespec );
        namespace = '';
        basename  = fqn;   
        return                                                          %   RETURN
    elseif isempty( regexp( special_characters, '^[+]*[@]?$', 'once' ) )
        %   Assumption: Only one class folder is allowed in a filespec; nested class
        %   folders are not allowed. A package folder cannot be subfolder of a class
        %   folder. Thus, special_characters contains zero or more '+' followed by 
        %   zero or one '@'. xpr = '[+]*[@]?';
        %
        %   Doc (Folders Containing Class Definitions): No Class Definitions in Private
        %   Folders You cannot put class definitions in private folders because doing so 
        %   would not meet the requirements for class or path folders.
        keyboard % NOTE: special characters in the wrong order
        return                                                          %   RETURN
    else
        %   Do nothing, just continue down the function
    end
    
    %   TODO: implement and verify ...\+pkg\private\my_module and
    %   ...\@pkg\private\my_module, ...\+dbch_files\@dbch_class_3_0\dbchMethod.m
    %
    
    % Split at first [+@]. Keep the [+@] with the second token
    ca1 = regexp( filespec, '^([^\x2B\x40]*)([\x2B\x40].+)$', 'tokens' ); 
    
%   TODO: this construct, previous regexp, leaves filesep, "\", as the last character of
%   path_folder. Matlab's fileparts doesn't include the trailing filesep. The tests
%   indicate that regexp didn't prior to R2018a. Now, I have added an "\" to the expected
%   string in the assertions. 

    path_folder = ca1{1}{1};  % the folder that is in Matlab's search path  
    special_ffs = ca1{1}{2};  % the part of the filespec that's outside the search path

    if strcmp( special_characters(end), '+' )      
        % No class folder. (Class folder: "@name", must be last. (NO! "@name/private"))
        % [tok,ext] = strtok( special_ffs(2:end), '.' );  % "2:": Skip leading '+'
        % fqn = regexprep( tok, '\x5C[\x2B]?', '\x2E' );  % Replace '\[+]?' by '.'
        % [ namespace, basename ] = fileparts( special_ffs(2:end) );
        % namespace = strrep( namespace, '\+', '.' );
        [ namespace, basename, ext ] = fileparts( special_ffs(2:end) );
        namespace = strrep( namespace, '\+', '.' );
        fqn = strjoin( {namespace,basename}, '.' );
        %
    elseif strcmp( special_characters(end), '@' ) 
        % Class folder
        %
        % Are nested class folders documented? No and they are not allowed.
        % ...\datamanager\@datamanager\@brushmanager is a special construct based on 
        % schema.m
        %
        % >> help h5pia.StringTree.has_location
        % >> help h5pia.StringTree>has_location
        % >> help h5pia.StringTree/has_location all return
        %    No help found for h5pia.StringTree/has_location
        % i.e all allowed; Matlab cannot make up its mind regarding ".>/"
        
        % 2020-08-03, The following if-else-end block is rewritten to handle extrernal
        % methods differently. I avoided indexing into character arrays, to make the
        % code work with strings.
        [ folder, name, ext ] = fileparts( special_ffs );
        if endsWith( folder, ['@',name] )  
            % The values of folder and name are equal only for the classdef file 
            % (ignoring the leading @)
            fqn = regexprep( folder, [dbhex(filesep),'[\x2B\x40]?'], '\x2E' ); 
            fqn = regexp( fqn, '(?<=^[\x2B\x40])[\w\x2E]+$', 'match','once' );

            cac = regexp( folder, [dbhex(filesep),'\x40'], 'split' );              
            if length(cac) == 1
                namespace = '';
            else
                namespace = regexprep( cac{1}, [dbhex(filesep),'\x2B'], '\x2E' );
                if startsWith( namespace, '+' )
                    namespace = extractAfter( namespace, '+' );
                end
            end
            basename  = name;
        else
            % The values of folder and name differs for external methods.
            % fqn, fully qualified name isn't defined for external methods.
            fqn         = '';
            path_folder = '';
            namespace   = '';
            basename    = '';
            ext         = '';
        end
        
%   FIXME: Requirement slip! fqn shall not include the name of the methods or local
%   functions. Furthermore, neither shall private subfolders - or 
%         if not( strcmp( name, ca3{end} ) )
%             % NOTE: "class>method"                
%             fqn = sprintf( '%s>%s', fqn, name ); 
%           warning('ffs2fqn:NotClassdefFile'                          ...
%               ,   '%s is an external method, not a classdef file', filespec ) 
%         end
    else
        error( 'ffs2fqn:InternalError', 'Special folders issue: %s', filespec )
    end
end
%%  History                     .
%   2017-08-13, Radical refatoring, see h:\m\PiaRepos\mylib\filespec2fqn_20170812.m
%

