% +m2uml, A short informative text
% Version 0.00 2000-01-01
%
%
% Created automatically by make_contents_file at 2020-04-10 19:45:32
%
%   Packages
%
%   Folders
%
%   Classes
%       AbstractMethodsBlockRegex.m    - No H1-line
%       AssignmentBlockParser.m        - extract names, #lines and help-texts from blocks of source code
%       AssignmentParser.m             - See also: text_types_of_mfile
%       BlockRegex.m                   - is base class of AbstractMethods, Simpleand
%       CharacterClasses.m             - Former name: AssignmentCharacter
%       Class.m                        - Knows the data to make the class block code for ONE Matlab class.
%       Doer.m                         - is superclass of classes, which operate on subclasses of Element
%       Element.m                      - is superclass of classes, which represent PlantUml code s.
%       Enumeration.m                  - knows all data to make the PlantUml field row for ONE .
%       Event.m                        - knows all data to make the PlantUml field row for ONE .
%       Footer.m                       - knows all data to make the code for the .
%       Function.m                     - Knows all data to make class block code for ONE Matlab function.
%       GeneralizationScanner.m        - Compile generalization relationships
%       Header.m                       - knows all data to make the code for the .
%       HierarchyLeafAdder.m           - adds Footer, Header, Title and Skinparam to PlantUmlScript
%       LeafDisplayOrder.m             - -
%       LeafDisplaySelection.m         - Shall there be a compartment for TodoFixme annotations?
%       MaxLabelWidth.m                - "Label" rather than "String" to avoid associations to the Matlab type string.
%       MetaDataScanner.m              - 
%       Method.m                       - knows all data to make the PlantUml row for ONE .
%       Miscellaneous.m                - TODO: rename to Background color
%       NodeHierarchyCreator.m         - builds a hierarchy of packages, classes, and functions
%       Package.m                      - Knows all data to make the namespace block for ONE Matlab package.
%       PlantUmlCodePrinter.m          - NOTE: The Matlab browser has a print feature. It is possible to print to an Adobe
%       PlantUmlScript.m               - is the root of a hierarchy of nodes and leafs. It adds the nodes
%       Property.m                     - knows all data to make the PlantUml field row for ONE .
%       Relationship.m                 - Knows all data to make the PlantUml relation row for ONE relationship.
%       Separator.m                    - knows all data to make ONE seprator between compartments of a class box
%       SimpleBlockRegex.m             - events, enumeration, properties
%       SingleCodeRow.m                - knows all data to make ONE PlantUml code row
%       Skinparam.m                    - knows all data needed to make a block code.
%       SourceFile.m                   - NOTE: This class replaces sandbox\SourceCodeFile
%       SourceFileAnalyzer.m           - is responsible for analyzing m-code of one module
%       SourceFileScanner.m            - NOTE: copy&pated from execute_Property. The persistent
%       Stack.m                        - The Stack class represents a last-in-first-out (LIFO) stack of objects.
%       Title.m                        - knows all data to make the code for the .
%       TodoFixme.m                    - knows all data to make the code for ONE entry.
%
%   Functions
%       blank_multiline_comments.m     - replaces multi-line comments with empty lines
%       call_local_PlantUML.m          - m2uml.call_local_PlantUML displays a UML Class Diagram in the Matlab Web Browser.
%       create_PlantUML_script.m       - creates and writes a PlantUML-script to a puml-file
%       display_class_diagram.m        - displays an image file in a browser
%       factory_options.m              - Creates a structure that controls appearance and the degree of detail of the diagram
%       ffs2url.m                      - m2uml.ffs2url('h:\m\PiaX\IDE_tools_test\work\test_755.svg')
%       has_explicit_constructor.m     - num = regexp( str, ['^\x20*function\x20*\w+\x20*=\x20*',cac{end}]   ...
%       main.m                         - m2uml_main creates a PlantUML script that defines an UML Class Diagram comprising
%       merge_options.m                - Syntax
%       my_browser.m                   - opens the page specified by url in the hardcoded browser
%       puml2graphic.m                 - takes a puml-file and creates an image file
%       resolve_user_automatic_arrow_conflict.m - 
%       run.m                          - m2uml.run creates a PlantUML script, writes it to a file and opens it in the editor
%       search_relationships.m         - produces a set of potential relationship arrows
%       uml2png.m                      - m2uml.uml2web displays an UML Class Diagram in the Matlab Web Browser.
%       uml2svg.m                      - m2uml.uml2svg takes a puml-file and creates an svg-file
%
%   Script
%
%   Help
%
%   Others
%
