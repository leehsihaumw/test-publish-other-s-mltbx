classdef    Property  < m2uml.Element            %
% Property knows all data to make the PlantUml field row for ONE property.  

    properties  ( Constant = true )
        %
        block_head  = 'properties'; 
    end
    properties                                  %
        % Data used for the property code row
        data = struct(  'visibility'    ,   ''      ...
                    ,   'isAbstract'    ,   false   ...
                    ,   'isStatic'      ,   false   ...
                    ,   'line'          ,   []      ...
                    ,   'tooltip'       ,   ''      ...
                    ,   'prefix'        ,   ''      ... to handle dependent properties
                    );
        %
        % SourceFile instance, with the properties: ffs,fqn,type,namespace,basename
        source_file = m2uml.SourceFile.empty(1,0);
        max_label_width
    end
    methods                                     %
        function    this = Property( varargin ) %
            % Explicit constructor
            this@m2uml.Element( varargin{:} );
        end
    end
end
