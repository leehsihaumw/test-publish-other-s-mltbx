classdef    SingleCodeRow  < m2uml.Element     %
% SingleCodeRow knows all data to make ONE PlantUml code row 
%
    properties                              %
        %
        string = '';
    end
    methods                                 %
        function    this = SingleCodeRow( varargin )    %
            % Explicit constructor
            this@m2uml.Element( varargin{1:2} );
            if nargin == 3
                this.string = varargin{3};
            end
        end
    end
end
