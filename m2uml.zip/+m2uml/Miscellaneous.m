classdef    Miscellaneous < m2uml.Doer                             %
% Miscellaneous

    properties  ( Access = private )                            %
        %
        options
    end
    methods                                                     %
        function    this = Miscellaneous( varargin )            %
            % Explicit constructor. Sets the property, options
            narginchk( 0, 1 )
            if nargin == 1
                this.options = varargin{1};
            end
        end
    end
    methods     ( Access = ?m2uml.Doer )                        %
        function    execute_PlantUmlScript  ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Class           ( this, obj )       %
            %
            obj.data.CircleBackgroundColor  ...    
            =   this.options.Class.CircleBackgroundColor.( obj.data.CircleCharacter );
        
            this.execute_for_all_children( obj )
        end
        function    execute_Function        ( this, obj )       %
            %
            obj.data.CircleBackgroundColor = this.options.Function.CircleBackgroundColor;
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Package         ( this, obj )       %
            %
            obj.data.BackgroundColor = this.options.Package.BackgroundColor;
            %
            this.execute_for_all_children( obj )
        end
    end
end
