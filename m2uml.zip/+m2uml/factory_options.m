function    options = factory_options()
% Creates a structure that controls appearance and the degree of detail of the diagram

%{
%   NOTE:   ShowTrailingUnderscore isn't implemented, 
%   NOTE:   The hand pointer indicates that either or both of hyperlink and tooltip 
%           are active, but not which. 
%   NOTE:   Landscape/Portrait would be useful, since my monitor typically is
%           Landscape. It's not possible(?). Googling "PlantUml Landscape Portrait"
%           doesn't find anything of interest. What about Diagram.TopToBottom?
%   DONE:   Footer: Created by LiveEditorEvaluationHelperESectionEval at 2019-09-09 09:04
%           Using dbstack to create 'created_by' isn't robust.
%   DONE:   Add General.PlantumlExtension = 'puml'; Users might want 'txt' to support use
%           of PlantText
%}
%#ok<*STRNU> 
narginchk(0,0)
%% Diagram                                      .
    Diagram.Arguments          = true;          %   show arguments of methods
    Diagram.Generalizations    = true;          %   show inheritance arrows
    Diagram.Monospaced         = true;          %   use monospace in class boxes
    Diagram.LinetypeDefault    = true;          %   false gives "linetype ortho"
    Diagram.TopToBottom        = true;          %   false gives "left to right direction"
%% Class                                        .
    CBC.A = '#A9DCDF';                          %   abstract     
    CBC.C = '#ADD1B2';                          %   general, default letter     
    CBC.D = 'Plum';                             %   date, not used
    CBC.E = '#EB937F';                          %   enum         
    CBC.H = '#E6FFE6';                          %   handle
    CBC.S = '#FF7700';                          %   singleton    
    CBC.V = 'PaleGreen';                        %   value
    Class.CircleBackgroundColor = CBC;          %   "Circle" is better than "Stereotype"
    Class.SeparatorLabel        = false;        %   not used
%% Enumeration                                  .
    Enumeration.show    = true;                 %   show enumerations
%% Event                                        .
    Event.private       = true;                 %   show private events
    Event.protected     = true;                 %   show protected events
    Event.public        = true;                 %   show public events
%% Footer                                       . the text at the very bottom       
    Footer.Color    = 'Maroon';                 %
    Footer.FontSize = 10;                       %
    Footer.On       = true;                     %
    Footer.String   = 'No footer';              %   default value
%% Function                                     .
    Function.CircleBackgroundColor = 'Pink';    %
%% Header                                       . the text in the upper right corner
    Header.Color    = 'Maroon';                 %
    Header.FontSize = 10;                       %
    Header.On       = true;                     %
    Header.String   = 'No header';              %   default value
%% Hyperlink                                    .
    Hyperlink.Class       = true;               %
    Hyperlink.Enumeration = true;               %
    Hyperlink.Event       = true;               %
    Hyperlink.Function    = true;               %
    Hyperlink.Method      = true;               %
    Hyperlink.Package     = true;               %
    Hyperlink.Property    = true;               %
    Hyperlink.TodoFixme   = true;               %
%% Method                                       .
    Method.private      = true;                 %   show private methods
    Method.protected    = true;                 %   show protected methods
    Method.public       = true;                 %   show public methods
    Method.setget       = true;                 %   show set and get methods 
%% Package                                      .
    Package.BackgroundColor = 'OldLace';        %
    Package.ReadmeFile      = 'Contents.m';     %   Contains help-text of package
%% Property                                     .
    Property.private     = true;                %   show private properties
    Property.protected   = true;                %   show protected properties
    Property.public      = true;                %   show public properties
%% Title                                        .
    Title.Color     = 'Maroon';                 %
    Title.FontSize  = 18;                       %
    Title.On        = true;                     %
    Title.String    = 'No title';               %   default value  
%% TodoFixme                                    .
    TodoFixme.fixme = true;                     %   show FIXME annotations
    TodoFixme.todo  = true;                     %   show TODO annotations
    TodoFixme.note  = true;                     %   show NOTE annotations
%% Tooltip                                      .
    %   
    Tooltip.DefaultText = 'No tooltip';         %
    Tooltip.H1Line      = true;                 %   use H1-line as tooltip
    %
    Tooltip.Class       = true;                 %   show tooltip of classes
    Tooltip.Enumeration = true;                 %   show tooltip of enumerations
    Tooltip.Event       = true;                 %   show tooltip of events
    Tooltip.Function    = true;                 %   show tooltip of functions
    Tooltip.Method      = true;                 %   show tooltip of methods
    Tooltip.Package     = true;                 %   show tooltip of packages
    Tooltip.Property    = true;                 %   show tooltip of properties
    Tooltip.TodoFixme   = true;                 %   show tooltip of aqnnotations
%% ------                                       .
%% General                                      .
    General.WorkingFolder       = fullfile('d:\m\tmp'); % folder of puml and image files
    General.FileBaseName        = 'test';       % name of puml-script and image file
    General.PlantUmlExtension   = 'puml';
    General.GraphicFormat       = 'svg';        % 'svg', 'png', ...
    General.Viewer              = 'web';        % 'web', 'browser' or 'webwindow'
    General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2020.17.jar');
%   General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2020.02.jar');
%   General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2020.00.jar');
%   General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2019.11.jar');
%   General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2018.09.jar');
%   General.PlantUmlJar         ...
%   =   fullfile('d:\_MyPrg\PlantUml\plantuml_namespace_beta_2020-02-04.jar');
%   General.PlantUmlJar         ...
%   =   fullfile('d:\_MyPrg\PlantUml\plantuml_namespace_beta_2020-03-01.jar');
    General.DisplayWidth        = 0; % pixels <80 switches default on. Leave it at zero! 
%% ------                                       .
%% Consolidate the substructures into one struct.
%   DO NOT EDIT the code of this section    
    
    sas = whos();
    sas( not( strcmp({sas.class},'struct') ) ) = [];
    %
    for sub = {sas.name}
        options.( sub{:} ) = eval( sub{:} );
    end
end
