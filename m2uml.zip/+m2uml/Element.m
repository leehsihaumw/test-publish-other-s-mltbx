classdef    Element  < matlab.mixin.Heterogeneous & handle
% Element is superclass of classes, which represent PlantUml code elements. 
%
% Subclasses: Class, Enumeration, Event, Footer, Function, Header, Method, Package, 
%   PlantUmlScript, Property, Relationship, Separator, SingleCodeRow, Skinparam, 
%   Title, TodoFixme
%   FindFiles " < m2uml.Element" or Find and Replace Files "<\x20+m2uml\.Element\>"
    
    properties                                      %
        %
        name = '';
        % Parent
        parent = m2uml.Element.empty(1,0);  
        %   Indicates whether the element will be included in the PlantUml script.
        isSelected  = true;
    end
    methods                                         %
        function    this = Element( varargin )      %
            % Explicit constructor. The property, name, is set
            if nargin == 0   
                return
            elseif nargin == 2
                this.name   = varargin{1};
                this.parent = varargin{2};
            else
                error( 'm2uml:Element:WrongNumberOfInputs', 'Wrong number of inputs' )
            end
        end
    end
    methods ( Static, Sealed, Access = protected )  %
        %
        function default_object = getDefaultScalarElement           %
            % See: matlab.mixin.Heterogeneous.getDefaultScalarElement
            default_object = m2uml.TodoFixme();
        end
    end
end
