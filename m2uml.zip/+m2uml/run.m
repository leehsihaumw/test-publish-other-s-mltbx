function    puml = run( title_str, class_list, other_arrows )        %
% m2uml.run creates a PlantUML script, writes it to a file and opens it in the editor
%
% Syntax:
%       puml = m2uml.run( title_str, class_list, other_arrows );
%
% Input Parameters:
%       title_str       a text string, which will appear as title of the
%                       class diagram
%       class_list      a cell array of full names of classes. The names of
%                       classes, which are members of a packages, shall be
%                       prefixed by the package name, separated by a dot.
%       other_arrows    a cell array of PlantUML statements, which define
%                       arrows between classes. See "3.1 Relations between
%                       classes" in the PlantUML pdf-manual or
%                       http://plantuml.com/class-diagram on-line.
%
% Output parameters:
%       puml            full filespec of the puml-script-file
%
% Description:
%       This version of m2uml.run mimics the behavior of m2uml.run of m2uml 1.1.  
%       m2uml.run generates a PlantUML-script-file named temp.txt, which is opened in the
%       editor. The script defines an UML class diagram, which depict populated class
%       boxes for the classes of class_list together with inheritance arrows and the
%       arrows of other_arrows.
%
% Examples:
%         puml = m2uml.run( 'BN_Iterator'  ...
%             ,   {
%                 'List'
%                 'CellArrayList'
%                 'Iterator'
%                 'CellArrayListIterator'
%                 }, {
%                 'CellArrayList "1" <-left-o "1 " CellArrayListIterator : "  "'
%                 } );
%
% See also: m2uml.call_local_PlantUML, m2uml.create_PlantUML_script,
%           m2uml.display_class_diagram, m2uml.puml2graphic


    puml = m2uml.create_PlantUML_script                     ...
                    (   'Classes'       ,   class_list      ...
                    ,   'Arrows'        ,   other_arrows    ...
                    ,   'UserOptions'   ,   v11_options()   ...   
                    ,   'Title'         ,   title_str       ...
                    );
    matlab.desktop.editor.openDocument( puml );
end
