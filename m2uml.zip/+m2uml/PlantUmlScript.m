classdef    PlantUmlScript  < m2uml.Element  
% PlantUmlScript is the root of a hierarchy of nodes and leafs. It adds the nodes
% (packages and classes) to this hierarchy.

    properties                                                  %
        %
        source_file_list    = m2uml.SourceFile.empty(1,0); 
        %
        children            = m2uml.Element.empty(1,0);         %
    end
    methods                                                     %
        function    this = PlantUmlScript( varargin )           %
            %
            this@m2uml.Element( varargin{1:end-1} );
            if nargin >= 1
                this.setSourceFile( varargin{3} )
            end
        end
    end
    methods                                                     %
        function    setSourceFile( this, file_list )            %
            %   Input, file_list, shall be a cell array of character vectors. The
            %   values of the file_list shall be full filespecs or fully qualified
            %   names of classes or functions. The classes and function shall be on
            %   the Matlab search path.
            
            assert( length( file_list ) >= 1        ...
                ,   'm2uml:PlantUmlScript:NoValue'  ...
                ,   'The input file_list is empty'  )
            
            this.source_file_list = m2uml.SourceFile( file_list );
        end
        function    node_row = traverse_hierarchy( this, obj )  %
            % returns a row of obj and all its descendants
            
            % Depth-first left-to-right search,   
            % node_row is an array of all children and children of child 
            node_row = obj;
            if ismember( 'children', properties(obj) )  % if obj has children
                for child = obj.children 
                    node_row = cat( 2, node_row, this.traverse_hierarchy( child ) ); 
                end
            end
        end
    end
end
