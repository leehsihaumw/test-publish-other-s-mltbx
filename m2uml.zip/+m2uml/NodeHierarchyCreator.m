classdef    NodeHierarchyCreator < handle                   %
% NodeHierarchyCreator builds a hierarchy of packages, classes, and functions    
    
    methods                                                 %
        function    build_node_hierarchy( this, pus )       %
        % build_node_hierarchy builds a parent-child hierarchy of packages, classes
        % and functions
        
        %   Node Hierarchy allows nodes to be children of other nodes creating a 
        %   tree-like hierarchy of packages and classes (and functions). The root 
        %   is a PlantUmlScript object.

        %   root    object of PlantUmlScript
        %   nodes   objects of Package (internal node)    
        %   nodes   objects of Class or Function
        %
        %   Subsequently, leafs will be added to the root and the class nodes.  
        
            for source_file = pus.source_file_list
                this.add_Node( pus, source_file );
            end
        end
    end
    methods     ( Access = private )                        %
        function    add_Node( ~, pus, source_file )         %
            %
            fqn_split = regexp( source_file.fqn, '\.', 'split' );   
            len = length( fqn_split );
            loc = nan( 1, len );

            if len >= 2     % if package folder; find folderspec of the parent folder
                filespec_parts = regexp( source_file.ffs, filesep, 'split' );   
                ise = cellfun( @isempty, regexp(filespec_parts,'^\+','start','once') );
                folderspec = fullfile( filespec_parts{ 1 : find(not(ise))-1 } );
            end
           
            %   Packages. Deduce one (or zero) subtree of packages from the full 
            %   filespec and add it to the end of the row of root.children. 
            %   TODO: What happens with ...\+P1\+P2 in combination with ...\+P2 ??
            parent = pus;
            for jj = 1 : len-1 % the last one is a class/function, not a package
                [ ism, loc(jj) ] = ismember( fqn_split{jj}, {parent.children.name} );
                if ism
                    parent = parent.children(loc(jj));
                else
                    % ...\+P1\+P1\myclass.m is ok; ...\+P1\f\+P2\myclass.m is not
                    child = m2uml.Package( fqn_split{jj}, parent );
                    folderspec = fullfile( folderspec, ['+',fqn_split{jj}] );
                    child.data.folderspec = folderspec;
                    parent.children(1,end+1) = child; 
                    parent = child;
                end
            end
            %   At this point the value of parent is a leaf of the current tree  
            
            %   Class or Function. 
            if strcmp( source_file.type, 'class' )
                node = m2uml.Class( fqn_split{end}, parent );
            elseif strcmp( source_file.type, 'function' )
                node = m2uml.Function( fqn_split{end}, parent );
            else
                error( 'm2uml:NodeHierarchyCreator:IllegalType' ...
                    ,  'Illegal type, "%s", of "%s"'            ...
                    ,   source_file.type, source_file.ffs       )
            end
            node.source_file = source_file;

            parent.children(1,end+1) = node;
        end
    end
end
