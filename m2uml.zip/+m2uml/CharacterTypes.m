classdef 	CharacterTypes 
% This class replace an enumeration class, which contributed to a very slow code. 
% See my answer to the question, "Are enum-comparisons slow in MATLAB?".  

    properties ( Constant = true )
        null_statement                    = 0;
        end_of_statement                  = 1;
        code_outside_brackets             = 2;
        code_in_brackets                  = 3;
        in_character_constant             = 4;
        in_character_constant_in_brackets = 5;
        in_string_constant                = 6;
        in_string_constant_in_brackets    = 7;
        in_single_line_comment            = 8;
    end                                   
end
