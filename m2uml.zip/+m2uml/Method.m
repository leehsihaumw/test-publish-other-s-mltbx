classdef    Method  < m2uml.Element
% Method knows all data to make the PlantUml method row for ONE method. 

%   NOTE: Implicit and explicit constructors are treated the same. meta.data doesn't
%   distinguish between the two. Hiding implicit constructors, is that a good idea?
%   Maybe. Property of class: has_explicit_constructor. Property of method:
%   is_constructor
        
    properties  ( Constant = true )
        %
        block_head  = 'methods'; 
    end
    properties                                  %
        % Data used for the method code row
        data = struct(  'visibility'            ,   ''      ...
                    ,   'isAbstract'            ,   false   ...
                    ,   'isStatic'              ,   false   ...
                    ,   'tooltip'               ,   ""      ...
                    ,   'inargs'                ,   []      ...     % docs order
                    ,   'outargs'               ,   []      ...
                    ,   'isExplicitConstructor' ,   false   ...
                    ,   'isImplicitConstructor' ,   false   ...
                    );
        % SourceFile instance, with the properties: ffs,fqn,type,namespace,basename
        source_file = m2uml.SourceFile.empty(1,0);
        max_label_width
    end
    methods                                     %
        function    this = Method( varargin )   %
            % Explicit constructor
            this@m2uml.Element( varargin{1:2} );
        end
    end
end
