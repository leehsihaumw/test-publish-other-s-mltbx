classdef    Function  < m2uml.Element
% Knows all data to make class block code for ONE Matlab function. 

    properties  ( Constant = true )
        %
        block_head  = 'function'; 
    end
    properties
        % Data used for the function block code
        data = struct(  'CircleCharacter'       , ''  ... capital letter in circle
                    ,   'CircleBackgroundColor' , ''  ...      
                    ,   'tooltip'               , ''  );
        
        % Children of class include objects of TodoFixme 
        children = m2uml.TodoFixme.empty(1,0);
        
        % SourceFile instance, with the properties: ffs,fqn,type,namespace,basename
        source_file = m2uml.SourceFile.empty(1,0);
        max_label_width 
    end
    methods
        function    this = Function( varargin )            %
            % Explicit constructor
            this@m2uml.Element( varargin{:} );
        end
    end
end
