function    resolve_user_automatic_arrow_conflict( pus, user_arrows )
% resolve_user_automatic_arrow_conflict 
%
% disables conditionally relationship based on meta.MetaData
%    
% Syntax:  arrow_presedence( relationship, user_arrows )
%
% Inputs:
%   pus             <1x1 m2uml.PlantUmlScript> of interest is pus.children of class
%                   <1xm m2uml.Relationship>, which are derived from meta.MetaData 
%   user_arrows     <nx1 cellstr> indata supplied by the user, e.g. {'source --|> target'}
%
% Outputs:
%   sets relationship.isSelected = false. (m2uml.Relationship is a handle class.)
%
% Description:
%   Generalisation arrows included in user_rows shall take precedence over
%   generalisation arrows based on meta.MetaData. If user_rows contains a
%   generalisation, isSelected is set to false for the corresponding
%   m2uml.Relationship object.
%
% See also: m2uml.create_PlantUML_script
    
%   user_source_target and meta_source_target are <nx2 string>, e.g. ["source","target"] 
    
    %   Extract the generalizations from the user arrow code
    xpr = regex.generalization_arrow();
    cac = regexp( string(user_arrows), xpr, 'tokens', 'once' );
    user_arrow_code = vertcat( cac{:} );
    
    len = size( user_arrow_code, 1 ); 
    user_source_target = strings( len, 2 );
    for jj = 1 : len
        if contains( user_arrow_code(jj,2), "<|" )
            user_source_target(jj,:) = [ user_arrow_code(jj,3), user_arrow_code(jj,1) ];
        else
            user_source_target(jj,:) = [ user_arrow_code(jj,1), user_arrow_code(jj,3) ];
        end
    end
    
    %   All pus.children of class 'm2uml.Relationship' define generalizations  
    is_relationship = arrayfun( @(obj) isa(obj,'m2uml.Relationship'), pus.children );
    relationships   = pus.children( is_relationship );
    
    meta_source_target = [
        string( reshape( curly(relationships,'data','source'), [],1 ) )  ...
        string( reshape( curly(relationships,'data','target'), [],1 ) )  ];

    %   Deselect the "automatic" generalization relationships that exist in user_rows 
    ismem = ismember( meta_source_target, user_source_target, 'rows' ); 
    [ relationships(ismem).isSelected ] = deal( false );
    
    %   Add the user arrow code to the list of childrens of the tree-root, pus
    for row = reshape( user_arrows, 1,[] )
        pus.children = [ pus.children, m2uml.SingleCodeRow('user',pus,row{:}) ];
    end
end
