classdef 	InputTypes  
% This class replace an enumeration class, which contributed to a very slow code. 
% See my answer to the question, "Are enum-comparisons slow in MATLAB?".  

    properties ( Constant = true )
        null_input               =  0;
        single_quote             =  1;
        double_quote             =  2;
        opening_bracket          =  3;
        closing_bracket          =  4;
        delimiter                =  5;
        comment                  =  6;
        alpha_num                =  7;
        white_space              =  8;
        special                  =  9;
        transpose_blip           = 10;
        closing_single_quote     = 11;
        outer_closing_bracket    = 12;
        other_character          = 13;
    end
end
