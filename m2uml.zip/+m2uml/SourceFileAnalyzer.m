classdef    SourceFileAnalyzer  < handle                                    %
    % SourceFileAnalyzer classifies the characters of the code of ONE module. 
    
    properties  ( Constant = true )                     %
        
        alpha_num = num2cell( ['A':'Z','a':'z','_','0':'9'] ); 
        
        %   Doc: MATLAB Operators and Special Characters, (blip is super special - sigh)
        special = num2cell( '+-*^/\.=<>&|~@:!?$' );     
        
        single_quote    = {char(39)};
        double_quote    = {char(34)};
        opening_bracket = {'(','[','{'};
        closing_bracket = {')',']','}'};
        delimiter       = {',',';', newline };  
        white_space     = {char(9),char(32)};   % add backspace, char(8), ??? 
        comment         = {'%'};
        
        pre_transpose_blip = num2cell(['A':'Z','a':'z','0':'9',')]}._',char(39)]);
        
        %   FIXME: The characters, "!#£€¤$?", and may be a few more are missing.
        %   All of these may occur in string constants and some of them even in
        %   code_outside_brackets, e.g. "?!". My code assumes that the processed
        %   source code confirms with the syntax rules.
        
    end
    properties  ( Constant = true )                     %
        NextState   = m2uml.SourceFileAnalyzer.create_TransitionFunction;
        Char2Input  = m2uml.SourceFileAnalyzer.create_Character2InputAlphabet;
    end
    properties  ( Access = private )                    %
        previous_state = m2uml.CharacterTypes.end_of_statement;
        previous_bracket_level  = 0;
        stack                   = m2uml.Stack();
        %   used by next_block_() to distinguish between methods and functions
        is_in_methods_block     = false;
    end
    properties  ( Access = {?m2uml.SourceFileScanner}, Constant = true )   % 
        % See the function iskeyword(). block() is used as a kind of enumeration
        keywords                                                                    ...
        =   [ "null_block", "outside_block", "classdef", "properties", "methods"    ...
            , "function", "events", "enumeration", "todofixme", "end"               ...
            , "for", "while", "switch", "try", "if"                                 ...
            , "parfor" ];
        
        block = containers.Map( m2uml.SourceFileAnalyzer.keywords, (0:15) );  
        block_xpr = "\<(" + strjoin( m2uml.SourceFileAnalyzer.keywords,")\>|\<(") + ")\>";
        % NOTE: block_xpr must be as short as possible to limit the regexp execution time.
    end
    methods     ( Static = true )                       %
        function    out = create_Character2InputAlphabet()  %
            %   Transform input stream of characters to members of the input alphabet
            ascii2type  = ...  0   1   2   3   4   5   6   7   8   9
                        [      0,  0,  0,  0,  0,  0,  0,  0,  0,  8    ...  0
                        ,      5,  0,  0,  5,  0,  0,  0,  0,  0,  0    ...  1
                        ,      0,  0,  0,  0,  0,  0,  0,  0,  0,  0    ...  2
                        ,      0,  0,  8,  9,  2,  0,  9,  6,  9,  1    ...  3
                        ,      3,  4,  9,  9,  5,  9,  9,  9,  7,  7    ...  4
                        ,      7,  7,  7,  7,  7,  7,  7,  7,  9,  5    ...  5
                        ,      9,  9,  9,  9,  9,  7,  7,  7,  7,  7    ...  6
                        ,      7,  7,  7,  7,  7,  7,  7,  7,  7,  7    ...  7
                        ,      7,  7,  7,  7,  7,  7,  7,  7,  7,  7    ...  8
                        ,      7,  3,  9,  4,  9,  7,  0,  7,  7,  7    ...  9
                        ,      7,  7,  7,  7,  7,  7,  7,  7,  7,  7    ... 10
                        ,      7,  7,  7,  7,  7,  7,  7,  7,  7,  7    ... 11
                        ,      7,  7,  7,  3,  9,  4,  9,  0            ... 12
                        ];
            
            out = ascii2type;
        end
        function    out = create_TransitionFunction()       %
            
            out = repmat( m2uml.CharacterTypes.null_statement, 13, 8 );
            
            out( :, 1 ) = [  % end_of_statement
                m2uml.CharacterTypes.in_character_constant    %   1. single_quote
                m2uml.CharacterTypes.in_string_constant       %   2. double_quote
                m2uml.CharacterTypes.code_in_brackets         %   3. opening_bracket
                m2uml.CharacterTypes.null_statement           %   4. closing_bracket
                m2uml.CharacterTypes.end_of_statement         %   5. delimiter
                m2uml.CharacterTypes.in_single_line_comment   %   6. comment
                m2uml.CharacterTypes.code_outside_brackets    %   7. alpha_num
                m2uml.CharacterTypes.code_outside_brackets    %   8. white_space
                m2uml.CharacterTypes.code_outside_brackets    %   9. special
                m2uml.CharacterTypes.null_statement           %  10. transpose_blip
                m2uml.CharacterTypes.null_statement           %  11. closing_single_quote
                m2uml.CharacterTypes.null_statement           %  12. outer_closing_bracket
                m2uml.CharacterTypes.null_statement           %  13. other_character
                ];
            out( :, 2 ) = [  % code_outside_brackets
                m2uml.CharacterTypes.in_character_constant    %   1. single_quote
                m2uml.CharacterTypes.in_string_constant       %   2. double_quote
                m2uml.CharacterTypes.code_in_brackets         %   3. opening_bracket
                m2uml.CharacterTypes.null_statement           %   4. closing_bracket
                m2uml.CharacterTypes.end_of_statement         %   5. delimiter
                m2uml.CharacterTypes.in_single_line_comment   %   6. comment
                m2uml.CharacterTypes.code_outside_brackets    %   7. alpha_num
                m2uml.CharacterTypes.code_outside_brackets    %   8. white_space
                m2uml.CharacterTypes.code_outside_brackets    %   9. special
                m2uml.CharacterTypes.code_outside_brackets    %  10. transpose_blip
                m2uml.CharacterTypes.null_statement           %  11. closing_single_quote
                m2uml.CharacterTypes.null_statement           %  12. outer_closing_bracket
                m2uml.CharacterTypes.null_statement           %  13. other_character
                ];
            out( :, 3 ) = [  % code_in_brackets
                m2uml.CharacterTypes.in_character_constant_in_brackets % 1. single_quote
                m2uml.CharacterTypes.in_string_constant_in_brackets    % 2. double_quote
                m2uml.CharacterTypes.code_in_brackets         %   3. opening_bracket
                m2uml.CharacterTypes.code_in_brackets         %   4. closing_bracket
                m2uml.CharacterTypes.code_in_brackets         %   5. delimiter
                m2uml.CharacterTypes.in_single_line_comment   %   6. comment
                m2uml.CharacterTypes.code_in_brackets         %   7. alpha_num
                m2uml.CharacterTypes.code_in_brackets         %   8. white_space
                m2uml.CharacterTypes.code_in_brackets         %   9. special
                m2uml.CharacterTypes.code_in_brackets         %  10. transpose_blip
                m2uml.CharacterTypes.null_statement           %  11. closing_single_quote
                m2uml.CharacterTypes.code_outside_brackets    %  12. outer_closing_bracket
                m2uml.CharacterTypes.null_statement           %  13. other_character
                ];
            out( :, 4 ) = [  % in_character_constant
                m2uml.CharacterTypes.null_statement           %   1. single_quote
                m2uml.CharacterTypes.in_character_constant    %   2. double_quote
                m2uml.CharacterTypes.in_character_constant    %   3. opening_bracket
                m2uml.CharacterTypes.in_character_constant    %   4. closing_bracket
                m2uml.CharacterTypes.in_character_constant    %   5. delimiter
                m2uml.CharacterTypes.in_character_constant    %   6. comment
                m2uml.CharacterTypes.in_character_constant    %   7. alpha_num
                m2uml.CharacterTypes.in_character_constant    %   8. white_space
                m2uml.CharacterTypes.in_character_constant    %   9. special
                m2uml.CharacterTypes.null_statement           %  10. transpose_blip
                m2uml.CharacterTypes.code_outside_brackets    %  11. closing_single_quote
                m2uml.CharacterTypes.in_character_constant    %  12. outer_closing_bracket
                m2uml.CharacterTypes.in_character_constant    %  13. other_character
                ];
            out( :, 5 ) = [  % in_character_constant_in_brackets
                m2uml.CharacterTypes.null_statement           %   1. single_quote
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 2. double_quote
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 3. opening_bracket
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 4. closing_bracket
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 5. delimiter
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 6. comment
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 7. alpha_num
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 8. white_space
                m2uml.CharacterTypes.in_character_constant_in_brackets  % 9. special
                m2uml.CharacterTypes.null_statement           %  10. transpose_blip
                m2uml.CharacterTypes.code_in_brackets         %  11. closing_single_quote
                m2uml.CharacterTypes.null_statement           %  12. outer_closing_bracket
                m2uml.CharacterTypes.in_character_constant_in_brackets % 13. other_character
                ];
            out( :, 6 ) = [  % in_string_constant
                m2uml.CharacterTypes.in_string_constant       %   1. single_quote
                m2uml.CharacterTypes.code_outside_brackets    %   2. double_quote
                m2uml.CharacterTypes.in_string_constant       %   3. opening_bracket
                m2uml.CharacterTypes.in_string_constant       %   4. closing_bracket
                m2uml.CharacterTypes.in_string_constant       %   5. delimiter
                m2uml.CharacterTypes.in_string_constant       %   6. comment
                m2uml.CharacterTypes.in_string_constant       %   7. alpha_num
                m2uml.CharacterTypes.in_string_constant       %   8. white_space
                m2uml.CharacterTypes.in_string_constant       %   9. special
                m2uml.CharacterTypes.null_statement           %  10. transpose_blip
                m2uml.CharacterTypes.null_statement           %  11. closing_single_quote
                m2uml.CharacterTypes.in_string_constant       %  12. outer_closing_bracket
                m2uml.CharacterTypes.in_string_constant       %  13. other_character
                ];
            out( :, 7 ) = [  % in_string_constant_in_brackets
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   1. single_quote
                m2uml.CharacterTypes.code_in_brackets                 %   2. double_quote
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   3. opening_bracket
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   4. closing_bracket
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   5. delimiter
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   6. comment
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   7. alpha_num
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   8. white_space
                m2uml.CharacterTypes.in_string_constant_in_brackets   %   9. special
                m2uml.CharacterTypes.null_statement           %  10. transpose_blip
                m2uml.CharacterTypes.null_statement           %  11. closing_single_quote
                m2uml.CharacterTypes.null_statement           %  12. outer_closing_bracket
                m2uml.CharacterTypes.in_string_constant_in_brackets % 13. other_character
                ];
            out( :, 8 ) = [  % in_single_line_comment
                m2uml.CharacterTypes.in_single_line_comment   %   1. single_quote
                m2uml.CharacterTypes.in_single_line_comment   %   2. double_quote
                m2uml.CharacterTypes.in_single_line_comment   %   3. opening_bracket
                m2uml.CharacterTypes.in_single_line_comment   %   4. closing_bracket
                m2uml.CharacterTypes.in_single_line_comment   %   5. delimiter
                m2uml.CharacterTypes.in_single_line_comment   %   6. comment
                m2uml.CharacterTypes.in_single_line_comment   %   7. alpha_num
                m2uml.CharacterTypes.in_single_line_comment   %   8. white_space
                m2uml.CharacterTypes.in_single_line_comment   %   9. special
                m2uml.CharacterTypes.null_statement           %  10. transpose_blip
                m2uml.CharacterTypes.null_statement           %  11. closing_single_quote
                m2uml.CharacterTypes.in_single_line_comment   %  12. outer_closing_bracket
                m2uml.CharacterTypes.in_single_line_comment   %  13. other_character
                ];
        end
    end
    
    methods     ( Access = public )         % 
        function    mcodes = read_and_classify( this, ffs ) %

            % mcodes        <nx1 struct>
            %     .row      <1x1 string>   one line of code
            %     .kinds    <1xm double>             
            %
            
            mcode_raw = this.read_source_code( ffs );
            
            % To make the code that operates on rows simpler, get rid of
            % multi-line comments and continuation lines. These two
            % involves multiple characters, e.g. "..." and "%{"
            mcode_raw = this.blank_multiline_comments( mcode_raw );
            mcode_raw = this.concatenate_continuation_lines( mcode_raw );
            mcode_raw = strtrim( mcode_raw );
            mcodes = this.classify( mcode_raw );
            mcodes = this.classify_rows( mcodes );
        end
    end
    methods     ( Access = public )         % public to allow testing
        function    mcodes = classify( this, mcode_raw )    %
            %
            % mcode_raw  <nx1 string>   n is the number of rows in the file, multi-line
            %                           comments and continuation lines are already
            %                           removed. Line numbers are preserved.
            %
            % mcodes     <nx1 struct>   one struct element per row
            %   .row
            %   .kinds
            %   .block_type
            
            % Pairs of square brackets and braces, which span several lines, which 
            % in turn contains expressions, poses problems like continuation lines.
            % The properties .previous_state and .previous_bracket_level are used
            % to carry over info from one line to the next.  
            %
            this.previous_state = m2uml.CharacterTypes.end_of_statement;
            this.previous_bracket_level = 0;
            
            mcodes(size(mcode_raw,1),1) = struct( 'row',"", 'kinds',[], 'block_type',[] ); 
            
            for rr = 1 : length( mcode_raw )   % loop over all rows
                mcodes(rr).kinds = this.classify_fsm( mcode_raw(rr) );
                mcodes(rr).row   = mcode_raw(rr);
            end
        end
        function    states = classify_fsm( this, str_code ) %
            
            % str_code  <1x1 string>    one line of code 
            %
            % states    <1xn double>    n is the number of characters in the line and 
            %                           its values as defined by m2uml.CharacterTypes
            
            % chr(jj) is orders of magnitude faster than extractBetween(str,jj,jj)  
            chr_code = char( str_code );   
            
            len = length( chr_code );
            if len == 0
                states = m2uml.CharacterTypes.end_of_statement;
                return                                                  %   RETURN
            end
            
            cur_state     = this.previous_state;
            bracket_level = this.previous_bracket_level;
            
            % pre-allocate
            inputs(1,len) = m2uml.InputTypes.null_input;
            states(1,len) = m2uml.CharacterTypes.null_statement;
            
            %   
            consecutive_dots = 0;
            
            for jj = 1 : len    % loop over all characters in the row, chr_code
                
                if chr_code(jj) == '.'  % Avoid a method call for every character
                    consecutive_dots ...
                    =   this.update_consecutive_dots( cur_state, consecutive_dots );
                else
                    consecutive_dots = 0;
                end
                
                cur_input = this.character_to_input_type( chr_code(jj) ); 
                
                %   2020-Q1, Depending on the context, change the value of cur_input from
                %   single_quote    --> transpose_blip or single_quote_in_brackets
                %   double_quote    --> double_quote_in_brackets
                %   closing_bracket --> outer_closing_bracket
                %   To handle closing_bracket the bracket nesting depth is monitored
                %   with the counter, bracket_level
                
                % 2020-06-22, The problem is that a single quote after a
                % closing_single_quote is not a transpose_blip. Furthermore,
                % single quote serves as escape character for single quote. It
                % might not be necessary to handle that correctly, but it must
                % not throw an error.
                
                switch cur_input
                    case m2uml.InputTypes.single_quote        %
                        if jj == 1
                            % A blip in position one cannot be anything but the start
                            % of a character constant. Thus, do nothing.
                        else
                            cur_input = this.determine_input_type_of_blip           ...
                                ( cur_input, cur_state, chr_code(jj-1), inputs(jj-1) );
                        end
                        
                    case m2uml.InputTypes.double_quote        %
                        %   do nothing
                        
                    case m2uml.InputTypes.opening_bracket     %
                        if  cur_state == m2uml.CharacterTypes.code_outside_brackets   ...
                        ||  cur_state == m2uml.CharacterTypes.code_in_brackets        ... 
                        ||  cur_state == m2uml.CharacterTypes.end_of_statement
                            bracket_level = bracket_level + 1;
                        end
                        
                    case m2uml.InputTypes.closing_bracket     %
                        if cur_state == m2uml.CharacterTypes.code_in_brackets
                            bracket_level = bracket_level - 1;
                        end
                        if bracket_level == 0
                            cur_input = m2uml.InputTypes.outer_closing_bracket;
                        end
                        
                    otherwise
                        %   do nothing
                end

                try
                    cur_state   = this.NextState( cur_input, cur_state );
                    states(jj)  = cur_state;
                    inputs(jj)  = cur_input;
                    if consecutive_dots >= 3
                        cur_state = m2uml.CharacterTypes.in_single_line_comment;
                        consecutive_dots = 0;    
                    end
                catch me
                    msg = [ sprintf( '%s\n', sprintf( '%1X', states ) ) ... 
                        ,   sprintf( '%s\n', sprintf( '%1X', inputs ) ) ];
                    me1 = MException( 'sfa:debug', msg );
                    me2 = addCause( me, me1 ); 
                    throw( me2 )
                end
            end
            
            this.carry_over_to_next_line( states, bracket_level )
            
            states = this.expand_closing_brackets_quotes( states, inputs );
        end
        
        function    num  = update_consecutive_dots( ~, cur_state, consecutive_dots )  %
            if  cur_state == m2uml.CharacterTypes.code_in_brackets   ...
            ||  cur_state == m2uml.CharacterTypes.code_outside_brackets
                num = consecutive_dots + 1;
            else
                num = 0;
            end
        end
        function    type = character_to_input_type( this, chr )                       %
            if double(chr) <= 127
                type = this.Char2Input( double(chr)+1 ); % zero based +1 
                if type == m2uml.InputTypes.null_input
                    type = m2uml.InputTypes.other_character;
                end
            else
                type = m2uml.InputTypes.other_character;
            end
        end
        function    type = determine_input_type_of_blip                         ...
                           ( this, cur_input, cur_state, prev_code_chr, prev_input )  %

            if  cur_state == m2uml.CharacterTypes.in_character_constant   ...
            ||  cur_state == m2uml.CharacterTypes.in_character_constant_in_brackets
        
                type = m2uml.InputTypes.closing_single_quote;

            elseif ( cur_state == m2uml.CharacterTypes.code_outside_brackets  ...
                  || cur_state == m2uml.CharacterTypes.code_in_brackets )     ...
            &&  ismember( prev_code_chr, this.pre_transpose_blip )            ...
            &&  not( prev_input == m2uml.InputTypes.closing_single_quote )
        
                type = m2uml.InputTypes.transpose_blip;

            elseif  cur_state == m2uml.CharacterTypes.code_outside_brackets ...
            ||  cur_state == m2uml.CharacterTypes.code_in_brackets          ...
            ||  cur_state == m2uml.CharacterTypes.end_of_statement
                %   normal start of character constant, pass on cur_input 
                
                type = cur_input;
                
            elseif cur_state == m2uml.CharacterTypes.code_in_brackets   ...
            &&  (   prev_input == m2uml.InputTypes.white_space          ...
                 || prev_input == m2uml.InputTypes.closing_single_quote )
                %   "triple blip case", pass on cur_input 
                
                type = cur_input;
                
            elseif cur_state == m2uml.CharacterTypes.in_single_line_comment ...
            ||  cur_state == m2uml.CharacterTypes.in_string_constant        ...  
            ||  cur_state == m2uml.CharacterTypes.in_string_constant_in_brackets
                %   in text or comment, thus pass on cur_input 
                
                type = cur_input;
                
            else
                %   should not occur
                keyboard % string constant???
            end
        end
        function    carry_over_to_next_line( this, states, bracket_level )            %

            %   End of line and outside_brackets "must" result in end of statement. At
            %   this point in this method an outer closing bracket will be classified
            %   as outside the brackets. 
            %
            
            if states(end) == m2uml.CharacterTypes.in_single_line_comment
                %   In the following example it's the character type before the
                %   comment in line two, which shall be be carried over to line three.
                %
                %     A = [ 1
                %         2 % two
                %         3 ]
                
                is_in_comment = states==m2uml.CharacterTypes.in_single_line_comment;
                ix = find( not( is_in_comment ), 1,'last' );
                if isempty( ix )
                    %   this.previous_* from previous iteration are still valid
                else
                    this.previous_state         = states( ix );
                    this.previous_bracket_level = bracket_level;
                end
            else
                if states(end) == m2uml.CharacterTypes.code_outside_brackets
                    this.previous_state         = m2uml.CharacterTypes.end_of_statement;
                    this.previous_bracket_level = 0;
                else
                    this.previous_state         = states(end);
                    this.previous_bracket_level = bracket_level;
                end
            end
        end
        
        function    mcodes = classify_rows( this, mcodes )              %
            
            % 0. null_block     help throw exceptions in case of logic errors
            % 1. outside_block  leading and trailing comments ...
            % 2. classdef       
            % 3. properties     properties block
            % 4. methods        this one is tricky!*
            % 5. function       main and local functions, but NOT methods
            % 6. events         events block
            % 7. enumeration    enumeration block
            % 8. todofixme      todofixme rows
            % 9. end            ??? blocks do NOT include the closing "end"
            %

            mcodes = this.determine_row_blocktype( mcodes );
            
            if this.stack.size >= 1
                this.check_on_unmatched_ends( mcodes )
            elseif this.stack.size <= -1
                error( 'm2uml:internal:error'                          ...
                    ,  'Mismatch between block begin keywords and end' )
            else
                % fine
            end
            
            %   I reckon that expand_closing_end() (like expand_closing_brackets_quotes) 
            %   isn't needed
            
            %   And finally, indicate the TODOFIXME rows.
            cac = regexp( [mcodes.row], regex.todofixme_annotation, 'tokens', 'once' );
            has = ( cellfun( @length, cac ) >= 1 );
            [mcodes(has).block_type] = deal( this.block("todofixme") );
        end
        function    mcodes = determine_row_blocktype( this, mcodes )    %
            
            prev_block = this.block("outside_block");
            len = numel( mcodes );
            this.stack.clear
            
            for ixr = 1 : len           % loop over all rows
                % eos, end of statement 
                eos = find( mcodes(ixr).kinds == m2uml.CharacterTypes.end_of_statement );
                strlen = strlength( mcodes(ixr).row );
                if numel(eos)==0 || strlen==0
                    eos = 0;                        % Why not strlen ???
                elseif eos(end) < strlen
                    % There is no delimiter at the end of the line
                    eos(end+1) = strlen;    %#ok<AGROW>
                elseif eos(end) == strlen
                    % The line is terminated by a delimiter
                    % Do nothing
                else
                    keyboard
                end

                %   Keywords can only exist in code outside brackets
                msk = ( mcodes(ixr).kinds == m2uml.CharacterTypes.code_outside_brackets );
                chr_msk = char( mcodes(ixr).row );
                chr_msk(not(msk)) = char(32);
                
                if numel(eos) == 1
                    % The row contains exactly ONE statement, with at most one keyword.
                    cur_block  = next_block_( this, prev_block, string(chr_msk) );
                    prev_block = cur_block;
                    
                elseif numel(eos) >= 2 
                    % The row contains TWO or more statements. 
                    bos = [ 1, eos(1:end-1)+1 ];    % beginning of statement
                    
                    for ixs = 1 : numel( eos )      % loop over all statements in row 
                        
                        cur_block = next_block_( this, prev_block               ...
                                    ,   string( chr_msk( bos(ixs):eos(ixs) ) )  ); 
                        
                        prev_block = cur_block;
                    end
                else
                    keyboard
                end
                mcodes(ixr).block_type = cur_block;
            end
        end
        function    check_on_unmatched_ends( this, mcodes )             %
            %   2020-09-29, I deleted the code because it wasn't meaningsful
            %   and it didn't handle files in packages correctly. (It issued
            %   a bunch of warnings.)
            variable_not_used( this, mcodes )
        end
    end
    methods     ( Access = private )        % 
        function    mcode_raw = read_source_code( this, ffs )                       %

            txt = convertCharsToStrings( txt2str( ffs ) );
            mcode_raw = strsplit( txt, newline, 'CollapseDelimiters',false );
            mcode_raw = reshape( mcode_raw, [],1 );
            variable_not_used( this )
        end
        function    mcode_raw = concatenate_continuation_lines( this, mcode_raw )   %
            
            % Force: The concatenated lines tends to get very long with a lot of space
            % in them. That is awkward when testing and it consumes cpu-cycles when 
            % classified. Let exactly two spaces separate trimmed concatenated lines.
            %
            % An ellipsis outside quoted texts is equivalent to a space.
            % x = [1.23...
            % 4.56];
            
            [ has, stripped ] = this.has_continuation_ellipsis( mcode_raw );
            
            for jj = length( mcode_raw )-1 : -1 : 1  % last line cannot have an ellipsis
               if has(jj)
                   % Q&D, 
                   mcode_raw(jj)   = stripped(jj) + "  " + strtrim(mcode_raw(jj+1));
                   mcode_raw(jj+1) = "";
               end
            end
        end
        function    [has,str] = has_continuation_ellipsis( this, mcode_raw )        %
        % has_continuation_ellipsis determines whether lines of mcode_raw have ellipsis
        %
        % Syntax:
        %   [ has, str ] = has_continuation_ellipsis( mcode_raw )
        %
        % Inputs:
        %   mcode_raw  <nx1 cell>  cell array of character rows
        %
        % Outputs:
        %   has     <nx1 logical>   true if row contains a continuation ellipsis
        %   str     <nx1 str>       the code left of the continuation ellipsis. 
        %
        % Description:
        %   ellipsis = has_continuation_ellipsis(mcode_raw) returns true for the rows of
        %   mcode_raw that has a continuation ellipsis. The purpose of this function is 
        %   to avoid ellipsis in character and string constants and in comments.
        %
            len = length( mcode_raw );
            has = false( len, 1 );
            str = repmat( "", len, 1 );

            for jj = 1 : len    % loop over all rows
                if contains( mcode_raw(jj), '...' )
                    
                    %   Here part of the functionality this.classify_fsm is used
                    %   outside of its ordinary context. This raises two problems
                    %
                    %   1.1 Problem: When called by this.classify, state and
                    %   bracket_level are inherited from the end of previous line.
                    %   Here classify_fsm is called for some unrelated lines with
                    %   ellipsis. This is possible because character and string
                    %   constants cannot span multiple lines and bracket_level does
                    %   not affect whether an ellipsis is a continuation ellipsis or
                    %   not.
                    %
                    %   1.2 Solution: Values of bracket_level below zero cause an
                    %   be a error to be thrown. previous_bracket_level = 17 seems 
                    %   to be safe value. And consequently previous_state =
                    %   CharacterTypes.code_in_brackets.
                    %
                    %   2.1 2020-08-20, Problem: Currently, characters to right of the
                    %   ellipsis must be characters that are allowed in code (# is not).
                    %
                    %   So wasn't it a mistake to use this.classify_fsm in the first 
                    %   place?
                    
                    this.previous_state	= m2uml.CharacterTypes.code_in_brackets;
                    this.previous_bracket_level = 17;
                    
                    sts = this.classify_fsm( mcode_raw(jj) );
                    msk = ismember( sts, [ m2uml.CharacterTypes.code_in_brackets
                                           m2uml.CharacterTypes.code_outside_brackets ] );
                                       
                    chr = char( mcode_raw(jj) ); 
                    chr(not(msk)) = char(32);
                    cac = strsplit( chr, '...' );
                    ixe = length(cac{1});   % -1; 2020-07-11, Why "-1" in the first place?
                    
                    if length( cac ) >= 2
                        chr = char( mcode_raw(jj) ); 
                        has(jj) = true;
                        str(jj) = string( chr(1:ixe) );
                    end
                end
            end
            str = strtrim( str );   % 2020-07-13,
        end
        % 
        function    mcode_raw = blank_multiline_comments( this, mcode_raw )         %
        % blank_multiline_comments replaces multi-line comments with empty lines

            xpr_begin = '^[\x20\x09]*\x25\x7B[\x20\x09]*$';  % literal: %{ between whitespace
            xpr_end   = '^[\x20\x09]*\x25\x7D[\x20\x09]*$';  % literal: %} between whitespace

            isb = not( cellfun( @isempty, regexp( mcode_raw, xpr_begin ) ) );
            ise = not( cellfun( @isempty, regexp( mcode_raw, xpr_end   ) ) );
            ise = [ false; ise ];
            isb = [ isb; false ];

            multiline_comment_depth = cumsum( double(isb) - double(ise) );

            assert( multiline_comment_depth(end) == 0           ...
                ,   'm2uml:blank_multiline_comments:MisMatch'   ...
                ,   'Multiline comments mismatch in "%s"'       ...
                ,   mcode_raw{1}                                )

            mcode_raw( multiline_comment_depth >= 1 ) = {''};

            variable_not_used( this )
        end
        function    states = expand_closing_brackets_quotes( this, states, inputs ) %
            
            %   states <CharacterTypes>
            %   So far the closing brackets and quotes have the type of the character
            %   preceding the enclosed sequence of characters, e.g. in
            %           a = sas.( 'name' );
            % before    2222222233444443321
            % after     2222222233444444331
            %                          ^ ^
            
            %   The order between the character types in this array matters! The array,
            %   states, may be modified in each iteration of the loop below. Thus, the
            %   cases might see different values of the array, states. 
            character_type_array  = [ 
                            m2uml.CharacterTypes.in_character_constant                ...
                        ,   m2uml.CharacterTypes.in_character_constant_in_brackets    ...
                        ,   m2uml.CharacterTypes.in_string_constant                   ...
                        ,   m2uml.CharacterTypes.in_string_constant_in_brackets       ...
                        ,   m2uml.CharacterTypes.code_in_brackets
                        ];
            
            if any( ismember( states, character_type_array ) )
                % continue in the function
            else
                return                                                  %   RETURN
            end
        
            for  character_type = character_type_array
                %
                switch character_type
                    case { m2uml.CharacterTypes.in_character_constant             ...
                         , m2uml.CharacterTypes.in_character_constant_in_brackets ...
                         , m2uml.CharacterTypes.in_string_constant                ...
                         , m2uml.CharacterTypes.in_string_constant_in_brackets    } 
                     
                        upstream  = [ m2uml.CharacterTypes.null_statement, states(1:end-1) ];
                        overwrite = not( states == character_type ) ...
                                    & ( upstream == character_type );
                        
                    case { m2uml.CharacterTypes.code_in_brackets }        %
                        
                        overwrite   = inputs == m2uml.InputTypes.closing_bracket      ...
                                    | inputs == m2uml.InputTypes.outer_closing_bracket;
                                
                        for ix = reshape( find( overwrite ), 1,[] )
                            if  all( ismember( states( max(1,ix-1):min(ix+1,end) ) ...
                                , [ m2uml.CharacterTypes.in_character_constant
                                    m2uml.CharacterTypes.in_character_constant_in_brackets 
                                    m2uml.CharacterTypes.in_string_constant
                                    m2uml.CharacterTypes.in_string_constant_in_brackets
                                ] ) )
                                overwrite( ix ) = false;
                            end
                        end
                    otherwise                                       %
                        continue                                    %   CONTINUE
                end
                if any( overwrite )
                    states( overwrite ) = character_type;
                end
            end
            variable_not_used( this )
        end
        %
        function    cur_block = next_block_( this, prev_block, str_msk )            %
            
            %   Only main functions are attributed block_type==5; methods, local and 
            %   nested functions are ignored.   
            
            key = regexp( str_msk, this.block_xpr, 'tokens', 'once' );
            
            assert( numel( key ) <= 1, 'm2uml:SFA:MultipleKeywords'     ...
                ,   'More than one keyword in statement, "%s"', str_msk )

            if isempty( key )
                cur_block = prev_block;
            elseif any( this.block( key ) == (10:15) )      % magic block numbers
                % for, while, switch, try, if, parfor 
                cur_block = prev_block;
                this.stack.push( prev_block );
            else
                if any( this.block( key ) == [1,2,3,6,7] )  % magic block numbers       
                    % outside_block, classdef, properties, events, enumeration
                    cur_block = this.block( key );  
                    this.stack.push( prev_block );
                elseif key == "methods"     % the tricky one
%                   this.is_in_methods_block = true;
                    cur_block = this.block( key );
                    this.stack.push( prev_block );
                elseif key == "function"    % the tricky one
                    if prev_block == 1      % outside_block 
                        cur_block = this.block( key );  
                        this.stack.push( prev_block );
                    else
                        cur_block = prev_block;
                        this.stack.push( prev_block );
                    end
                elseif key == "end"
                    cur_block = this.stack.pop;
                else
                    keyboard
                end
            end
        end
    end
end
