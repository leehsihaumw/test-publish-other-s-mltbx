function    graphic_file = puml2graphic( varargin )   
% puml2graphic takes a puml-file and creates an image file  
%
% Syntax: 
%       graphic_file = m2uml.puml2graphic                   ...
%               (   'PlantUmlScript'    , filespec          ... required
%               ,   'UserOptions'       , user_options      ... optional
%               ,   'GraphicFormat'     , image_file_type   ... optional
%               );
%
% Input:
%       filespec        full filespec of the PlantUml script   
%       user_options    a scalar struct or cell row of scalar structs. The structs are 
%                       "subset" of the struct defined by m2uml.factory_options. The
%                       user_options structs has only the fields, the values of which
%                       differs from m2uml.factory_options.
%      image_file_type  'svg', 'png', ...
%
% Output:
%       graphic_file    full filespec of the image file    
%
% Description:
%       m2uml.puml2graphic takes a PlantUML-script and creates an image file. It runs 
%       a local installation of PlantUML. 
%
% Examples:
%     m2uml.puml2graphic( 'PlantUmlScript', 'd:\m\tmp\test.puml' );
% 
% See also: m2uml.call_local_PlantUML, m2uml.create_PlantUML_script,
%           m2uml.display_class_diagram, m2uml.run

    ipp = InputPreprocessor( {
    ...   Name              Default value       Class       Constraint  
        3 'PlantUmlScript'  nan                 {'char'}    {'row'}
        3 'UserOptions'     struct([]) {'cell','struct'}    {'row'}
        3 'GraphicFormat'   ''                  {'char'}    {'row'}
        } );
    
    inv = ipp.parse( varargin{:} );
    
    %   Build an option stucture of input argument values 
    if not( isempty( inv.GraphicFormat ) )
        arguments.General.GraphicFormat = inv.GraphicFormat;
    else
        arguments = struct([]);     
    end
    
%   DONE: 2019-12-14, Set the color of the visibility icons. Especially the face color
%   of the icon of protected methods itched. See https://forum.plantuml.net/10540
%   /default-color-edges-visibility-protected-methods-identical
%
%   https://plantuml.com/command-line
%   -config "file"  Include a file before each diagram, e.g. including skínparam ...
    
    if isa( inv.UserOptions, 'struct' )
        options = m2uml.merge_options( inv.UserOptions, arguments );
    else
        if all( cellfun( @(uo) isa(uo,'struct'), inv.UserOptions ) )
            options = m2uml.merge_options( inv.UserOptions{:}, arguments );
        else
            error(  'm2uml:puml2graphic:CannotFindFile'                         ...
                ,   'The value of ''UserOptions'' is not a cell row of structs' )
        end
    end
    
    sad = dir( fullfile( m2uml_root,'\**\VisibilityColorConfigFile.cfg') );
    assert( isscalar( sad )                     ...
        ,   'm2uml:puml2graphic:CannotFindFile' ...
        ,   'Failed to find one unique "%s"'    ...
        ,   'VisibilityColorConfigFile.cfg'     )
    
    cmd_str = sprintf( 'java -jar %s %s -config "%s" -t%s'  ...
                    ,   options.General.PlantUmlJar         ...
                    ,   inv.PlantUmlScript                  ...
                    ,   fullfile( sad.folder, sad.name )    ...
                    ,   options.General.GraphicFormat       );

    [sts,msg] = system( cmd_str );
    
    assert( sts == 0                                        ...
        ,   'Failed to create a "%s" file from "%s":\n%s'   ...
        ,   options.General.GraphicFormat                   ...
        ,   inv.PlantUmlScript                              ...
        ,   msg                                             );
    
    [ folder, file ] = fileparts( inv.PlantUmlScript );

    graphic_file = fullfile( folder, [file,'.',options.General.GraphicFormat] );
end 
