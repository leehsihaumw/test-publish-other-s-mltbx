classdef    TodoFixme  < m2uml.Element
% TodoFixme knows all data to make the code for ONE entry.  

%   TODO: name is never set for TodoFixme objects
    properties                                      %
        % Data used for the toodfixme code row
        data = struct(  'type'      ,   ''  ...
                    ,   'tooltip'   ,   ''  ...
                    ,   'line'      ,   []  ...
                    );
        % SourceFile instance, with the properties: ffs,fqn,type,namespace,basename
        source_file (1,1)   m2uml.SourceFile
        max_label_width
    end
    methods                                         %
        function    this = TodoFixme( varargin )    %
            % Explicit constructor
            this@m2uml.Element( varargin{:} );
        end
    end
end
% NOTE: According to PlantUml "\\n" in the text string of a tooltip of the
% PlantUml script will display as a line-break. PlantUml converts "\n" in
% the script to "&#10;" in the svg-file. Firefox displays a multi-line
% tooltip of the svg-file as expected. Matlab R2018a web concatenates the
% lines into a single-line. Google doesn't help much.
