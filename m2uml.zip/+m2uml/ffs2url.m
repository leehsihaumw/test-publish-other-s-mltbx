function    url = ffs2url( ffs )
% ffs2url
%
% m2uml.ffs2url('h:\m\PiaX\IDE_tools_test\work\test_755.svg')
% ans =
%     'file:///h:/m/PiaX/IDE_tools_test/work/test_755.svg'

    cac = regexp( ffs, filesep, 'split' );   
    url = [ 'file:///', strjoin(cac,'/') ];
end
