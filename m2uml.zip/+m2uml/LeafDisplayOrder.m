classdef    LeafDisplayOrder < m2uml.Doer      %
% LeafDisplayOrder - 

    properties  ( Access = private )                            %
        %
        options     %   
    end
    methods                                                     %
        function    this = LeafDisplayOrder( varargin )         %
            %
            narginchk( 0, 1 )
            if nargin == 1
                this.options = varargin{1};
            end
        end
    end
    methods     ( Access = ?m2uml.Doer )                        %
        function    execute_PlantUmlScript  ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Class           ( this, obj )       %
        %   Sort the with respect to type, visibility and name

            %%  Description                                                     .
            %   Below the title compartment, the class box contains a number of
            %   compartments, which are separated by separators and contains rows 
            %   of text. (Here separators and rows of text are called elements.) 
            %   This method performes the following steps
            %   *   Adds objects of m2uml.Separator to the list of children of 
            %       the object, obj.number_of_elements is then the length of
            %       obj.Children
            %   *   Creates a matrix, tbs(number_of_elements,3), of whole numbers
            %       such that sortrows(tbs) returns the order that the elements
            %       shall recognize. 
            %   *   Rearrange the obj.Children, which now includes separators, 
            %       to match the order, in which they shall be displayed in the
            %       class box. 
            %       
            %   The compartments are sorted in the standard order: properties, 
            %   methods, events, enums, and todofixme at the bottom.
            %   Properties and methods are sorted public,protected,private and 
            %   within each in lexical order. (I fail to find a recommended 
            %   order and stick to the order of m2uml ver 1.1.) The constructor
            %   is at the top of the methods.
            %   TodoFixme are displayed fixme,todo,note as red,yellow,green.
            
            %   TODO: A label in the separator. With the number of compartments
            %   growing it might make sense to add labels to the separators, e.g.
            %   '..enum..'. It is possible to have a property separator, the
            %   default value of which is an empty string. That doesn't affects
            %   the current visual appearance and it would allow for showing
            %   labels. Why not .isSelected=false? Uncle Bob would complain,
            %   adding a separator at the top requires many small changes in the
            %   code.

            %   Add separators to the list of children. There shall always be a
            %   separator between the properties and the methods. There shall be a
            %   separator above enumeration, events and/or todofixmes, only when
            %   they have entries. 
            %   Classes with a sole enumeration block shall not have any
            %   sepatators. The implicit constructor shall not be shown. 
            %
            %   tbs(:,1)    content
            %   ----------|------------   
            %    1          separator
            %    2          properties 
            %    3          separator
            %    4          methods
            %    5          separator       \   The class box shall not   
            %    6          events          |   show empty compartments 
            %    7          separator       |   for these elements 
            %    8          enumeration     |
            %    9          separator       |
            %   10          todofixme       /
            %%                                                                  .
            %   the order of class_list controls the order, in which the
            %   compartments are displayed in the class-box
            class_fqn_list = {'m2uml.Property','m2uml.Method','m2uml.Event' ...
                            , 'm2uml.Enumeration','m2uml.TodoFixme'         };
                     
            %   The child base name is used as compartment name, e.g. 'Property',
            %   'Method', etc., but not Title:(
            compartments = string( strrep( class_fqn_list, 'm2uml.', '' ) );
            
            class_of_children = arrayfun( @class, obj.children, 'uni',false );
            
            assert( all( ismember( class_of_children, class_fqn_list ) )        ...
                ,   'm2uml:LeafDisplayOrder:execute_Class:UnExpectedClass'  ...
                ,   'Unexpected child, "xx", of class, "%s"'                ...
                ,   obj.name                                                )
            
            [~,iiCompartment_of_children] = ismember( class_of_children, class_fqn_list );
            
            number_of_compartments = length( compartments );
             
            %   CREATE Separators
            for jj = 1 : number_of_compartments
                str = compartments{jj};
                if this.options.Class.SeparatorLabel
                    obj.children(1,end+1) = m2uml.Separator( str, obj, ['..',str,'..'] );
                else
                % DONE: set sep.isSelected = false; for the top separator after sorting.
                    sep = m2uml.Separator( str, obj, '---' );
                    if jj == 1
                        %   Separator of Property. Don't show as default.
                        sep.isSelected = false;
                    end
                    obj.children(1,end+1) = sep;
                end
            end
            
            %   COMPARTMENT ORDER, tbs(:,1)
            tbs = nan( length( obj.children ), 3 );     % to be used for sorting
            len = length( iiCompartment_of_children );  % number of elements
            tbs( 1:len, 1 ) = reshape( 2*iiCompartment_of_children, [],1 );
            %   and separators
            tbs( len+1:end, 1 ) = reshape( (1:2:2*number_of_compartments), [],1 );
            %   more sorting criteria don't apply to separators
            tbs( len+1:end, 2:3 ) = 99; 
            
            %   VISIBILITY. Why bottom to top order vs compartment? tbs(:,2)
            %   Bottom compartment
            is_compartment_of_children = ...
            ismember( class_of_children, class_fqn_list(number_of_compartments) ); 
        
            %    loop over all children, which go into the bottom compartment
            for ix = find( is_compartment_of_children )  
                type = obj.children(ix).data.type;
                [ ~, tbs(ix,2) ] = ismember( type, {'fixme','todo','note'} );
            end
            %   Enumeration, Event, Method, Property
            for jj = number_of_compartments-1 : -1 : 1
                %   loop over all children, which go into the jjth compartment
                for ix = find( iiCompartment_of_children == jj )    
                    vis = obj.children(ix).data.visibility;
                    [~, tbs(ix,2) ] = ismember( vis, {'public','protected','private'} );
                end
            end

            %   LEXICAL ORDER, tbs(:,3)
            %   Loop over Property, Method and Envent, but NOT over Enumeration
            %   or TodoFixme. The order of the enumeration elements in the source
            %   code is important to keep. The todofixme are not meaningsful to
            %   sort lexically. 
            for jj = [1,2,3]            %   Property, Method, Event   
                ix = find( iiCompartment_of_children == jj );
                if not( isempty( ix ) )
                    [ ~, ixx ]  = sort( lower( {obj.children(ix).name} ) );
                    [ ~, ixn ]  = sort( ixx );
                    tbs( ix, 3 )= ixn(:);
                end
            end
            for jj = [4,5]              %   Enumeration, TodoFixme
                ix = find( iiCompartment_of_children == jj );
                if not( isempty( ix ) )
                    tbs( ix, 3 ) = 0;
                end
            end
            
            assert( not( any( isnan( tbs(:) ) ) )       ...
                ,   'm2uml:LeafDisplayOrder:Unexpected' ...
                ,   'Sorting failed \n%scontains NaNs'  ...
                ,   tprintf( [], '%d,%d,%d\n', tbs )    )
            
            %   Move the CONSTRUCTOR to the top. The class name is identical to the
            %   constructor name. 
            ixm = find( iiCompartment_of_children == 2 );  % methods
            ix  = find( strcmp( obj.name, {obj.children(ixm).name} ) ); 
            tbs( ixm(ix), 1 ) = tbs( ixm(ix), 1 ) - 0.5;
            
            [ ~, ix_sort ] = sortrows( tbs, 1:size(tbs,2) ); 
            obj.children   = obj.children(ix_sort);
            %   
            % Separators have been added; update class_of_children
            class_of_children = arrayfun( @class, obj.children, 'uni',false ); 
            %
            %%  Display or hide compartments. Complete rewrite 2020-05-08.      .
            %   The old code relied entirely on the PlantUML keywords "show" and "hide". 
            %   It became too complicated to handle Enumeration and Event together with
            %   all different on/off options. 

            %   Create a structure, is, ...
            for element = cat( 2, {'Separator'}, compartments ) 
                is.(element{1}) = ismember( class_of_children, ['m2uml.',element{1}] );
            end
            
            %   Create an anonymous function to make some of the following if-statements
            %   more readable. 
            nothing_to_display = @(item)                            ...
                (   sum(double( is.(item) )) == 0                   ...
                 || not(any([obj.children(is.(item)).isSelected]))  );
            
            %   The array, separators, holds temporary handles of the underlying 
            %   objects. The purpose of this array is to facilitate setting 
            %   .isSelected values by simpler indexing. 
            separators = obj.children( is.Separator );
                 
            %   Problem: hide and show are not compatible with explicite
            %   separators. Event, Enum and TodoFixme requires explicite
            %   seaparators. Either explicite or automatic, not both in
            %   the same PlantUML script. Furthermore, all three uses the 
            %   {field} modifier. It would be possible to use automatic 
            %   separators in some cases. However, in m2uml I'll use 
            %   explicite separators exclusively, with a few exeptions.
            %
            %   The control of display of compartments is done with isSelected.

            %   To handle the Properties and Methods compartments of Enumeration and
            %   "ordinary" classes in parallel is over my head. Thus one at a time
            if obj.data.isEnumeration
                %   Set isSelected=false for implicite constructors 
                %   that are the sole method
                if  sum(double( is.Method )) == 1       ...
                &&  obj.children(is.Method).data.isImplicitConstructor
                    obj.children(is.Method).isSelected = false;        
                end
                
                %   Set isSelected=false for the separator of methods, 
                %   in case there is no method or property to show. 
                if nothing_to_display('Property') && nothing_to_display('Method')
                    separators( m2uml.Elements.Method ).isSelected = false;  
                end
            else
                %   The Properties and Methods compartments shall be displayed for
                %   "ordinary" classes (even if empty) when any other compartment 
                %   is displayed. There is possiblya case where only the Title 
                %   compartment shall be displayed.
                17;
            end
            
            for element = ["Event","Enumeration","TodoFixme"]         
                if nothing_to_display( element )
                    separators( m2uml.Elements.(element)).isSelected = false; 
                end
            end
            
            if  obj.data.isEnumeration
                %   Set isSelected=false for the separators of empty compartments
                %   preceeding the first compartment with items to show. (For the 
                %   separator of Properrty isSelected==false already.)
                nothing_so_far = true; 
                for element = compartments
                    nothing_so_far = all( [nothing_so_far, nothing_to_display(element) ]);
                    if not( nothing_so_far )
                        %   If there are elements to be displayed in the methods
                        %   compartment and not in the property compartment an empty
                        %   property compartment shall be displayed. (And the other 
                        %   way round.)
                        if not( element == "Method" )
                            separators( m2uml.Elements.(element)).isSelected = false;
                        end
                        break
                    end
                end
                %   
                if not(any([separators.isSelected]))
                    %   Suppress the automatic separator that would create an 
                    %   empty compartment at the bottom of the box of a class
                    %   that has a sole enumeration block. PlantUML takes the 
                    %   enum members as "properties" and adds an empty methods
                    %   compartment. (Here, there is no explicite separator.)  
                    %   To suppress use either "hide enum_name empty methods" 
                    %   or "hide enum empty methods". I chose the former  
                    %   because it's more specific.
                    chr = sprintf('hide %s empty methods', obj.name ); 
                    scr = m2uml.SingleCodeRow( 'HideMethods', obj.parent, chr );
                    obj.parent.children(end+1) = scr;
                    if nothing_to_display( "Enumeration" )
                        chr = sprintf('hide %s empty fields', obj.name ); 
                        scr = m2uml.SingleCodeRow( 'HideFields', obj.parent, chr );
                        obj.parent.children(end+1) = scr;
                    end
                end
            end
        end
        function    execute_Function        (    ~, obj )       %
        %   Sort the with respect to visibility, i.e. {'fixme','todo','note'}
        
            len = numel(obj.children);
            num = nan( len, 1 );
            
            %   Access level
            for ix = 1:len   % TodoFixme
                type = obj.children(ix).data.type;
                [~,num(ix)] = ismember( type, {'fixme','todo','note'} );
            end
            
            assert( not( any( isnan( num(:) ) ) ), 'm2uml:LeafDisplayOrder:Unexpected' ...
                ,   'Sorting failed \n%scontains NaNs', tprintf([],'%d\n',num ) )
            
            [ ~, ix_sort ] = sort( num ); 
            obj.children   = obj.children(ix_sort);
            
            % Hide the {fields} compartment if there is no TodoFixme
            chr = sprintf('hide %s empty fields', obj.name ); 
            scr = m2uml.SingleCodeRow( 'HideFields', obj.parent, chr );
            obj.parent.children(end+1) = scr;
            
            % Hide the {methods} compartment. It shall always be empty.
            chr = sprintf('hide %s empty methods', obj.name );
            scr = m2uml.SingleCodeRow( 'HideMethods', obj.parent, chr );
            obj.parent.children(end+1) = scr;
        end
        function    execute_Package         ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end                                             
    end
end
