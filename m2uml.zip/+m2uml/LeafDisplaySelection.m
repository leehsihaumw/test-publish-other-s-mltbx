classdef    LeafDisplaySelection < m2uml.Doer   %
   
    properties  ( SetAccess = private )         %
        %
        options
    end
    methods                                     %
        function    this = LeafDisplaySelection( varargin )     %
            %
            narginchk( 0, 1 )
            if nargin == 1
                this.options = varargin{1};
            end
        end
    end
    methods     ( Access = ?m2uml.Doer )                        %
        function    execute_PlantUmlScript  ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Class           ( this, obj )       %
            %
            this.execute_for_all_children( obj )
         end
        function    execute_Enumeration     ( this, obj )       %
            obj.isSelected = this.options.Enumeration.show;
        end
        function    execute_Event           ( this, obj )       %
            obj.isSelected = this.options.Event.(obj.data.visibility);
        end
        function    execute_Footer          ( this, obj )       %
            obj.isSelected = this.options.Footer.On;
        end
        function    execute_Function        ( this, obj )       %
            %
            % Set .isSelected for all children accourding to this.options
            this.execute_for_all_children( obj )    
            %   2020-09-12, poi: deleted a chunk of code that derived is_compartment
        end
        function    execute_Header          ( this, obj )       %
            obj.isSelected = this.options.Header.On;
        end
        function    execute_Method          ( this, obj )       %
            if obj.data.isImplicitConstructor
                %   Q&D: Implicite constructor shall not be displayed. Maybe include
                %   it in options. 
                obj.isSelected = false;
            else
                obj.isSelected = this.options.Method.(obj.data.visibility);
            end
            if numel(obj.name)>=4 && any( ismember( obj.name(1:4), {'set.','get.'} ) )
                % Must not overwrite a current false by true
                if not( this.options.Method.setget )
                    obj.isSelected = false;
                end
            end
        end
        function    execute_Package         ( this, obj )       %
            this.execute_for_all_children( obj )
        end
        function    execute_Property        ( this, obj )       %
            obj.isSelected = this.options.Property.(obj.data.visibility);
        end
        function    execute_Relationship    ( this, obj )       %
            obj.isSelected = this.options.Diagram.Generalizations;
        end
        function    execute_SingleCodeRow   ( this, obj )       %
            
            switch obj.name
                case    'direction'
                    obj.isSelected = not( this.options.Diagram.TopToBottom );
                case    'mono'
                    obj.isSelected = this.options.Diagram.Monospaced;
                case    'ortho'
                    obj.isSelected = not( this.options.Diagram.LinetypeDefault );
                case    'scale'
                    obj.isSelected = false;
                case    'user'
                    % do nothing
                otherwise
                    error(  'm2uml:LeafDisplaySelection:Unexpected' ...
                        ,   'Unexpected value of obj.name: "%s"'    ...
                        ,   obj.name )
            end
        end
        function    execute_Skinparam       ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Title           ( this, obj )       %
            obj.isSelected = this.options.Title.On;
        end
        function    execute_TodoFixme       ( this, obj )       %
            obj.isSelected = this.options.TodoFixme.(obj.data.type);
        end
    end
end
