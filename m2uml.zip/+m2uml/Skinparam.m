classdef    Skinparam  < m2uml.Element
% Skinparam knows all data needed to make a skinparam block code.  

    properties                                      %
        % Children of class include objects of SingleCodeRow
        children = m2uml.SingleCodeRow.empty(1,0);
    end
    methods                                         %
        function    this = Skinparam( varargin )    %
            % Explicit constructor
            this@m2uml.Element( varargin{:} );
        end
    end
end
