classdef 	Elements < double
 
    enumeration
        Property      (1)
        Method        (2)
        Event         (3)
        Enumeration   (4)
        TodoFixme     (5)
    end
end
