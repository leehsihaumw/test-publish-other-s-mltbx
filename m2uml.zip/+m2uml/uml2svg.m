function    uml2svg( varargin )
% m2uml.uml2svg takes a puml-file and creates an svg-file
%
% Syntax: 
%       m2uml.uml2web( 'PlantUmlScript', plantuml_script ); 
%
% Input Parameters:
%       plantuml_script PlantUML script
% 
% Output:
%       A svg-file containing the class diagram in the same folder as the PLantUML script
%
% Examples:
%     m2uml.uml2svg('PlantUmlScript','...\m2uml\temp.puml')
%
% Wishlist:
    
    ipp = InputPreprocessor( {
        3 'PlantUmlScript'  nan     {'char'}    {'FileExist'}
        } );
    inv = ipp.parse( varargin{:} );
    
    [ arguments.General.WorkingFolder, arguments.General.FileBaseName ] ...
    =   fileparts( inv.PlantUmlScript );    
    
    m2uml.puml2graphic                                      ...
          (   'PlantUmlScript'    , inv.PlantUmlScript      ...  
          ,   'UserOptions'       , {v11_options,arguments} ...  
          ,   'GraphicFormat'     , 'svg'                   );
end
