function    [ puml_arrows, relationship_table ] = search_relationships( callers, callees )
% search_relationships produces a set of potential relationship arrows 
%
% Syntax:
%    [ puml_arrows, relationship_table ] = search_relationships( callers )
%    [ puml_arrows, relationship_table ] = search_relationships( callers, callees )
%
% Inputs:
%    callers -  cell column of fully qualified names, potential sources         
%    callees -  cell column of fully qualified names, potential targets  
%
% Outputs:
%    arrows             - cell column of puml-arrow-code 
%    relationship_table - <nx2 table>     
%
% Description:
% TODO: description text missing
% Example: 
%    
% See also: 
%    

%#ok<*AGROW>

    narginchk(1,2)
    if nargin == 1
        callees = callers;
    end
        
    relationship_table  = table( 'Size'         , [ 0, 2 ]              ...
                               , 'VariableNames', ["source","target"]   ...
                               , 'VariableTypes', ["string","string"]   );
    
    len = length( callers );
    for jj = 1 : len
        
        ffs_req_row = matlab.codetools.requiredFilesAndProducts( callers{jj}, 'toponly' );
        
        for ffs_req = ffs_req_row   % loop over all required m-files
            
            if contains( ffs_req, ["built-in"] )    %#ok<NBRAK>
                continue
            end
            
            fqn_req = ffs2fqn( ffs_req{:} ); 
            if  strcmp( fqn_req, callers{jj} )              ...
            ||  ismember( fqn_req, superclasses( callers{jj} ) )
                continue
            end
            if ismember( fqn_req, callees )
                relationship_table{end+1,:} = [ string(callers{jj}), string(fqn_req) ];
            end
        end
    end
    
    relationship_table = unique( relationship_table, 'rows' );
    
    len_arrows  = size( relationship_table, 1 ); 
    puml_arrows = cell( len_arrows, 1 );
    
    str_width   = max( strlength( relationship_table.source ) );
    format_spec = sprintf( '%%-%ds --> %%s', str_width );     
    
    for jj = 1 : len_arrows
        puml_arrows{jj} = sprintf(  format_spec                     ...
                                ,   relationship_table.source(jj)   ...
                                ,   relationship_table.target(jj)   );
    end
end
