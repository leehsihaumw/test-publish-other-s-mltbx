classdef    MetaDataScanner < m2uml.Doer                           %
% MetaDataScanner    

%#ok<*AGROW>
    methods     ( Access = ?m2uml.Doer )                        %
        function    execute_PlantUmlScript  ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Class           ( this, obj )       %
            %
            objmeta = meta.class.fromName( obj.source_file.fqn );
             
            obj.data.CircleCharacter = this.getCircleCharacter( objmeta );   
            obj.data.isAbstract      = objmeta.Abstract;
            obj.data.isEnumeration   = objmeta.Enumeration; 
            
% Property leafs
            for prp_meta = reshape( objmeta.PropertyList, 1,[] )
                if strcmp( prp_meta.DefiningClass.Name, obj.source_file.fqn )
                    prp = this.create_property( obj, prp_meta );
                    prp.max_label_width = obj.max_label_width;
                    prp.source_file = obj.source_file;
                    obj.children = [ obj.children, prp ];   
                end
            end
% TODO: Refactor above for-loop            
%             isMe = strcmp(  curly( objmeta.PropertyList, 'DefiningClass','Name' ) ...
%                         ,   obj.source_file.fqn                                 );
                 
% Method leafs
            %   TODO: Find out why metadata claims that certain methods are
            %   defined by the classdef-file although they don't appear in the
            %   source code. 'loadobj' doesn't appear in the source code.
            %   Still meta.class reports that it's defined in uix.BoxPanel.
            %   For now, just try to exclude them. 
            exclude_list = {'empty','loadobj'};     % What about overloaded?

            % Debug code
            % for jj = 1 : length( objmeta.MethodList )
            %     fprintf( '%-20s - %s\n', objmeta.MethodList(jj).Name ... 
            %         ,    objmeta.MethodList(jj).DefiningClass.Name   ) 
            % end
            
            %   isMe true indicates that the method is defined by the class itself, 
            %   not by a superclass
            isMe = strcmp(  curly( objmeta.MethodList, 'DefiningClass','Name' ) ...
                        ,   obj.source_file.fqn                                 );
                        
            method_list = reshape( objmeta.MethodList(isMe), 1,[] );
            
            method_list( ismember( {method_list.Name}, exclude_list ) ) = [];
            
            %   Enumeration adds a long list of methods that are not defined
            %   in the source code. See comment in Enumeration.m
            if objmeta.Enumeration
                ism = ismember( {method_list.Name}                    ...
                            ,   m2uml.Enumeration.exclude_method_list );
                method_list( ism ) = [];
            end
            
            for mth_meta = method_list
                mth = this.create_method( obj, mth_meta );
                mth.max_label_width = obj.max_label_width;
                if strcmp( obj.source_file.basename, mth_meta.Name )
                    % then mth_meta represents the constructor
                    xpr = regex.concrete_method_name( mth_meta.Name );
                    cac = regexp( [obj.source_file.mcodes.row], xpr, 'once' );
                    has_explicit_constructor = any(not(cellfun( @isempty, cac )));
                    if has_explicit_constructor 
                        mth.data.isExplicitConstructor = true;
                    else
                        mth.data.isImplicitConstructor = true;
                    end
                end
                mth.source_file = obj.source_file;
                obj.children = [ obj.children, mth ];   
            end

% Setter and Getter methods. 
%   Google says: "UML does not define getter setter operations." and PlantUML doesn't
%   provide a compact way to indicate the existence of getters and setters. Someone at
%   stackoverflow proposed <<set/get>> together with the name in the properties
%   compartment. Setters and getters create to much clutter seems to be the majority
%   opinion. Matlab meta.class doesn't include set and get methods in the MethodList.
%
%   poi: Explicite set and get methods requires some rational to exist in the user code.
%   Many of the old set-method examples are made obsolete by "Property Validation in 
%   Class Definitions". Typically, in Matlab there will not be that many set and get
%   methods. 
%
%   Conclusion: m2uml shall optionally show set and get methods as methods.
%
            for prp_meta = reshape( objmeta.PropertyList, 1,[] )
                if not( isempty( prp_meta.GetMethod ) )
                    mth = this.create_setget_method( obj, prp_meta, 'get' );
                    obj.children = [ obj.children, mth ];   
                end
                if not( isempty( prp_meta.SetMethod ) )
                    mth = this.create_setget_method( obj, prp_meta, 'set' );
                    obj.children = [ obj.children, mth ];   
                end
            end
            17; 
            
% Event leafs
            isMe = strcmp(  curly( objmeta.EventList, 'DefiningClass','Name' )  ...
                        ,   obj.source_file.fqn                                 );
            
            event_list = reshape( objmeta.EventList(isMe), 1,[] );
            
            for event_meta = event_list
                event = this.create_event( obj, event_meta );
                event.max_label_width = obj.max_label_width;
                event.source_file = obj.source_file;
                obj.children = [ obj.children, event ];   
            end
            
% Enumeration leafs. Enumeration cannot be inherited, i.e. be a superclass(?).

            for enum_meta = reshape( objmeta.EnumerationMemberList, 1,[] )
                enum = m2uml.Enumeration( enum_meta.Name, obj );
                if numel(objmeta.SuperclassList) >= 1
                    %   There must be a better way to find out whether the value of Name
                    %   is the name of a numeric class. Most likely, the better way is
                    %   ismember( name, list_of_all_names )?
                    if isnumeric( eval([objmeta.SuperclassList(1).Name,'(1);']) )
                        %   There must be a better way to get this value
                        cmd = sprintf( '%s.%s', obj.source_file.fqn, enum.name );
                        enum.value = feval( objmeta.SuperclassList.Name, eval( cmd ) );
                    elseif islogical( eval([objmeta.SuperclassList(1).Name,'(1);']) ) 
                        %   There must be a better way to get this value
                        cmd = sprintf( '%s.%s', obj.source_file.fqn, enum.name );
                        enum.value = feval( objmeta.SuperclassList.Name, eval( cmd ) );
                    else
                        enum.value = [];
                    end
                else
                    enum.value = [];
                end
                enum.max_label_width = obj.max_label_width;
                enum.source_file = obj.source_file;
                obj.children = [ obj.children, enum ];   
            end
        end
        function    execute_Function        (    ~, obj )       %
            %
            obj.data.CircleCharacter = 'F';   
        end
        function    execute_Package         ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        %
    end
    methods     ( Access = private )                            %
        function    new_prp = create_property       ( ~, parent, prp_meta )         %
            %
            new_prp = m2uml.Property( prp_meta.Name, parent );  
            
            new_prp.data.isAbstract = prp_meta.Abstract;
            if prp_meta.Dependent   % "derived" in UML nomenclature
                new_prp.data.prefix = '/';
            end
%           new_prp.data.isStatic   = prp_meta.Constant;
            
            % NOTE: Property visibility is a bit tricky. 
            %   Matlab has a list of possible values of SetAccess and GetAccess, which 
            %   has to be mapped onto {'private','protected','public'} of PlantUML. 
            %   https://se.mathworks.com/help/matlab/matlab_oop/property-attributes.html
            % 
            % TODO: 2020-04-29, Make a table of the mapping of Matlab Access, Static,
            % Constant to the three PlantUML visibility symbols.
            %
            % TODO: run special tests with different property attributes 
            %   "properties ( SetAccess = {?ClassName1,...} )"
            %   "properties ( Constant=true, GetAccess=private )"
            
            if prp_meta.Constant
                new_prp.data.visibility = 'private';
            elseif ischar( prp_meta.SetAccess )
                switch prp_meta.SetAccess
                    case  {'private','protected','public'}      
                        new_prp.data.visibility = prp_meta.SetAccess;
                    case  {'immutable'}                         
                        new_prp.data.visibility = 'private';
                    case  {'none'}    % Cannot occur(?)         
                        new_prp.data.visibility = 'private';
                    otherwise                                   
                        error(  'm2uml:MetaDataScanner:Unexpected'              ...
                            ,   'Unexpected value of prp_meta.SetAccess: "%s"'  ...
                            ,   prp_meta.SetAccess                              )
                end
            elseif isa( prp_meta.SetAccess, 'meta.class' )  ... 
            ||     isa( prp_meta.SetAccess{1}, 'meta.class' )
                new_prp.data.visibility = 'protected';
            else
                error( 'm2uml:MetaDataScanner:Unexpected'               ...
                    ,   'Unexpected value of prp_meta.SetAccess: "%s"'  ...
                    ,   value2short( prp_meta.SetAccess )               )
            end
            
% TODO: {static} properties isn't a good idea. 
%             if strcmp( prp_meta.SetAccess, 'immutable' )    
%                 new_prp.data.isStatic = true;
%             end
        end
        function    new_mth = create_method         ( ~, parent, method_meta )      %
            %
            new_mth = m2uml.Method( method_meta.Name, parent );  

            new_mth.data.isAbstract  = method_meta.Abstract;  
            new_mth.data.isStatic    = method_meta.Static;
            % NOTE: quickfix to handle "methods ( Access = {?ClassName1,?ClassName2} )" 
            if ischar( method_meta.Access )
                new_mth.data.visibility = method_meta.Access;
            else
                new_mth.data.visibility = 'protected';
            end
            new_mth.data.outargs     = method_meta.OutputNames;
            new_mth.data.inargs      = method_meta.InputNames;
        end
        function    new_mth = create_setget_method  ( ~, parent, prp_meta, type )   %
            
            if strcmp( prp_meta.DefiningClass.Name, parent.source_file.fqn )
                new_mth = m2uml.Method( [lower(type),'.',prp_meta.Name], parent );
                new_mth.max_label_width = parent.max_label_width;
                new_mth.data.isAbstract = prp_meta.Abstract;  
                new_mth.data.isStatic   = [];
                new_mth.data.visibility = prp_meta.( ...
                                          [upper(type(1)),lower(type(2:end)),'Access']);
                new_mth.data.outargs    = {};
                new_mth.data.inargs     = {};
                new_mth.source_file     = parent.source_file;
            else
                new_mth = m2uml.Method.empty;
            end
        end
        function    new_evt = create_event          ( ~, parent, event_meta )       %
            %
            new_evt = m2uml.Event( event_meta.Name, parent );
            if ischar( event_meta.NotifyAccess )
                new_evt.data.visibility = event_meta.NotifyAccess;
            else
                new_evt.data.visibility = 'protected';
            end
        end
        function    new_rls = create_relationship   ( ~, parent, name, super_meta ) %
            % FIXME: 2020-05-12, This is an old mess that isn't tested or called 
            len = length( super_meta );
            new_rls(1,len) = m2uml.Relationship();
            new_rls.data.source  = name;
            new_rls.data.source  = parent;
            new_rls.data.target  = super_meta.Name;
            new_rls.data.type    = 'generalization';
            new_rls.data.keyword = '';
        end
        function    out     = getCircleCharacter    ( ~, mco )                      %
        %
        %   A value class is identified by excluding other alternatives 
        %   out = 'C';  % Adhere to PlantUml, which uses C as default

        %   The order of the following if-statements is important, since a class 
        %   may meet the criteria of more than one. A Singleton is typically also a
        %   Handle class, but here it will be tagged with S, since S comes before H.
        
            if mco.Abstract                 % A 
                out = 'A';
                return                                                      %   RETURN
            end
            if mco.Enumeration              % E 
                out = 'E';
                return                                                      %   RETURN
            end
            if isSingleton_( mco )          % S 
                out = 'S';
                return                                                      %   RETURN
            end
            if isHandleClass_( mco )        % H 
                out = 'H';
                return                                                      %   RETURN
            end
% NOTE: HandleCompatible==false doesn't indicate a value class. HandleCompatible is
% something else. At this point in the code a number of cases are excluded. Does anything
% but value class remain? Maybe not. If so "C" will never happen. 
%           if not( mco.HandleCompatible )  % V 
%               out = 'V';
%               return                                                      %   RETURN
%           end
            out = 'V';
        end
    end
end
function    isS = isSingleton_( mco )                           %
%    
%   Assumption: 
%       A class is a Singleton iff it has an explicite constructor that is private     

    isS = false;
    for jj = 1 : numel( mco.Methods )
        if is_explicite_constructor_( mco, jj )
            if  strcmp( mco.Methods{jj}.Access, 'private' )
                isS = true;
            end
            break
        end
    end
end
function    isC = is_explicite_constructor_( mco, ix_method  )  %
%
%   Assumption: The meta class object does not explicitely indicate the constructor 

    isC = false;
    if strcmp(  mco.Methods{ix_method}.DefiningClass.Name, mco.Name )
        cac = regexp( mco.Name, '\.', 'split' );
        if strcmp( mco.Methods{ix_method}.Name, cac{end} )
            isC = true;
        end
    end
end
function    isH = isHandleClass_( mco )                         %
%    
%   Assumption: 
%       A class is a Handle class if mco.HandleCompatible is true and one 
%       of it's superclasses is a handle class

    if not( mco.HandleCompatible )
        isH = false;
        return
    end
    
    obj = mco;  isH = false;
    for jj = 1 : length( obj.SuperClasses )
    
        super_class = obj.SuperClasses{jj};
        if strcmp( super_class.Name, 'handle' )
            isH = true;
            break
        else
            isH = isHandleClass_( super_class );    % recursive call
        end
    end
end
