function    puml_ffs = create_PlantUML_script( varargin )                       %
% create_PlantUML_script creates and writes a PlantUML-script to a puml-file
%
% Syntax: 
%       puml_ffs = m2uml.create_PlantUML_script         ...
%           ...     Name              Value
%               (   'Classes'       , class_list        ... required
%               ,   'Arrows'        , other_arrows      ... optional
%               ,   'UserOptions'   , user_options      ... optional
%           ...     arguments that overrides option values  
%               ,   'Title'         , title_str         ... optional
%               ,   'CreatedBy'     , created_by        ... optional
%               ,   'FileBaseName'  , file_base_name    ... optional
%               );
%
% Input:
%       class_list      a cell array of fully qualified names (or filespecs) of classes 
%                       and functions. Alternatively, string vector and struct vector as
%                       created by dir() The names of classes, which are members of a
%                       packages, shall be prefixed by the package name, separated by a
%                       dot. The classes must be syntactically correct and on the search
%                       path.
%       other_arrows    a cell array of PlantUML statements, which defined arrows between 
%                       classes. See "3.1 Relations between classes" in the PlantUML 
%                       pdf-manual or the on-line help.
%       user_options    a scalar struct or cell row of scalar structs. The structs are 
%                       "subset" of the struct defined by m2uml.factory_options. The
%                       user_options structs has only the fields, the values of which
%                       differ from m2uml.factory_options.
%       title_str       a text string, which appears as title of the class diagram
%       created_by      a text string, which is embedded in the footer of the class
%                       diagram
%       file_base_name  a legal file name (excluding the extention) that does not include
%                       spaces
%
% Output:
%       puml_ffs        full filespec of the PlantUML script    
%
% Description:
%       m2uml.create_PlantUML_script creates a PlantUML-script, writes the script to a
%       file and returns the full filespec. 
%
% Examples:
%     puml_ffs = m2uml.create_PlantUML_script                                         ...
%         ( 'Title'   , 'BN_Iterator'                                                 ...
%         , 'Classes' , {'List','CellArrayList','Iterator','CellArrayListIterator'}   ...
%         , 'Arrows'  , {'CellArrayList "1" <-left-o "1 " CellArrayListIterator : "  "'} )
%
% See also: m2uml.call_local_PlantUML, m2uml.display_class_diagram, m2uml.puml2graphic,
%           m2uml.run

%   The original function, create_PlantUML_script(), is split into three functions,
%   create_PlantUML_script(), create_PlantUML_script_(), and create_PlantUML_script__() 
%   to handle increasing requirements: accept file_lists of "all" formats, validate the  
%   files earlier in the process and overwrite some option values by input values. 

    if nargin == 0  % Dirty trick to test validate_input_file_list_()
        puml_ffs = localfunctions();
        return                                                          %   RETURN
    end
        
    %   validate the input file list (and convert to cell array of characters)
    len   = numel( varargin );
    inarg = cell( 1, len );
    for jj = 1 : 2 : len
        inarg(jj) = varargin(jj); 
        if isa( varargin{jj}, 'char' )  &&  strcmp( varargin{jj}, 'Classes' ) 
            
            file_list = validate_input_file_list_( varargin{jj+1} );
            
            assert( not(isempty( file_list ))           ...
                ,   'poi:m2uml:SourceFile:EmptyList'    ...
                ,   'The list contains no valid files'  )
            
            inarg{jj+1} = file_list;

        else
            inarg(jj+1) = varargin(jj+1); 
        end
    end
    
    puml_ffs = create_PlantUML_script_( inarg{:} );   
end
function    puml_ffs = create_PlantUML_script_( varargin )                      %
    
    ipp = InputPreprocessor( {
    ...   Name              Default value       Class       Constraint  
        3 'Classes'         nan                 {'cell'}    {'FileExist'}
        3 'Arrows'          cell(0,1)           {'cell'}    {'CellStr'}
        3 'UserOptions'     struct([]) {'cell','struct'}    {}
    ... arguments that overrides option values, these default values don't override
        3 'Title'           ''                  {'char'}    {'row'}
        3 'CreatedBy'       ''                  {'char'}    {'row'}
        3 'FileBaseName'    ''                  {'char'}    {'row'}
        } );
    
    inv = ipp.parse( varargin{:} );
    
    %   Build an option stucture of input argument values 
    if not( isempty( inv.Title ) )
        arguments.Title.String = inv.Title;
    end
    if not( isempty( inv.CreatedBy ) )
        arguments.Footer.String = create_footer_string_( inv.CreatedBy );
    end
    if not( isempty( inv.FileBaseName ) )
        arguments.General.FileBaseName = inv.FileBaseName;
    end
    if not( exist( 'arguments', 'var' ) == 1 )
        arguments = struct([]);     
    end
    
    if isa( inv.UserOptions, 'struct' )
        options = m2uml.merge_options( inv.UserOptions, arguments );
    else
        if all( cellfun( @(uo) isa(uo,'struct'), inv.UserOptions ) )
            options = m2uml.merge_options( inv.UserOptions{:}, arguments );
        else
            error(  'm2uml:puml2graphic:CannotFindFile'                         ...
                ,   'The value of ''UserOptions'' is not a cell row of structs' )
        end
    end
    
    puml_code = create_PlantUML_script__( inv.Classes, options, inv.Arrows );
    
    %   write a puml-script
    ffs = fullfile( options.General.WorkingFolder       ...
            ,   [   options.General.FileBaseName, '.'   ...
            ,       options.General.PlantUmlExtension   ]  );
        
    str = strjoin( puml_code, '\n' );
    fid = fopen( ffs, 'w' );
    fprintf( fid, '%s\n', str );
    fclose( fid );
    puml_ffs = ffs;
end
function    pumlcode = create_PlantUML_script__( file_list, options, user_rows )%
% create_PlantUML_script_ creates a PlantUML script that defines an UML Class Diagram
% comprising class boxes and generalization arrows. 
%
%   Syntax 
%       puml_code = m2uml_main( file_list, user_options, user_rows )
%
%   Inputs
%       file_list       <nx1 cell>      of items that are good as input of which()
%       user_options    <1x1 struct>    a subset of the struct of factory_options
%       user_rows       <nx1 cell>      PlantUML code, one row per cell
%           
%   Outputs
%       puml_code       <nx1 cell>      PlantUML code, one row per cell
%
%   Description
%       m2uml.create_PlantUML_script_() creates a PlantUML-script and returns the the
%       complete PlantUML code in a cell array
%{
%   m2uml creates a PlantUML script, which defines an UML Class Diagram, based on
%   information extracted from the m-code and the meta.class object of the Matlab
%   classes. The Class Diagram, which is generated automatically, comprises class
%   boxes and generalization arrows. Additional relation arrows can be supplied as
%   input by the user. The user can control the degree of detail of the class boxes
%   by a set of options.
%}
%%  ====    Build a tree    ====================================================.
%
%%  Build a tree-like hierarchy. Each node has zero or multiple children        .
    %   The root is an object of PlantUmlSctript. All nodes of the tree are subclasses
    %   of m2uml.Element. Each node generates potentially one or more rows of code in
    %   the target PlantUml script. The source code is read, trimmed and stored in  
    %   a struct array, pus.source_file_list.mcode. 
    pus = m2uml.PlantUmlScript( 'TreeRoot', m2uml.Element.empty, file_list );

    % Build a tree of objects of PlantUmlScript, Packages, Classes, and Functions
    build_node_hierarchy( m2uml.NodeHierarchyCreator, pus ) 
    %
%%  Add option based leafs to the tree, e.g Footer, Header, ...                 .
    % Add Footer, Header, Title and Skinparam to PlantUmlScript
    hla = m2uml.HierarchyLeafAdder();
    add_option_based_items_to_hierarchy( hla, pus, options )
    %
    % Add generalization relationships based on meta.MetaData 
    add_generalizations_to_hierarchy_root( m2uml.GeneralizationScanner(), pus )
    %
    set_max_label_width_calculator( hla, pus, options.Diagram.Monospaced )
    %
%%  ====    Traverse the tree repeatedly for various tasks    ==================.
%%  Gather meta.class info. Add property, methods, enumeration and events leafs .
    %   
    execute( m2uml.MetaDataScanner( ), pus );
    %
%%  Gather tooltip texts from the Matlab source code. Add TodoFixme leafs       .
    % to Class and Function nodes
    % The purpose of "keep( options, ..." is to provide a clue on which values of
    % options that are used. keep_() is a local function of this script.
    execute( m2uml.SourceFileScanner( keep_( options, {'Tooltip','Package'} )), pus )
    %
%%  Sets isSelected according to the values of options.                         .
    % This controls whether to display rows for objects of Title, Header, Footer,
    % Monospaced, Generalizations, Property, Method and TodoFixme. (All files of 
    % file_list are displayed. Parts of rows, e.g. hyperlinks, tooltips are handled 
    % PlantUmlCodePrinter.) 
    execute( m2uml.LeafDisplaySelection( options ), pus )
    %
%%  Add user_arrows to the tree and deselect conflicting Relationships          .
    % DONE: 2019-12-16, Generalisation arrows included in user_rows shall take
    % precedence over Generalisation arrows based on meta.MetaData. If user_rows 
    % contains a specific generalisation, isSelected shall be set to false for 
    % the corresponding m2uml.Relationship object. I see no obvious way to implement 
    % that behaviour. execute( a_doer_subclass_object ) is hardly possible.
    % 2020-01-14, Refactored 
    %
    m2uml.resolve_user_automatic_arrow_conflict( pus, user_rows )
    %
%%  Sort the children of Class and Function objects (Add Separator leafs.), i.e .
    % properties, methods and todofixmes with respect to visibility,
    % {'private','protected','public'} and {'FIXME','TODO','NOTE'}, respectively. 
    % Add Separator objects as needed.
    execute( m2uml.LeafDisplayOrder( keep_( options, {'Class'} ) ), pus ) 
%%  Miscellanous: "circle-letter" and MonoSpaced                                .
    % Set background colors of the "circle-letter" and MonoSpaced. 
    execute( m2uml.Miscellaneous( keep_( options, {'Class','Function','Package'} )), pus )
    %
%%  Compile a PlantUml script                                                   .
    % Create a PlantUml script and store it in the property, plantuml_code. Up
    % to here "all" information has been added to the tree. There is one exeption,
    % if options.Tooltip.H1Line is true only the H1-line is kept, not the full
    % help-text. The value of isSelected controls which PlantUml code rows are
    % created. Values of options.Show control whether hyperlinks, tooltips and 
    % in- and out-arguments of methods are included.
    printer = m2uml.PlantUmlCodePrinter(keep_(options,{'Diagram','Tooltip','Hyperlink'}));
    execute( printer, pus )
    %
%%  ====    Prepare the output    ==============================================.
    pumlcode = deblank( strsplit( printer.plantuml_code, '\n' ) );
    pumlcode( cellfun( @isempty, pumlcode ) ) = [];   
end
%%  ====    Helper functions    ================================================.
function    out = keep_( options, fields )              %
    out = rmfield( options, setdiff( fieldnames(options), fields ) );
end
function    chr = create_footer_string_( created_by )   %
    
    formatspec  = 'Created by %s at %s';                 
    timestamp   = datestr( now, 'yyyy-mm-dd HH:MM' );    
    chr         = sprintf( formatspec, created_by, timestamp );
end
function    ffs = validate_input_file_list_( files )    %
% validate_input_file_list_ validates input files and converts to cell array of char  
%
%   Input:
%       files   fully qualified names or filespecs in vector of cellstr or strings  
%               vector of structs   as created by dir()
%
%   Output:
%       ffs     filespecs in vector of cellstr
%

    %   convert to cell array of characters
    if isa( files, 'char' )
        file_list = {files};
    elseif isa( files, 'string' )
        if isscalar( files )
            file_list = {char(files)};
        else
            file_list = convertStringsToChars( files );
        end
    elseif isa( files, 'struct' )
        files( startsWith( {files.name}, '.' ) ) = [];
        file_list = fullfile( {files.folder}, {files.name} );
    elseif isa( files, 'cell' )  &&  iscellstr( files )         %#ok<ISCLSTR>
        file_list = files;
    else
        error(  'poi:m2uml:SourceFile:UnknownInput'     ...
            ,   'Cannot handle input list of files, %s' ...
            ,   value2short( files )                    )
    end

    %   which asserts that ffs are full filespecs on the search path, however
    %   external method files ... . Files not on the search path are silently
    %   skipped; which() returns empty.
    if isa( file_list, 'cell' )
        ffs = cellfun( @which, file_list, 'uni',false );
    elseif isa( file_list, 'string' )
        ffs = cellfun( @which, convertStringsToChars(file_list), 'uni',false );
    elseif isa( file_list, 'struct' )
        ffs = cellfun( @which, fullfile({file_list.folder},{file_list.name}),'uni',false); 
    else
        error(  'poi:m2uml:SourceFile:UnknownInput' ...
            ,   'Cannot handle input file_list, %s' ...
            ,   value2short( file_list )            )
    end

    %   exclude files, which are NOT on the search path
    ise = cellfun( @isempty, ffs );
    if any( ise )
        for f1 = fliplr(find( ise ))
            fprintf( 2, 'File excluded because it''s not on the search path: "%s"\n'...
                    ,   file_list{f1}                                               );
            ffs(f1) = [];
        end
    end
    if isempty( ffs )
        return                                                          %   RETURN
    end

    %   exclude files with syntax error
    for f1 = numel( ffs ) : -1 : 1
        sas = checkcode('-m2', ffs{f1} );   % '-m2' is undocumented
        if not( isempty( sas ) )
            fprintf( 2, 'File excluded because of syntax error: "%s"\n', ffs{f1} );
            ffs(f1) = [];
        end
    end
    if isempty( ffs )
        fprintf( 2, 'Execution interupted because of zero valid files\n' );
        return                                                          %   RETURN
    end
    
    %   print warnings for shadowed files
    for f1 = 1 : numel( ffs )
        fqn = ffs2fqn( ffs{f1} );
        if not(isempty( fqn ))
            %   cac = which(fqn,'-all'); doesn't return the word, "Shadowed" 
            cac = evalc( horzcat('which ',fqn,' -all') );   
            cac = strsplit( cac, '\n' );
            for f2 = find( contains( cac, 'Shadowed' ) )
                fprintf( 2, 'Warning: "%s"\n', cac{f2} );
            end
        end
    end
    
    %   exclude external methods
    for f1 = numel( ffs ) : -1 : 1
        if contains( ffs{f1}, '@' )
            chr = extractAfter( ffs{f1}, '@' );
            cac = strsplit( chr, { filesep, '.' } );
            if not( any( strcmp( cac(1), cac(2:end) ) ) )
                fprintf( 2, 'Is external method; exclude: "%s"\n', ffs{f1} );
                ffs(f1) = [];
            end
        end
    end
end
%
% DONE: 2019-12-07, How to provide an acceptable "user experience"? Background: 
%       m2uml.factory_options defines a set of name value pairs. (The word "option"
%       reveals that I didn't find a better word.) The intent of 'UserOptions' is
%       to let the user define sets of options values in separate m-files. These
%       files should be given descriptive names, e.g. 'compact', 'verbose'. Next
%       there are a few option values that will have unique values for each
%       diagram, e.g. the values of 'Title' and 'FileBaseName'. These options are
%       included in the input arguments list. Input arguments have the highest
%       precedence, 'UserOptions' the second highest and m2uml.factory_options the
%       lowest. The default values of InputPreprocessor() are not used.
% 
%
%   NOTE: firefox -new-tab URL
%   "C:\Program Files\Mozilla Firefox\firefox.exe" -new-tab 
%   file:///H:/m/PiaX/IDE_tools_test/work/test_21.svg    

%   TODO: Chromium Embedded browser; PlantUML GUI 
%   w = matlab.internal.webwindow('file:///H:/m/PiaX/IDE_tools_test/work/test_782.svg')
%   show( w )
%   bringToFront( w )

%   TODO: Design and API doc, https://msdn.microsoft.com/en-us/magazine/gg309172.aspx
%   http://sdkbridge.com/
