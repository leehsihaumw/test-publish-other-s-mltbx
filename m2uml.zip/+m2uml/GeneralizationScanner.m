classdef    GeneralizationScanner < handle                                  %
% Compile generalization relationships

% NOTE: Why doesn't this class extend m2uml.Doer? The reason is because the method,
%       execute_class(this,obj), which is the appropriate method to create the 
%       relationship, cannot easily add it to the children of PlantUmlScript. I've 
%       chosen to represent relationships with single rows at the end of the script
%       rather than by the keyword "extends" in the class definition. That offers  
%       possibilities to affect the layout by explicitly prescribe the direction of
%       the arrows. 

%#ok<*AGROW>

    methods                                                                 %
        function    add_generalizations_to_hierarchy_root( this, pus )      %
            %
            fqn_list        = cell( 1, 0 );
            generalizations = m2uml.Element.empty;
            node_row        = pus.traverse_hierarchy( pus );
            type_row        = arrayfun( @class, node_row, 'uni',false );
            is_class        = strcmp( type_row, 'm2uml.Class' );
            
            for cls = node_row( is_class )
                generalizations = [ generalizations                         ...
                                ,   this.create_generalization_array( cls ) ];
                fqn_list{1,end+1} = cls.source_file.fqn;
            end
            %   Add to pus.children the relationships, the targets of which are
            %   members of the user supplied list of classes. Thus, avoiding
            %   Matlab factory classes.
            targets = arrayfun( @(r) r.data.target, generalizations, 'uni',false );
            ismem   = ismember( targets, fqn_list );
            pus.children = [ pus.children, generalizations(ismem) ];
        end
    end
    methods     ( Access = private )                                        %
        function    array   = create_generalization_array( this, cls )      %
            %
            % array because of multiple inheritance
            array = m2uml.Relationship.empty(1,0);
            %
            if isa( cls, 'm2uml.Class' )
                clsmeta = meta.class.fromName( cls.source_file.fqn );
                for super = reshape( clsmeta.SuperclassList, 1,[] )
                    array = ...
                    [ array, this.create_generalization( cls.source_file.fqn, super ) ];   
                end
            end
        end
        function    new_rls = create_generalization( ~, name, super_meta )  %
            %
            len = length( super_meta );
            new_rls(1,len) = m2uml.Relationship();

            new_rls.data.source  = name;
            new_rls.data.target  = super_meta.Name;
            new_rls.data.type    = 'generalization';
            new_rls.data.keyword = '';
        end
    end
end
