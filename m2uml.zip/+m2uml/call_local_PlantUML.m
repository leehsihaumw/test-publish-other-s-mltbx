function    puml = call_local_PlantUML( varargin )
% m2uml.call_local_PlantUML displays a UML Class Diagram in the Matlab Web Browser.
%
% Syntax: 
%       m2uml.call_local_PlantUML                   ...
%           ...     Name              Value
%               (   'Title'         , title_str     ... required
%               ,   'Classes'       , class_list    ... required
%               ,   'Arrows'        , other_arrows  ... required, possibly empty
%               ,   'TempFolder'    , temp_folder   ... optional
%               ,   'PlantUmlJar'   , plantuml_jar  ... optional
%               ); 
%
% Input:
%       title_str       a text string, which will appear as title of the class diagram
%       class_list      a cell array of full names of classes. The names of classes, 
%                       which are members of a packages, shall be prefixed by the package 
%                       name, separated by a dot.  
%       other_arrows    a cell array of PlantUML statements, which defined arrows between 
%                       classes - other than inheritance arrows. See "3.1 Relations 
%                       between classes" in the PlantUML pdf-manual or the on-line help.
%       temp_folder     folder for temporary files, including the svg-file. Default is
%                       now General.WorkingFolder of m2uml.factory_options. (In m2uml v1
%                       it was getenv('temp').)
%       plantuml_jar    full filespec of the PlantUML compiled Jar. The default value is
%                       the value of General.PlantUmlJar of m2uml.factory_options.
% 
% Output:
%       puml            full filespec of the PlantUML script    
%
% Description:
%       This version of m2uml.call_local_PlantUML mimics the behavior of
%       m2uml.call_local_PlantUML of m2uml 1.1. m2uml.call_local_PlantUML creates a
%       PlantUML-script, writes the script to a file, creates an image file, displays the
%       image file in the Matlab browser and finally opens the script in the editor.
%
% Examples:
%     m2uml.call_local_PlantUML                                                       ...
%         ( 'Title'   , 'BN_Iterator'                                                 ...
%         , 'Classes' , {'List','CellArrayList','Iterator','CellArrayListIterator'}   ...
%         , 'Arrows'  , {'CellArrayList "1" <-left-o "1 " CellArrayListIterator : "  "'} )
%
% See also: m2uml.create_PlantUML_script, m2uml.display_class_diagram, 
%           m2uml.puml2graphic, m2uml.run

    ipp = InputPreprocessor( {
        3 'Title'       nan     {'char'}    {'row'}
        3 'Classes'     nan     {'cell'}    {'CellStr'}
        3 'Arrows'      nan     {'cell'}    {'CellStr'}
        3 'TempFolder'  ''      {'char'}    {'FolderExist'}
        3 'PlantUmlJar' ''      {'char'}    {'FileExist'}
        } );
    inv = ipp.parse( varargin{:} );
    
    %   Build an option stucture of input argument values 
    arguments.Title.String = inv.Title;
    if not( isempty( inv.TempFolder ) )
        arguments.General.WorkingFolder = inv.TempFolder;
    end
    if not( isempty( inv.PlantUmlJar ) )
        arguments.General.MyPlantUml = inv.PlantUmlJar;
    end
    
    options = m2uml.merge_options( m2uml.factory_options, v11_options() );
    options = m2uml.merge_options( options, arguments );
    
    puml = m2uml.create_PlantUML_script         ...
            (   'Classes'       , inv.Classes   ...
            ,   'Arrows'        , inv.Arrows    ...
            ,   'UserOptions'   , options       ...
            );

    graphic_file = m2uml.puml2graphic( 'PlantUmlScript', puml );

    m2uml.display_class_diagram( 'GraphicFile', graphic_file );
    
    matlab.desktop.editor.openDocument( puml );
end
