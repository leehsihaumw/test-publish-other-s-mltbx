classdef    Class  < m2uml.Element
% Class knows the data to make the class block PlantUML-code for ONE Matlab class.  

% Class holds the data needed to generatate PlantUML code for one Matlab class. Class
% relies on children for data on property, method and todofixme code.

    properties  ( Constant = true )
        %
        block_head  = 'classdef'; 
    end
    properties                                          %
        % Data used for the class block code
        data = struct(  'CircleCharacter'       , ''  ... capital letter in circle
                    ,   'CircleBackgroundColor' , ''  ... color of circle background
                    ,   'stereotype'            , ''  ...
                    ,   'line'                  , 1   ... 2020-07-25,  
                    ,   'tooltip'               , ''  ...
                    ,   'isAbstract'            , false  ...
                    ,   'isEnumeration'         , false  );
        
        % Children of a class include objects of Property, Method, TodoFixme, etc. 
        children = m2uml.Element.empty(1,0);
        % 
        % trailing_statements = m2uml.SingleCodeRow.empty(1,0);
        
        % SourceFile instance, with the properties: ffs,fqn,type,namespace,basename
        source_file = m2uml.SourceFile.empty(1,0);
        
        % The longest text row controls the width of the class-box. TodoFixme strings
        % must not increase the width of the class-box, but on the other hand use the
        % available width. max_class_leaf_string_width is set by the longest string in
        % the box and is used to set the part of the todofixme-string, which can be
        % displayed in the box.
        max_label_width 
    end
    methods                                             %
        function    this = Class( varargin )            %
            % Explicit constructor
            this@m2uml.Element( varargin{:} );
        end
    end
end
