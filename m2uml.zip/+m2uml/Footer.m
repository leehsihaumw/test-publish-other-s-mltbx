classdef    Footer  < m2uml.Element  
% Footer knows all data to make the code for the footer. 
%
%   Footer is displayed as one left justified row with parameterized font size and color. 

    properties                                  %
        %
        String  = '';
        %
        Size    = [];
        %
        Color   = '';
    end
    methods                                     %
        function    this = Footer( varargin )   %
            % Explicit constructor. The properties, String, Size, and Color, are set.
            this@m2uml.Element( varargin{1:2} );
            if nargin == 0
                return
            end
            this.String = varargin{3}.String;
            this.Size   = varargin{3}.FontSize;
            this.Color  = varargin{3}.Color;
        end
    end
end
