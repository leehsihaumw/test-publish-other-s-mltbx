classdef    SourceFileScanner < m2uml.Doer                            %
% SourceFileScanner gathers tooltips and adds TodoFixme leafs
%
%   From the Matlab source code: 
%   *   Gathers tooltip texts and their line numbers
%   *   Adds TodoFixme leafs 
%
    properties  ( Access = private )                            %
        %
        options
    end
    methods     ( Access = public )                             %
        function    this = SourceFileScanner( varargin )        %
            %
            narginchk( 0, 1 )
            if nargin == 1
                this.options = varargin{1};
            end
        end
    end
    methods     ( Access = ?m2uml.Doer )                        %
        function    execute_PlantUmlScript  ( this, obj )       %
            %
            this.execute_for_all_children( obj )
        end
        function    execute_Event           ( this, obj )       %
            
            this.assign_tooltip_text_( obj, "above", regex.leading_name(obj.name) );
        end
        function    execute_Enumeration     ( this, obj )       %
            
            this.assign_tooltip_text_( obj, "above", regex.leading_name(obj.name) )
        end
        function    execute_Class           ( this, obj )       %
            %
            
            this.assign_tooltip_text_( obj, "below", regex.classdef_name(obj.name) );
            
            execute_for_all_children( this, obj )
            
            todofixmes = this.scan_todofixme_texts_( obj ); 
            if not( isempty( todofixmes ) )
                [todofixmes.max_label_width] = deal( obj.max_label_width );
                obj.children = [ obj.children, todofixmes ];
            end
        end
        function    execute_Function        ( this, obj )       %
            
            xpr = regex.concrete_method_name( obj.name );
            this.assign_tooltip_text_( obj, "below", xpr )
            
            todofixmes = this.scan_todofixme_texts_( obj ); 
            if not( isempty( todofixmes ) )
                [todofixmes.max_label_width] = deal( obj.max_label_width );
                obj.children = [ obj.children, todofixmes ];
            end
        end
        function    execute_Method          ( this, obj )       %
            %
            if obj.data.isImplicitConstructor
                obj.data.tooltip = "Implicit constructor";
            elseif obj.data.isAbstract
                xpr_name = regex.abstract_method_name( obj.name );
                this.assign_tooltip_text_( obj, "above", xpr_name )
            else 
%               external_methods_name = [obj.source_file.external_methods.name];
%               if  not( isempty( external_methods_name ) ) ...     
%               &&  any( obj.name == external_methods_name )
                if isempty( obj.source_file.external_methods )
                    xpr_name = regex.concrete_method_name( obj.name );
                    this.assign_tooltip_text_( obj, "below", xpr_name )
                else
                    17;
                end
            end

            %   1. Implicit contructor of class
            %   2. Method is defined in a separate file in a class folder
            %   3. Method is defined in a separate file in a class_folder/private
            %   4. Abstract method (the search above includes the word 

            %   99. There seems to be cases where on the one hand meta.class 
            %       reports methods to be defined by the user-classdef and 
            %       on the other hand these methods are NOT defined in the
            %       user-classdef-source-code. 

        end
        function    execute_Package         ( this, obj )       %
            %
            %   The help-text of a package is the single line comments in the file
            %   named by the value of Package.ReadmeFile of factory_options.m. The
            %   H1-line is the first row of this text-file. The Help on Contents,m 
            %   says: "The first two lines are headers that describe the folder."
            %   I assume that the first line isn't empty and that it's a comment. 
            
            ffs = fullfile( obj.data.folderspec, this.options.Package.ReadmeFile );
            if isfile( ffs )
                fid = fopen( ffs, 'rt' );
                txt = fgetl( fid );
                fclose( fid );
            else
                txt = this.options.Tooltip.DefaultText;
            end
            obj.data.tooltip = regexp( string(txt), regex.comment_text, 'tokens','once' );
            
            this.execute_for_all_children( obj )
        end
        function    execute_Property        ( this, obj )       %
            % 
            %   The help-text of a property is the block of single line comments
            %   directly above the property name inside the Properties Block. The
            %   H1-line is the topmost row of this help-text.

            this.assign_tooltip_text_( obj, "above", regex.leading_name(obj.name) )

            %   Q&D: meta.class claims that 'MaximizeTooltipString',
            %   'MinimizeTooltipString' and many more are names of 
            %   properties of uix.BoxPanel. However, they are NOT  
            %   defined by code in a properties block of uix.BoxPanel. See: 
            %   m2uml_next_design_test.GLT_BoxPanel_propname_error_2_test 

            %   NOTE: The syntax of the definition of properties contains many
            %   items, see "Validate Property Values". Here the criteria on the
            %   FIXME: old text, property name is simple. See SimpleBlockRegex.getName
            %   1.  The first word of a line of code inside a property block
            %   2.  A valid Matlab name
            %   The two covers all cases including "name@double", which seems 
            %   to be legal, although I didn't find it in the documentation. I 
            %   picked it up in the forum(?). 

        end
    end
    methods     ( Access = private )                            %
        function    todofixmes = scan_todofixme_texts_( ~, obj )            %
            % scan_todofixme_texts_ 
            
            ix_block = find( [obj.source_file.mcodes.block_type]            ...
                            == m2uml.SourceFileAnalyzer.block( "todofixme" ) );
                        
            if isempty( ix_block )  %   externai methods ??? 
                todofixmes = m2uml.TodoFixme.empty;      
                return                                                  %   RETURN
            else
                todofixmes( 1, numel(ix_block) ) = m2uml.TodoFixme();
            end
            
            xpr_todofixme = regex.todofixme_annotation();
            
            next_todofixme = 1;
            
            for rr = ix_block
                
                str = regexp( obj.source_file.mcodes(rr).row, xpr_todofixme ...
                            , 'tokens','once'                               );
                        
                notation_type = lower( str(1) );    % note, todo, fixme 
                
                if contains( str(2), "[" ) || contains( str(2), "]" )
                    % NOTE: Brackets cause a defective hyper-link in the svg-file.
                    % Brackets, [], in the notation text, or(?) notation_text(1:max_len),
                    % results in a defective hyper-link in the svg-file. Issue(?) with
                    % PlantUML.
                    fprintf( 2, 'Notations must not contain brackets: "%s"\n', str(2) );
                    fprintf( 2, 'Square brackets are replaced by underscore\n' )     
                    notation_text = regexprep( str(2), '[\[\]]', '_' );
                else
                    notation_text = str(2);
                end
                todofixmes(next_todofixme).data.type    = notation_type;
                todofixmes(next_todofixme).data.line    = rr;
                todofixmes(next_todofixme).data.tooltip = notation_text;
                todofixmes(next_todofixme).source_file  = obj.source_file;
                next_todofixme = next_todofixme + 1;
            end
        end
        function    assign_tooltip_text_( this, obj, direction, xpr_name )  %
            % assign_tooltip_text_ assigns the H1-line to tooltip of object 
            %
            %   Inputs:
            %       obj         <1x1 m2uml.Element>
            %       direction   <1x1 string>    "above", "below", ...
            %       xpr_name    <>              regular expression to capture obj.name
            %
            %   Output:
            %       Sets obj.data.line and obj.data.tooltip
            
%           direction = validatestring( direction, ["above","below"] );
            
            ix_block = find( [obj.source_file.mcodes.block_type]            ...
                        == m2uml.SourceFileAnalyzer.block( obj.block_head ) );
                    
            mcode_rows = reshape( [obj.source_file.mcodes.row], [],1 );
            
            %   Q&D: Here multiple statements in one row causes some headache.
            
            for ixr = ix_block
                
                ixn = nan;
                statements = this.row2statements( obj.source_file.mcodes(ixr) );
                
                for ss = 1 : numel( statements )
                    
                    col = regexp( statements{ss}, xpr_name, 'once' );
                    if not(isempty( col ))
                        ixn = ixr;
                        tip = this.get_tooptip( mcode_rows, ixn, direction );
                        if not(isempty( tip ))
                            obj.data.tooltip = tip;
                        else 
                            obj.data.tooltip = this.options.Tooltip.DefaultText;
                        end
                        break                                               %   BREAK
                    end
                end
                if not(isnan( ixn ))
                    obj.data.line = ixn;
                    break                                                   %   BREAK
                end
            end
        end
        function    cac = row2statements( ~, mcode )                        %
            
            % The regular expressions that spots function names requires the 
            % code_in_brackets text to handle the lhs, left-hand-side, e.g. [a,b]= . 
            
            msk = ( mcode.kinds == m2uml.CharacterTypes.code_outside_brackets )   ...
                | ( mcode.kinds == m2uml.CharacterTypes.code_in_brackets      );
            
            if not(any( msk ))
                cac = cell(0);
                return                                                  %   RETURN
            else
                chr_msk = char( mcode.row );
                chr_msk(not(msk)) = char(32);
            end
            
            del = mcode.kinds == m2uml.CharacterTypes.end_of_statement; % delimiters
            ix_del = find( del );
            
            if isempty( ix_del ) || ix_del(1) == numel( chr_msk )
                cac = {chr_msk};
                return                                                  %   RETURN
            end
            
            bos = [ 1, ix_del+1 ];                      % beginning of statement
            if ix_del(end) <= bos(end)
                eos = [ ix_del-1, numel(chr_msk) ];     % end of statement
            else
                eos = ix_del-1;
            end
            
            cac = arrayfun( @(ix1,ix2) chr_msk(ix1:ix2), bos, eos, 'uni',false );
            cac = strtrim( cac );
        end
        function    tip = get_tooptip( this, mcode_rows, ixn, direction )   %
            
            switch direction 
                case "above"
                    rr = ixn - 1;
                    found = false;
                    while startsWith( mcode_rows(rr), "%" )
                        rr = rr - 1;
                        found = true;
                    end
                    if found
                        tip = regexp( mcode_rows(rr+1), regex.comment_text() ...
                                    , 'tokens', 'once'                       );
                        if  ixn-(rr+1) >= 2 
                            dx = find( strlength(mcode_rows(rr+1:ixn-1))>=2, 1,'first');
                            if not(isempty( dx ))
                                tip = regexp( mcode_rows(rr+dx), regex.comment_text() ...
                                            , 'tokens', 'once'                       );
                            end
                        end
                    else
                        tip = this.options.Tooltip.DefaultText;
                    end
               case "below"
                   if startsWith( mcode_rows(ixn+1), "%" )
                        tip = regexp( mcode_rows(ixn+1), regex.comment_text() ...
                                    , 'tokens', 'once'                        );
                   else
                       tip = this.options.Tooltip.DefaultText;
                   end
                otherwise
                    error( 'm2uml: internal error' )
            end
        end
    end
end
