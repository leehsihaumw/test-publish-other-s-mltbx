function    options = SEP_support_separator_test_options()
% Creates an user option structure for tests on separators

%#ok<*STRNU> 
narginchk(0,0)
%% Diagram                                      .
    Diagram.Arguments          = false;         %   show arguments of methods
    Diagram.Monospaced         = false;         %   use monospace in class boxes
%% Class                                        .
%% Enumeration                                  .
%% Event                                        .
%% Footer                                       . the text at the very bottom       
    Footer.On       = false;                    %
%% Function                                     .
%% Header                                       . the text in the upper right corner
    Header.On       = false;                    %
%% Hyperlink                                    .
    Hyperlink.Class       = false;              %
    Hyperlink.Enumeration = false;              %
    Hyperlink.Event       = false;              %
    Hyperlink.Function    = false;              %
    Hyperlink.Method      = false;              %
    Hyperlink.Package     = false;              %
    Hyperlink.Property    = false;              %
    Hyperlink.TodoFixme   = false;              %
%% Method                                       .
%% Package                                      .
%% Property                                     .
%% Title                                        .
%% TodoFixme                                    .
%% Tooltip                                      .
    Tooltip.Class       = false;                %   show tooltip of classes
    Tooltip.Enumeration = false;                %   show tooltip of enumerations
    Tooltip.Event       = false;                %   show tooltip of events
    Tooltip.Function    = false;                %   show tooltip of functions
    Tooltip.Method      = false;                %   show tooltip of methods
    Tooltip.Package     = false;                %   show tooltip of packages
    Tooltip.Property    = false;                %   show tooltip of properties
    Tooltip.TodoFixme   = false;                %   show tooltip of aqnnotations
%% ------                                       .
%% General                                      .
%% ------                                       .
%% Consolidate the substructures into one struct.
%   DO NOT EDIT the code of this section    
    
    sas = whos();
    sas( not( strcmp({sas.class},'struct') ) ) = [];
    %
    for sub = {sas.name}
        options.( sub{:} ) = eval( sub{:} );
    end
end
