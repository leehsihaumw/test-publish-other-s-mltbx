function    options = simple_doc_options()
% Creates a user structure to produce a simple diagram for ducumentation            

%#ok<*STRNU> 
narginchk(0,0)
%% Diagram                                      .
    Diagram.Arguments          = false;         %   show arguments of methods
    Diagram.Monospaced         = false;         %   use monospace in class boxes
%% Class                                        .
%% Footer                                       . the text at the very bottom       
    Footer.On       = false;                    %
%% Function                                     .
%% Header                                       . the text in the upper right corner
    Header.On       = false;                    %
%% Hyperlink                                    .
    Hyperlink.Class       = false;              %
    Hyperlink.Enumeration = false;              %
    Hyperlink.Event       = false;              %
    Hyperlink.Function    = false;              %
    Hyperlink.Method      = false;              %
    Hyperlink.Package     = false;              %
    Hyperlink.Property    = false;              %
    Hyperlink.TodoFixme   = false;              %
%% Method                                       .
    Method.private       = false;               %   show public methods
    Method.protected     = false;               %   show protected methods
%% Package                                      .
%% Property                                     .
    Property.private     = false;               %   show private properties
    Property.protected   = false;               %   show protected properties
%% Title                                        .
%% TodoFixme                                    .
    TodoFixme.fixme = false;                    %   show FIXME annotations
    TodoFixme.todo  = false;                    %   show TODO annotations
    TodoFixme.note  = false;                    %   show NOTE annotations
%% Tooltip                                      .
    Tooltip.Class       = false;                %   show tooltip of classes
    Tooltip.Enumeration = false;                %   show tooltip of enumerations
    Tooltip.Event       = false;                %   show tooltip of events
    Tooltip.Function    = false;                %   show tooltip of functions
    Tooltip.Method      = false;                %   show tooltip of methods
    Tooltip.Package     = false;                %   show tooltip of packages
    Tooltip.Property    = false;                %   show tooltip of properties
    Tooltip.TodoFixme   = false;                %   show tooltip of aqnnotations
%% ------                                       .
%% General                                      .
%% ------                                       .
%% Consolidate the substructures into one struct.
%   DO NOT EDIT the code of this section    
    
    sas = whos();
    sas( not( strcmp({sas.class},'struct') ) ) = [];
    %
    for sub = {sas.name}
        options.( sub{:} ) = eval( sub{:} );
    end
end
