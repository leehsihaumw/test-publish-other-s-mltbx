%%  ======================    m2uml_v20_user_interface    =======================
%#ok<*NASGU>
%%  Elements and Doers 1.1                                                      .

    puml = m2uml.create_PlantUML_script                             ...
            (   'Classes'       , Element_and_Doer_subclasses_()    ...
            ,   'UserOptions'   , simple_doc_options()              ... 
            ,   'Title'         , 'Elements and Doers 1.1'          ...
            ,   'FileBaseName'  , 'ElementsAndDoers_11'             ...
            );
%%  Elements and Doers 1.2                                                      .

    puml = m2uml.create_PlantUML_script                             ...
            (   'Classes'       , Element_and_Doer_subclasses_()    ...
            ,   'Arrows'        , {'m2uml.Element -up[hidden]-- m2uml.Doer'} ...
            ,   'UserOptions'   , simple_doc_options()              ... 
            ,   'Title'         , 'Elements and Doers 1.2'          ...
            ,   'FileBaseName'  , 'ElementsAndDoers_12'             ...
            ); 
%%  Elements and Doers 1.3                                                      .

    arrows = vertcat( {'m2uml.Element -up[hidden]-- m2uml.Doer'}...
                    , Element_and_Doer_inheritance_arrows_()    );

    puml = m2uml.create_PlantUML_script                             ...
            (   'Classes'       , Element_and_Doer_subclasses_()    ...
            ,   'Arrows'        , arrows                            ...
            ,   'UserOptions'   , simple_doc_options()              ...
            ,   'Title'         , 'Elements and Doers 1.3'          ...
            ,   'FileBaseName'  , 'ElementsAndDoers_13'             ...
            );
%%  Elements and Doers 1.4, minimal_doc_options                                 .
    
    arrows = vertcat( {'m2uml.Element -up[hidden]-- m2uml.Doer'} ...
                    , Element_and_Doer_inheritance_arrows_()     );

    puml = m2uml.create_PlantUML_script                             ...
            (   'Classes'       , Element_and_Doer_subclasses_()    ...
            ,   'Arrows'        , arrows                            ...
            ,   'UserOptions'   , minimal_doc_options()             ...
            ,   'FileBaseName'  , 'ElementsAndDoers_14'             ...
            );
%%  Elements and Doers 1.5, other relationship arrows, minimal_doc_options      .
    
    arrows = vertcat( {'m2uml.Element -up[hidden]-- m2uml.Doer'}...
                    , Element_and_Doer_inheritance_arrows_()    ...
                    , Element_and_Doer_other_arrows_()          );

    puml = m2uml.create_PlantUML_script                             ...
            (   'Classes'       , Element_and_Doer_subclasses_()    ...
            ,   'Arrows'        , arrows                            ...
            ,   'UserOptions'   , minimal_doc_options()             ...
            ,   'FileBaseName'  , 'ElementsAndDoers_15'             ...
            );
%%  Elements and Doers 1.6, other relationship arrows, [#blue,norank]           .
    
    other_arrows = Element_and_Doer_other_arrows_();
    other_arrows = strrep( other_arrows, '-->', '-[#blue,norank]->' );
    
    arrows = vertcat( {'m2uml.Element -up[hidden]-- m2uml.Doer'}    ...
                    , Element_and_Doer_inheritance_arrows_()        ...
                    , other_arrows                                  );

    puml = m2uml.create_PlantUML_script                             ...
            (   'Classes'       , Element_and_Doer_subclasses_()    ...
            ,   'Arrows'        , arrows                            ...
            ,   'UserOptions'   , minimal_doc_options()             ...
            ,   'FileBaseName'  , 'ElementsAndDoers_16'             ...
            );
%%  m2uml logo 1.1  incl. monospace, todofixme and arguments                    .

    fqnlist = m2uml_logo_fqn_list_();
    
    user.Footer.On          = false;
    user.Header.On          = false;
    user.Title.On           = false;
    user.Method.private     = false;
    user.Method.protected   = false;

    puml = m2uml.create_PlantUML_script     ...
            (   'Classes'       , fqnlist   ...
            ,   'UserOptions'   , user      );
%%  m2uml logo 1.2  simple_doc_options                                          .

    fqnlist = m2uml_logo_fqn_list_();    
    user.Title.On = false;

    puml = m2uml.create_PlantUML_script     ...
            (   'Classes'       , fqnlist   ...
            ,   'UserOptions'   , {simple_doc_options,user} );
    %
%%  m2uml logo 1.3  simple_doc_options, Monospaced=true and "arrow"             .
    %
    fqnlist = m2uml_logo_fqn_list_();    
    user.Title.On = false;
    user.Diagram.Monospaced = true;     
    
    arrow = 'FileExchange.m2uml.Element -[norank]-> FileExchange.m2uml.Doer';
    
    puml = m2uml.create_PlantUML_script     ...
            (   'Classes'       , fqnlist   ...
            ,   'Arrows'        , {arrow}   ...
            ,   'UserOptions'   , {simple_doc_options(),user}   ... 
            ,   'FileBaseName'  , 'm2uml_logo_13'               ...
        );
    %
%%  m2uml logo 1.4  Class diagram for display in the FEX main page              .
    %
    fqnlist = m2uml_logo_fqn_list_();    
    user.Title.On = false;
    user.Diagram.Monospaced = true;     
    
    arrow = 'FileExchange.m2uml.Element -[norank]-> FileExchange.m2uml.Doer';
    
    puml = m2uml.create_PlantUML_script                         ...
            (   'Classes'       , fqnlist                       ...
            ,   'Arrows'        , {arrow}                       ...
            ,   'UserOptions'   , {simple_doc_options(),user}   ... 
            ,   'FileBaseName'  , 'FEX_m2uml_logo'              ...
        );
    graphic_file = m2uml.puml2graphic( 'PlantUmlScript',puml, 'GraphicFormat','png' );
    m2uml.display_class_diagram( 'GraphicFile', graphic_file );
    %
%%  m2uml logo 2.0  Class diagram for display in the FEX main page              .
    %
    fqnlist = m2uml_logo_6_fqn_list_();
    user.Property.protected = true;
    user.Property.private   = true;
    user.Title.On           = false;
    
    arrow = 'FileExchange.m2uml.Element -[norank]-> FileExchange.m2uml.Doer';
    
    puml = m2uml.create_PlantUML_script                         ...
            (   'Classes'       , fqnlist                       ...
            ,   'Arrows'        , {arrow}                       ...
            ,   'UserOptions'   , {simple_doc_options(),user}   ... 
            ,   'FileBaseName'  , 'FEX_m2uml_logo'              ...
        );
    graphic_file = m2uml.puml2graphic( 'PlantUmlScript',puml, 'GraphicFormat','png' );
    m2uml.display_class_diagram( 'GraphicFile', graphic_file );
    %
%%  m2uml_logo, svg, viewer: web, webwindow, browser                            .
    puml = m2uml.create_PlantUML_script( 'Classes', m2uml_logo_fqn_list_ );
    graphic_file = m2uml.puml2graphic( 'PlantUmlScript', puml, 'GraphicFormat','svg' );
    m2uml.display_class_diagram( 'GraphicFile',graphic_file, 'Viewer','web' );
    m2uml.display_class_diagram( 'GraphicFile',graphic_file, 'Viewer','webwindow' );
    m2uml.display_class_diagram( 'GraphicFile',graphic_file, 'Viewer','browser' );
%%  m2uml_logo, png, viewer: web, webwindow, browser                            .
    puml = m2uml.create_PlantUML_script( 'Classes', m2uml_logo_fqn_list_ );
    graphic_file = m2uml.puml2graphic( 'PlantUmlScript', puml, 'GraphicFormat','png' );
    m2uml.display_class_diagram( 'GraphicFile',graphic_file, 'Viewer','web' );
    m2uml.display_class_diagram( 'GraphicFile',graphic_file, 'Viewer','webwindow' );
    m2uml.display_class_diagram( 'GraphicFile',graphic_file, 'Viewer','browser' );
%%  -----------------------------------------------------------------------------
%%  "m2uml generates UML Class Diagrams", m2uml 1, FEX Examples                 .
% The FEX Examples requires source code of these File Exchange submissions, Singleton,
% Iterator, TrafficSigns and youemel. Search FEX for: tag:oop <name>
    path_to_BN_Singleton = fullfile('h:\m\FEX\oop\BN\Singleton');
    path_to_BN_Iterator  = fullfile('h:\m\FEX\oop\BN\Iterator');
    path_to_TrafficSigns = fullfile('h:\m\FEX\oop\TrafficSigns');
    path_to_youemel      = fullfile('h:\m\FEX\UML\youemel');
%%  youemel                                                                     .
    addpath( path_to_youemel )
    m2uml.call_local_PlantUML       ...
        ( 'Title'   , 'youemel'     ...
        , 'Classes' , {
                        'youemel_poi'
                        'UmlClass'
                        'UmlDiagram'
                        'UmlDirectedRelationship'
                        'UmlGeneralization'
                        'UmlRelationship'
                    }    ...
        , 'Arrows'  , { 
...                     'skinparam nodesep  64' 
...                     'skinparam ranksep  32'
                        'youemel_poi     -->          UmlDiagram'
                        'UmlDiagram  "1" -right-> "*" UmlClass'
                        'UmlDiagram  "1" -left->  "*" UmlGeneralization : "  "'
                    } );
    rmpath( path_to_youemel )
%%  TrafficSigns                                                                .
    addpath( path_to_TrafficSigns )
    puml = m2uml.run( 'Animated Traffic Lights'  ...
        ,   {
            'start_poi'
            'map'
            'trafficLamp'
            'tLamps'
            }, {
            'start_poi -right-> map'
            'start_poi -down-> tLamps'
            'tLamps "1" -right-> "4" trafficLamp : "  "'
            } );
    rmpath( path_to_TrafficSigns )
%%  BN_Iterator                                                                 .
    addpath( path_to_BN_Iterator )
    puml = m2uml.run( 'BN_Iterator'  ...
        ,   {
            'List'
            'CellArrayList'
            'Iterator'
            'CellArrayListIterator'
            }, {
            'CellArrayList "1" <-left-o "1 " CellArrayListIterator : "  "'
            } );
    rmpath( path_to_BN_Iterator )
%%  BN_Singleton                                                                .
    addpath( path_to_BN_Singleton )
    [~] = m2uml.run( 'BN_Singleton'  ...
        ,   {
            'Singleton'
            'SingletonImpl'
            }, {
            } );
    rmpath( path_to_BN_Singleton )
%%  -----------------------------------------------------------------------------
%%  open PlantUML-script                                                        .
    matlab.desktop.editor.openDocument( puml );
%%  puml2web  -   display the class diagram                                     .
    graphic_file = m2uml.puml2graphic( 'PlantUmlScript', puml );
    m2uml.display_class_diagram( 'GraphicFile', graphic_file );
%
%%  clearvars fqnlist user puml                                                 .
    clearvars fqnlist user puml
%%  Open PlantUML GUI, https://plantuml.com/gui                                 .
    opt = m2uml.factory_options;
    cmd_str = sprintf( 'java -jar %s -gui', opt.General.PlantUmlJar );
    [sts,msg] = system( cmd_str );   
%%  ======================    Helper functions    ===============================
%#ok<*DEFNU>
function    fqnlist = Element_and_Doer_subclasses_()            %
    
    fqnlist = {
        'Element'
        'PlantUmlScript'
        'Package'
        'Class'
        'Property'
        'Method'
        'TodoFixme'
        'Enumeration'
        'Event'
        'Function'
        'Relationship'
        'Separator'
        'SingleCodeRow'
        'Skinparam'
        'Title'
        'Header'
        'Footer'
       ...
        'Doer'
        'MetaDataScanner'
        'SourceFileScanner'
        'LeafDisplaySelection'
        'LeafDisplayOrder'
        'Miscellaneous'
        'PlantUmlCodePrinter'
        };
    
    fqnlist = cellfun( @(chr) compose('m2uml.%s',chr), fqnlist, 'uni',true );
end
function    arrows  = Element_and_Doer_inheritance_arrows_()    %
 
    arrows = {
                'm2uml.Element <|--   m2uml.PlantUmlScript'
                'm2uml.Element <|---  m2uml.Package'
                'm2uml.Element <|---- m2uml.Class'
                'm2uml.Element <|--   m2uml.Property'
                'm2uml.Element <|---  m2uml.Method'
                'm2uml.Element <|---- m2uml.TodoFixme'
                'm2uml.Element <|--   m2uml.Enumeration'
                'm2uml.Element <|---  m2uml.Event'
                'm2uml.Element <|---- m2uml.Function'
                'm2uml.Element <|--   m2uml.Relationship'
                'm2uml.Element <|---  m2uml.Separator'
                'm2uml.Element <|---- m2uml.SingleCodeRow'
                'm2uml.Element <|--   m2uml.Skinparam'
                'm2uml.Element <|---  m2uml.Title'
                'm2uml.Element <|---- m2uml.Header'
                'm2uml.Element <|--   m2uml.Footer'
            };
end
function    arrows  = Element_and_Doer_other_arrows_()          %
    fqnlist = Element_and_Doer_subclasses_();    
    [ arrows, ~ ] = m2uml.search_relationships( fqnlist );
end
function    fqnlist = m2uml_fqn_list_()                         %

    %   Input: packages     <1xn char> 
    
    fqnlist = {
        'Element'
        'Class'
        'Enumeration'
        'Event'
        'Footer'
        'Function'
        'Header'
        'Method'
        'Package'
        'PlantUmlScript'
        'Property'
        'Relationship'
        'Separator'
        'SingleCodeRow'
        'Skinparam'
        'Title'
        'TodoFixme'
        ...
        'BlockRegex'
        'AbstractMethodsBlockRegex'
        'SimpleBlockRegex'
        'AssignmentBlockParser'
        'CharacterClasses'
        'AssignmentParser'
        ...
        'GeneralizationScanner'
        'HierarchyLeafAdder'
        'NodeHierarchyCreator'
        'PropertiesBlockRegex'
        'SourceFile'
        'Stack'
        ...
        'Doer'
        'LeafDisplayOrder'
        'LeafDisplaySelection'
        'MetaDataScanner'
        'Miscellaneous'
        'PlantUmlCodePrinter'
        'SourceFileScanner'
        };
end
function    fqnlist = m2uml_logo_fqn_list_()                    %
    fqnlist = { 'FileExchange.m2uml.Element'
                'FileExchange.m2uml.Doer'
                'FileExchange.m2uml.Class'
                'FileExchange.m2uml.MetaDataScanner'
              };
end
function    fqnlist = m2uml_logo_6_fqn_list_()                  %
    fqnlist = { 'FileExchange.m2uml.Element'
                'FileExchange.m2uml.Doer'
                'FileExchange.m2uml.Package'
                'FileExchange.m2uml.Class'
                'FileExchange.m2uml.MetaData'
                'FileExchange.m2uml.UmlCodePrinter'
              };
end
