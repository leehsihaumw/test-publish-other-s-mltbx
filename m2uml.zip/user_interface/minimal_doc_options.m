function    options = minimal_doc_options()
% minimal_doc_options 

%#ok<*STRNU> 
narginchk(0,0)
%% Diagram                                      .
    Diagram.Arguments          = false;         %   show arguments of methods
    Diagram.Monospaced         = false;         %   use monospace in class boxes
    Diagram.LinetypeDefault    = true;          %   false gives "linetype ortho"
    Diagram.TopToBottom        = true;          %   false gives "left to right direction"
%% Class                                        .
% NOTE: What about circle letter of Event?                     
    CBC.A = '#A9DCDF';                          %   abstract     
    CBC.C = '#ADD1B2';                          %   general, default letter     
    CBC.D = 'Plum';                             %   date
    CBC.E = '#EB937F';                          %   enum         
    CBC.H = '#E6FFE6';                          %   handle
    CBC.S = '#FF7700';                          %   singleton    
    CBC.V = 'PaleGreen';                        %   value
    Class.CircleBackgroundColor = CBC;          %   "Circle" is better than "Stereotype"
    Class.SeparatorLabel        = false;        %   not used
%% Footer                                       . the text at the very bottom       
    Footer.On       = false;                    %
%% Function                                     .
%% Header                                       . the text in the upper right corner
    Header.On       = false;                    %
%% Hyperlink                                    .
    Hyperlink.Class       = false;              %
    Hyperlink.Enumeration = false;              %
    Hyperlink.Event       = false;              %
    Hyperlink.Function    = false;              %
    Hyperlink.Method      = false;              %
    Hyperlink.Package     = false;              %
    Hyperlink.Property    = false;              %
    Hyperlink.TodoFixme   = false;              %
%% Method                                       .
    Method.private       = false;               %   show private methods
    Method.protected     = false;               %   show protected methods
    Method.public        = false;               %   show public methods
%% Package                                      .
%% Property                                     .
    Property.private     = false;               %   show private properties
    Property.protected   = false;               %   show protected properties
    Property.public      = false;               %   show public properties
%% Title                                        .
    Title.On        = false;                    %
%% TodoFixme                                    .
    TodoFixme.fixme = false;                    %   show FIXME annotations
    TodoFixme.todo  = false;                    %   show TODO annotations
    TodoFixme.note  = false;                    %   show NOTE annotations
%% Tooltip                                      .
    %   
    Tooltip.Class       = false;                %   show tooltip of classes
    Tooltip.Enumeration = false;                %   show tooltip of enumerations
    Tooltip.Event       = false;                %   show tooltip of events
    Tooltip.Function    = false;                %   show tooltip of functions
    Tooltip.Method      = false;                %   show tooltip of methods
    Tooltip.Package     = false;                %   show tooltip of packages
    Tooltip.Property    = false;                %   show tooltip of properties
    Tooltip.TodoFixme   = false;                %   show tooltip of aqnnotations
%% ------                                       .
%% General                                      .
    General.WorkingFolder       = fullfile('d:\m\tmp'); % folder of puml and image files
    General.FileBaseName        = 'test';       % name of puml-script and image file
    General.PlantUmlExtension   = 'puml';
    General.GraphicFormat       = 'svg';        % 'svg', 'png', ...
    General.Viewer              = 'web';        % 'web', 'browser' or 'webwindow'
    General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2019.11.jar');
%   General.PlantUmlJar         = fullfile('d:\_MyPrg\PlantUML\plantuml.1.2018.09.jar');
    General.DisplayWidth        = 0; % pixels <80 switches default on. Leave it at zero! 
%% ------                                       .
%% Consolidate the substructures into one struct.
%   DO NOT EDIT the code of this section    
    
    sas = whos();
    sas( not( strcmp({sas.class},'struct') ) ) = [];
    %
    for sub = {sas.name}
        options.( sub{:} ) = eval( sub{:} );
    end
end
