% m2uml
% Version 2.0 03-Apr-2020
%
% Created automatically by make_contents_file at 2019-10-15 10:04:28
%
%   Packages
%       +m2uml       - H1-line of the m2uml package
%
%   Folders
%       doc          - The default document folder of the m2uml toolbox
%
%   Classes
%       @classfolder - H1-line of class folder
%       MyClass.m    - This class contains methods for performing simple arithmetics.
%
%   Functions
%       myfunc.m     - This function takes a numeric input and doubles it
%
%   Script
%
