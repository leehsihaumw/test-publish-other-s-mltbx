function    root = m2uml_root()
% m2uml_root returns the fully qualified name of the directory where m2uml is installed.
%
% Syntax:
%   root = m2uml_root()
%
% Outputs:
%   root    <1xn char> full folder specification of \m2uml
%
% Description:
%   m2uml_root returns the root folder of m2uml regardless of where m2uml is installed. 
%   m2uml_root.m must exist somewhere in the m2uml installation (on the search path).
%   The relevant file separator is used.
%
% Example:
%   d:\m\AddOns\Toolboxes\m2uml
%   d:\m\BestPractices\m2uml_sandbox\tbx\m2uml
%
% See also:
%    
    persistent folder
    if isempty( folder )
        whch = which( 'm2uml_root', '-all' );
        assert( numel(whch)==1, 'm2uml:PathProm'                    ...
            ,   'More than one toolbox, "m2uml", on the search path'  )

        ffs = mfilename('fullpath');
        cac = strsplit( ffs, filesep );
        ixm = find( strcmp( cac, 'm2uml' ) );
    
        folder = fullfile( cac{1:ixm} );
    end
    root = folder;
end
