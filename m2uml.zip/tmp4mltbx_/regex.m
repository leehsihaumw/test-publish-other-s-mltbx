classdef    regex      
% regex contains regular expressions, which are accessed with static methods
%
%   regex.help prints the H1-lines of the the regular expressions
%
%   See also: IDE_Tools/regular_expression_test

%   Problem: My regular expressions seldom works straight-away. They typically
%   requirer a fair amount of debugging. I have poorly documented regular
%   expressions in many m-files.
%
%   Solution: Keep all non-trivial regular expressions in on place. Write
%   documentation, test them and finally try to reuse them. This class is
%   an effort in that direction.
   
%   TODO: Develop some conventions on how to write and document these regular
%   expressions. One problem is illustrated by: M2U_extract_function_name_101_test 
%       Actual: ' tooltip',  Expected: 'tooltip'
%   Currently, I fail to make the test pass by modifying the quantifiers of
%   whitespace, e.g. [\x20\x09]*, [\x20\x09]*? and [\x20\x09]*+. My mental model 
%   doesn't match Matlabs behavior. Secondly, I don't exactly remember/understand
%   why I used whitespace exactly the way I did.
% 
%   H1-line:
%       "Captures" indicates that the Output Keyword, "tokens", is intended
%       "Matches" indicates that the Output Keyword, "match" or "start", is intended

%   TODO: 2020-07-28, Typical use cases in the help section of each regular expression
%   would be helpful
    
    methods     ( Static = true, Access = public )      %
        function    varargout = regex                   %
            regex.help
            varargout = {};
        end
        function    help( varargin )                    %
            % 
            metadata = meta.class.fromName( 'regex' );
            method_list = reshape( metadata.MethodList, 1,[] );

            iss = strcmp( curly( method_list,'DefiningClass','Name'), 'regex' ) ...
                & not(ismember( {method_list.Name}, {'empty'} ))                ...
                & [method_list.Static]                                          ;
            method_list( not(iss) ) = [];
            
            mxl = max( cellfun( @length, {method_list.Name} ) );
            ffs = which('regex');
            
            [ ~, ixs ]  = sort( {method_list.Name} );
            for method = method_list( ixs )
                lnk = hyperlink_to_document( ffs, 'Method', method.Name );
                len = length( method.Name );
                h1  = get_H1_line( ffs, method.Name );
                fprintf( '%s', lnk );   % prints (len+6) characters
                fprintf( '%s', blanks( mxl+6 - (len+6) +2 ) );
                fprintf( '%s\n', h1 );
            end
        end
    end
    methods     ( Static = true, Access = public )      %
        function    xpr = abstract_method_name( name )  %
            % (name) Captures the name of an abstract method 
            
            %   2020-07-26, No input name is just confusing, since it doesn't honor the
            %   name of the function name. Hopefully, blocking "no input" doesn't break 
            %   anything. 
            narginchk( 1, 1 )   
            
            if not( exist('name','var') == 1 ) || isempty( name )
                func_name = regex.name;
            else
                name = convertStringsToChars( name );
                func_name = [ '[\x20\x09]*?\<', name, '\>' ];
            end
            
            % Regex101: ^\h*(?:(?:(?:\w+)|(?:\[[\w\h\,]+\]))\h*=)*\h*(\w+)\b  
            xpr = [
                '(?m)                       '   ...
                '^                          '   ... % beginning of line
                '[\x20\x09]*?               '   ... % zero or more whitespace
                '(?:                        '   ... % group
                '   (?:                     '   ... % lhs 
                        regex.lhs               ...
                '   )                       '   ...
                '   [\x20\x09]*?            '   ...
                '   =                       '   ...
                '   [\x20\x09]*?            '   ...
                ')?                         '   ...
                '[\x20\x09]*+               '   ... 2019-02-18, poi: 
                '(                          '   ... % capture 
                    func_name                   ... % name
                ')                          '   ...
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = concrete_method_name( name )  %
            %  (name) Captures the name of a concrete method/function
            
            % NOTE: Concatenation of string and char results in a string array
            %       ['abc',"123"], ans = 1×2 string array, "abc" "123"              
            
            %   2020-07-26, No input name is just confusing, since it doesn't honor the
            %   name of the function name. Hopefully, blocking "no input" doesn't break 
            %   anything. When would I want to find the name of the class? Isn't it known
            %   beforehand. 
            
            narginchk( 0, 1 )
            
            if not( exist('name','var') == 1 ) || isempty( name )
                func_name = regex.name;
            else
                name = convertStringsToChars( name );
                func_name = [ '[\x20\x09]*?\<', name, '\>' ];
            end
            
            xpr = [
                '(?m)                       '   ...
                '^                          '   ... % beginning of line
                '[\x20\x09]*?               '   ... % zero or more whitespace
                'function                   '   ... % "function"
                '[\x20\x09]+                '   ... % one or more space
                '(?:                        '   ...
                '   (?:                     '   ...
                        regex.lhs               ... % left-hand-side, e.g. [a,b]
                '   )                       '   ...
                '   [\x20\x09]*?            '   ...
                '   =                       '   ...
                '   [\x20\x09]*?            '   ...
                ')?+                        '   ... % "?+": match as much as possible
                '[\x20\x09]*+               '   ... 2019-02-18, poi: 
                '(                          '   ...
                    func_name                   ... % 
                ')                          '   ...
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = abstract_method_block_begin() %
            % Matches the first line of an abstract method block
            
            % NOTE: '( Abstract = (true) )' and '( Abstract = false )' are legal. Shit!
            % '( Abstract = (false) )' yields a syntax warning. A test indicates that 
            % the signatures are skipped(???). Thus, (false) is not correct. 
            
            % Regex101: '^[\x20\x09]*methods[\x20\x09]*\(.*Abstract(?!\h*=\h*false)'
            xpr = [
                '(?m)                       '   ...
                '^                          '   ... % beginning of line
                '[\x20\x09]*                '   ... % zero or more whitespace
                'methods                    '   ... % "methods"
                '[\x20\x09]*                '   ... % zero or more whitespace
                '\(.*?                      '   ... % "(" anything up to
                'Abstract                   '   ... % "Abstract"
                '(?!                        '   ... % NOT followed by
                '   [\x20\x09]*=[\x20\x09]* '   ... % "=" embedded in optional space 
                '   false                   '   ... % "false"
                ')                          '   ... % 
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = block_begin_keywords()        %
            % Captures block begin keywords
            % NOTE: first step in a refactoring
            % NOTE: 2020-04-28, replaced rs.SourceFileAnalyzer by m2uml.SourceFileAnalyzer
            xpr = strjoin( m2uml.SourceFileAnalyzer.block_begin_keywords, ')\\>|\\<(' );
            xpr = [ '\<(', xpr, ')\>' ];
        end
        function    xpr = leading_block_begin_keyword() %
            % Captures a leading block begin keyword
            xpr = regex.block_begin_keywords();
            xpr = [ '^[\x20\x09]*\<(', xpr, ')\>' ];
        end
        function    xpr = leading_block_end_keyword()   %
            % Captures a leading block end keyword
            % TODO: Looks very optimistic, however, not used as of 2019-07-18
            %       Called only by ...\old\CallInfo.
            xpr = ['^[\x20\x09]*\<(end)\>']; %#ok<NBRAK>
        end
        function    xpr = generalization_arrow()        %
            % TODO: 2019-12-16, Complete generalization_arrow regex. Distinguish between 
            %       source and target
            xpr = [
                '(?m)                       '   ... % Match at beginning and end of line
                '^\x20*                     '   ... % zero or more space beginning of line
                '(                          '   ... % begin capture token of class name
                '   \w[^\x20:]*             '   ... % class name incl. package names
                ')                          '   ... % end capture token of class name
                '(?:\:\:\w+)?               '   ... % "::"name not capture token
                '\x20+                      '   ... % One or more spaces
                '(                          '   ... % begin capture token of arrow
                '   (?:<\|[^\x20]+)         '   ... % arrow head, "<|", and up til space                  
                '   |                       '   ... % or
                '   (?:[^\x20\|]+\|>)       '   ... % anything but " " or "|" and "|>"  
                ')                          '   ... % end capture token
                '\x20+                      '   ... % One or more spaces
                '(                          '   ... % begin capture token of class name
                '   \w[^\x20:]*             '   ... % class name incl. package names
                ')                          '   ... % end capture token of class name
                '(?:\:\:\w+)?               '   ... % "::"name not capture token
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = todofixme_annotation()        %
            % Captures todofixme keyword and annotation text
            
            xpr = [ '(?i)           '   ... % Do not match letter case; todo,fixme,note 
                '^                  '   ... % beginning of line
                '(?:                '   ... % start non-capturing group 
                '   [\x20\x09]*     '   ... % zero or more whitespace
                '   \x25+           '   ... % one or more literal: %
                '   [\x20\x09]*     '   ... % zero or more whitespace
                ')                  '   ...
                '(                  '   ... % start first capturing group
                '   (todo)          '   ... % literal keyword
                '   |               '   ... % OR
                '   (fixme)         '   ... % literal keyword
                '   |               '   ... % OR
                '   (note)          '   ... % literal keyword
                ')                  '   ...
                '(?:                '   ... % start non-capturing group
                '   [\x3A\x20]+     '   ... % one or more of literal: ":" and " "
                ')                  '   ... 
                '(                  '   ... % start second capturing group
                '   .+              '   ... % anything up til the end of line
                ')                  '   ...
                '$                  '   ... % end of line                     
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = leading_name( name )          %
            % (name) Captures the leading name 
            narginchk( 1, 1 )
            xpr = [ '^[\x20\x09]*\<(', name, ')\>' ];
        end
        function    xpr = name_anywhere( name )         %
            % (name) Captures a valid name anywhere in text
            narginchk( 1, 1 )
            xpr = [ '\<(', name, ')\>' ];
        end
        function    xpr = comment_text()                %
            % Capture text of a one comment line
            xpr = '^[\x20\x09]*%+[\x20\x09]*+(.*+)$';
        end
        function    xpr = classdef_name( name )         %
            %  (name) Captures the name of a class                    
            
            narginchk( 0, 1 )
            
            if not( exist('name','var') == 1 ) || isempty( name )
                class_name = regex.name;
            else
                name = char( name );
                class_name = [ '[\x20\x09]*?\<', name, '\>' ];
            end
            
            xpr = [
                '(?m)                       '   ...
                '^                          '   ... % beginning of line
                '[\x20\x09]*?               '   ... % zero or more whitespace
                'classdef                   '   ... % "classdef"
                '[\x20\x09]*+               '   ... % zero or more whitespace
                '(?:                        '   ... % non-capture token
                '   \([^\)]*\)              '   ... % anything enclosed by parantheses
                ')?                         '   ... % match zero or one 
                '[\x20\x09]*+               '   ... % whitespace
                '(                          '   ... % capture token
                    class_name                  ... % 
                ')                          '   ...
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = indices_expression( name )    %
            %  (name) matches the entire indices_expression of a LHS
            %
            if isa( name, 'string' )
                if strlength(name) ==  0
                    keyboard
                else
                    name = char( name );
                end
            end
            xpr = [
                '(?<=                       '   ... % look behind for 
                '   [\x28\x5C]              '   ... % literal one "(" or "{"
                ')                          '   ... %
                '[\w,;:\d\x20]*             '   ... % characters that are legal in index
                '\<                         '   ... % beginning of a word
                    name                        ... %
                '\>                         '   ... % end of a word
                '[\w,;:\d\x20]*             '   ... % characters that are legal in index
                '(?=                        '   ... % look ahead for 
                '   [\x7D\x29]              '   ... % literal one "}" or ")"
                ')                          '   ... %
                ];
            xpr( isspace(xpr) ) = [];
        end
    end
    methods     ( Static = true, Access = public )      %
        function    xpr = name()                        %
            % Matches valid variable names embedded in spaces, 
            % but also keywords. See iskeywords()
            xpr = '[\x20\x09]*?\<[A-Za-z]\w*\>[\x20\x09]*?';
        end
        function    xpr = name_or_tilde()               %
            % Matches valid variable names and tilde embedded in spaces, 
            % but also keywords
            % TODO: tilde constitutes a word boundary. However, 'A4~5' is a syntax error 
            % xpr = '[\x20\x09]*?\<[A-Za-z~]\w*\>[\x20\x09]*?';
            xpr = '[\x20\x09]*?\<([A-Za-z]\w*)|~\>[\x20\x09]*?';    % slightly better
        end
        function    xpr = lhs( name )                   %
            % Matches valid name or group of names in brackets 
            %   TODO: The name, lhs, promises too match. The expression doesn't 
            %   assert that the group is left of an equal sign. 
            if nargin == 0
                xpr_name = regex.name;
            else
                xpr_name = [ '[\x20\x09]*?\<', name, '\>[\x20\x09]*?' ];
            end
            xpr = [                             ... % output argument in brackets
                '(?:                        '   ... % group but don't capture
                '   [\x20\x09]*?            '   ... % optional whitespace     
                '   \[                      '   ... % "[" 
                '   (?:                     '   ... % 
                        xpr_name                ... % name embedded in optional space
                '       [,\x20\x09]         '   ... % one comma or space
                '   )*                      '   ... % optionally, 
                    xpr_name                    ... % name embedded in optional space    
                '   \]                      '   ... % "]"
                '   [\x20\x09]*?            '   ... %
                ')                          '   ... % 
                '|                          '   ... % or
                '(?:                        '   ... % single argument output 
                    xpr_name                    ... % name without square brackets 
                ')                          '   ... % 
                ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = lhs_with_tilde()              %
            % Matches valid name/tilde or group of name/tilde in brackets
            xpr = [        
                '(?:                        '   ... % multiple argument output
                '   [\x20\x09]*\[           '   ... % "[" 
                '   (?:                     '   ... % 
                        regex.name_or_tilde     ... % name 
                '       ,?                  '   ... % followed by zero or one "," 
                '   )*                      '   ... % optionally, 
                    regex.name_or_tilde         ... % name    
                '   \][\x20\x09]*           '   ... % "]" 
                ')                          '   ... % 
                '|                          '   ... % or
                '(?:                        '   ... % single argument without brackets
                    regex.name                  ... % name
                ')                          '   ... % 
                ];
            xpr = [ '(?:', xpr, ')' ];
            xpr( isspace(xpr) ) = [];
        end
        function    xpr = name_of_variable( name )      %
            %   Matches valid names of variables. Limitation: intended for filtered 
            %   strings of m2uml.SourceFile. Cannot distinguish between names of 
            %   variables and functions 
            if nargin == 0
                xpr_name = '\<[a-zA-Z]\w*\>';
            else
                xpr_name = ['\<', name,'\>'];
            end
            xpr = [                             ... % 
                '(?<!                       '   ... % look behind for anything but
                '   \x2E                    '   ... % dot, i.e. "." 
                ')                          '   ... % 
                 xpr_name                       ... % trimmed name; no spaces
                ];
            xpr( isspace(xpr) ) = [];
        end
    end
    methods     ( Static = true, Access = public )      %
        function    xpr = block_of_numerics()
           % ^(?:\x20*(?:[+\-]?\d+(?:\.\d*)*[,\x20]*)+\x10)+
           % ^\x20*(?:[+\-]?\d*(?:\.\d*)*[,\x10\x20]*)+$
           keyboard
           % Doesn't work
            xpr = [ 
                '(?-m)                      '   ... % match beginning and end of text
                '^                          '   ... % beginning of entire text
                '(?:                        '   ... % block of lines; entire text
                '   [\x20\x09]*             '   ... % zero or more white-space 
                '   (?:                     '   ... % one line
                '       (?:                 '   ... % group of delimited numbers
                '           (?<num>         '   ... % one "number"
                '               [\x2B\x2D]? '   ... % zero or one plus/minus
                '               \d+         '   ... % whole number part, at least "0"
                '               (?:         '   ... % decimal part
                '                   \x2E    '   ... % decimal point
                '                   \d*     '   ... % zero or mode digits
                '               )?          '   ... % zero or one decimal part
                '           )               '   ... % one number
                '           [\x2C\x20]+     '   ... % one or more delimiters
                '       )+                  '   ... % one number with trailing delimiter
                '       (?:k<num>)          '   ... % one number, the last on the line 
                '       [\x20\x09]*\x10     '   ... % optional white-space and new line
                '   )+                      '   ... % many numbers, i.e one line
                ')+                         '   ... % many lines, i.e. one block 
                ];
            xpr = [ '(?:', xpr, ')' ];
            xpr( isspace(xpr) ) = [];
        end
    end
    
end
%%  I tried to develop a regex to validate a block of numeric data. And lost it
%   and found it. Pasted above.
%
%   Recovered from Command window.
%   The problem is connected to newline a the anchors, ^$. If the newline is consumed 
%   matched then the anchor fails? 
%   https://www.regular-expressions.info/floatingpoint.html
%
%{
xpr = [ 
                '(?-m)                      '   ... % match beginning and end of text
                '^                          '   ... % beginning of entire text
                '(?:                        '   ... % block of lines; entire text
                '   [\x20\x09]*             '   ... % zero or more white-space 
                '   (?:                     '   ... % one line
                '       (?:                 '   ... % one "number"
                '           [\x2B\x2D]?     '   ... % zero or one plus/minus
                '           \d+             '   ... % whole number part, at least "0"
                '           (?:             '   ... % decimal part
                '               \x2E        '   ... % decimal point
                '               \d*         '   ... % zero or mode digits
                '           )?              '   ... % zero or one decimal part
                '           [\x2C\x20]+     '   ... % one or more delimiters
                '       )+                  '   ... % one number
                '       [\x20\x09]*\x10     '   ... % optional white-space and new line
                '   )+                      '   ... % many numbers, i.e one line
                ')+                         '   ... % many lines, i.e. one block 
                ];
            xpr = [ '(?:', xpr, ')' ];
            xpr( isspace(xpr) ) = [];
pos = regexp( data(jj), xpr_num, 'match' );
Undefined function or variable 'xpr_num'. 
pos = regexp( data(jj), xpr, 'match' );
xpr
xpr =
    '(?:(?-m)^(?:[\x20\x09]*(?:(?:[\x2B\x2D]?\d+(?:\x2E\d*)?[\x2C\x20]+)+[\x20\x09]*\x10)+)+)'
dbhex \x31
>>>       1   <<< put on clipboard
xpr = [ 
                '(?-m)                      '   ... % match beginning and end of text
                '^                          '   ... % beginning of entire text
                '(?:                        '   ... % block of lines; entire text
                '   [\x20\x09]*             '   ... % zero or more white-space 
                '   (?:                     '   ... % one line
                '       (?:                 '   ... % group of delimited numbers
                '           (?<num>         '   ... % one "number"
                '               [\x2B\x2D]? '   ... % zero or one plus/minus
                '               \d+         '   ... % whole number part, at least "0"
                '               (?:         '   ... % decimal part
                '                   \x2E    '   ... % decimal point
                '                   \d*     '   ... % zero or mode digits
                '               )?          '   ... % zero or one decimal part
                '           )*              '   ... % one number
                '           [\x2C\x20]+     '   ... % one or more delimiters
                '       )                   '   ... % one group of numbers
                '       (?:k<num>)          '   ... % one number, the last on the line 
                '       [\x20\x09]*\x10     '   ... % optional white-space and new line
                '   )+                      '   ... % many numbers, i.e one line
                ')+                         '   ... % many lines, i.e. one block 
                ];
            xpr = [ '(?:', xpr, ')' ];
            xpr( isspace(xpr) ) = [];
xpr
xpr =
    '(?:(?-m)^(?:[\x20\x09]*(?:(?:(?<num>[\x2B\x2D]?\d+(?:\x2E\d*)?)*[\x2C\x20]+)(?:k<num>)[\x20\x09]*\x10)+)+)'
xpr = [ 
                '(?-m)                      '   ... % match beginning and end of text
                '^                          '   ... % beginning of entire text
                '(?:                        '   ... % block of lines; entire text
                '   [\x20\x09]*             '   ... % zero or more white-space 
                '   (?:                     '   ... % one line
                '       (?:                 '   ... % group of delimited numbers
                '           (?<num>         '   ... % one "number"
                '               [\x2B\x2D]? '   ... % zero or one plus/minus
                '               \d+         '   ... % whole number part, at least "0"
                '               (?:         '   ... % decimal part
                '                   \x2E    '   ... % decimal point
                '                   \d*     '   ... % zero or mode digits
                '               )?          '   ... % zero or one decimal part
                '           )               '   ... % one number
                '           [\x2C\x20]+     '   ... % one or more delimiters
                '       )+                  '   ... % one number with trailing delimiter
                '       (?:k<num>)          '   ... % one number, the last on the line 
                '       [\x20\x09]*\x10     '   ... % optional white-space and new line
                '   )+                      '   ... % many numbers, i.e one line
                ')+                         '   ... % many lines, i.e. one block 
                ];
            xpr = [ '(?:', xpr, ')' ];
            xpr( isspace(xpr) ) = [];
xpr
%}
